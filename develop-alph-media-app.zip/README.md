# ALPH Media — All-in-One Android Music Player, Video Player, Photo Gallery & Professional Media Studio

**ALPH Media** is a native Android application built with **Kotlin**, **Jetpack Compose**, **AndroidX Media3 (ExoPlayer & Transformer)**, **Room**, **DataStore**, **MediaCodec/MediaMuxer**, and **ExifInterface**.

---

## 1. Core Capabilities

1. **Advanced Music Player**:
   - Local `MediaStore` discovery organized into Songs, Albums, Artists, Genres, Folders, Playlists, Favorites, Recently Played, Most Played, and Unplayed tracks.
   - **Advanced Repeat N-Times Engine**: Supports Repeat Off, Repeat One Forever, Repeat All Queue, Repeat Current Playlist, and **Repeat N Times** (2x, 3x, 4x, or custom count), where the count clearly specifies **Total Plays** of the current track before automatically advancing to the next item in the queue.
   - **Playback Speed (0.5x – 2.0x)** with custom slider & memory.
   - **Equalizer & Audio Effects**: Hardware `Equalizer`, `BassBoost`, `Virtualizer`, channel balance, and 11 presets with real OEM capability checks.
   - **Synchronized LRC Lyrics**: Embedded and local `.lrc` parser with manual sync delay offset.
2. **Advanced Video Player**:
   - Full-screen playback with **Dual-Zone Vertical Gestures** (Left = In-App Window Brightness via `WindowManager.LayoutParams.screenBrightness`, Right = Stream Volume), **Horizontal Fine Seeking**, **Double-Tap Seek (-10s/+10s)**, **Screen Lock Mode**, **A-B Loop**, **Picture-in-Picture (PiP)**, and **SRT/WebVTT Subtitle Synchronization & Styling**.
3. **Sleep Timer & Playback Automation**:
   - Background-safe coroutine timer inside `AlphMediaPlaybackService` (`MediaSessionService`) with presets (5m to 60m + custom) and gradual volume fade-out, plus automatic pause on headphone disconnect (`ACTION_AUDIO_BECOMING_NOISY`).
4. **Ringtone & Alarm-Tone Creator**:
   - Real off-main-thread `MediaExtractor` + `MediaMuxer` audio slicing with interactive waveform handle trimming, fade-in/out, and `RingtoneManager.setActualDefaultRingtoneUri` for Default Ringtone, Alarm Tone, Notification Sound, and Contact Ringtone assignment.
5. **Professional Video Editor**:
   - Powered by AndroidX Media3 `Transformer` and `OverlayEffect`: Trim, Split at Playhead, Merge, Crop, Rotate, Flip, Speed Control, Audio Track Mute/Volume/BGM, 13 Filters + Manual Color Grading, and **Timed Text Overlays on Selected Timeline Segments** (`startTimeMs..endTimeMs`).
6. **Advanced Photo Gallery & Professional Photo Editor**:
   - Pinch-to-zoom viewer, configurable Slideshow with local music, and non-destructive `Bitmap` + `ColorMatrix` + `Canvas` editor (Crop, Rotate, Flip, 13 Color Adjustments, Filters, Multi-Layer Text, Freehand Draw/Eraser, Blur/Pixelate, Watermark, Before/After comparison, and real JPEG/PNG export).
7. **Real Media Metadata Editor & File Manager**:
   - Modifies actual file tags (`ExifInterface` & container tags + embedded cover artwork) using safe atomic temporary file replacement and Android 11+ `MediaStore.createWriteRequest` consent.
8. **10 Complete Themes & Arabic (RTL) / English (LTR) Localization**:
   - *Obsidian Black, Midnight Graphite, Deep Ocean, Emerald Night, Royal Purple, Soft Titanium, Premium Pearl, Warm Light, Minimal Monochrome, and Custom Accent Theme*.

---

## 2. Project Structure

```text
ALPH-Media/
├── .github/workflows/android-build.yml
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── java/com/alphmedia/app/
│       │   │   ├── AlphMediaApplication.kt
│       │   │   ├── MainActivity.kt
│       │   │   ├── core/model/MediaModels.kt
│       │   │   ├── core/designsystem/AlphTheme.kt
│       │   │   ├── core/designsystem/AlphNavigationBar.kt
│       │   │   ├── core/database/AlphDatabase.kt
│       │   │   ├── core/datastore/UserPreferencesRepository.kt
│       │   │   ├── media/library/MediaStoreScanner.kt
│       │   │   ├── media/player/AlphMediaPlaybackService.kt
│       │   │   ├── media/player/AudioEqualizerController.kt
│       │   │   ├── media/player/LyricsParser.kt
│       │   │   ├── media/editor/MediaStudioEngines.kt
│       │   │   ├── media/editor/VideoTransformerEngine.kt
│       │   │   └── ui/video/VideoPlayerScreen.kt
│       │   └── res/
│       │       ├── drawable/ic_alph_launcher.xml
│       │       ├── values/strings.xml
│       │       ├── values-ar/strings.xml
│       │       ├── values/themes.xml
│       │       └── xml/file_paths.xml
│       └── test/java/com/alphmedia/app/AlphMediaEnginesTest.kt
├── gradle/libs.versions.toml
├── gradle/wrapper/gradle-wrapper.properties
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── gradlew
```

---

## 3. Building the APK via GitHub Actions or Local CLI

### Option A: Automated GitHub Actions Build (Recommended)
1. Push this repository to GitHub.
2. Open the **Actions** tab in your GitHub repository.
3. The **ALPH Media Android CI & APK Build** workflow runs automatically on every `push`, `pull_request`, or manual `workflow_dispatch`.
4. Download the compiled `ALPH-Media-Debug-APK` artifact directly from the completed workflow run.

### Option B: Local Android Studio / Command Line Build
```bash
chmod +x ./gradlew
./gradlew testDebugUnitTest lintDebug assembleDebug
```
The installable APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.
