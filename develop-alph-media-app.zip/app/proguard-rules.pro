# ALPH Media ProGuard / R8 Rules
-keep class com.alphmedia.app.core.model.** { *; }
-keep class com.alphmedia.app.core.database.** { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase { *; }
-dontwarn androidx.media3.**
-keep class androidx.media3.** { *; }
