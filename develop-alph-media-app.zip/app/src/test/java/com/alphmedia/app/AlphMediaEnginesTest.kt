package com.alphmedia.app

import com.alphmedia.app.core.model.RepeatConfiguration
import com.alphmedia.app.core.model.RepeatModeType
import com.alphmedia.app.core.model.TimedTextOverlay
import com.alphmedia.app.media.player.LyricsParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AlphMediaEnginesTest {

    @Test
    fun repeatCountEngine_tracksRemainingPlaysCorrectly() {
        val config3Plays = RepeatConfiguration(
            mode = RepeatModeType.COUNT_TOTAL_PLAYS,
            targetPlayCount = 3,
            currentPlayIteration = 1
        )
        assertEquals(2, config3Plays.remainingPlays)

        val secondPlay = config3Plays.copy(currentPlayIteration = 2)
        assertEquals(1, secondPlay.remainingPlays)

        val finalPlay = config3Plays.copy(currentPlayIteration = 3)
        assertEquals(0, finalPlay.remainingPlays)
    }

    @Test
    fun lyricsParser_parsesLrcTimestampsAndAppliesOffset() {
        val sampleLrc = """
            [00:10.00]First synchronized line
            [00:24.50]Second synchronized line
        """.trimIndent()

        val parsed = LyricsParser.parseLrc(sampleLrc, syncOffsetMs = 500L)
        assertEquals(2, parsed.size)
        assertEquals(10_500L, parsed[0].timestampMs)
        assertEquals("First synchronized line", parsed[0].text)
        assertEquals(25_000L, parsed[1].timestampMs)

        assertEquals(0, LyricsParser.findActiveLineIndex(parsed, 12_000L))
        assertEquals(1, LyricsParser.findActiveLineIndex(parsed, 26_000L))
    }

    @Test
    fun timedTextOverlay_isActiveOnlyWithinConfiguredInterval() {
        val overlay = TimedTextOverlay(
            id = "caption_1",
            text = "Appears between 10s and 15s",
            startTimeMs = 10_000L,
            endTimeMs = 15_000L
        )
        assertFalse(overlay.isActiveAt(4_000L))
        assertTrue(overlay.isActiveAt(10_000L))
        assertTrue(overlay.isActiveAt(12_500L))
        assertTrue(overlay.isActiveAt(15_000L))
        assertFalse(overlay.isActiveAt(15_001L))
    }
}
