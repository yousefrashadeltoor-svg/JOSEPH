package com.alphmedia.app.core.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.alphmedia.app.core.model.AlphThemePreset
import com.alphmedia.app.core.model.RepeatModeType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.alphDataStore by preferencesDataStore(name = "alph_media_preferences")

data class UserAppSettings(
    val themePresetId: String = AlphThemePreset.OBSIDIAN_BLACK.id,
    val customPrimaryHex: Long = 0xFF6366F1,
    val customSecondaryHex: Long = 0xFF818CF8,
    val cornerRadiusDp: Int = 22,
    val dynamicArtworkColors: Boolean = true,
    val reducedMotion: Boolean = false,
    val languageCode: String = "en",
    val repeatMode: RepeatModeType = RepeatModeType.OFF,
    val repeatTargetCount: Int = 2,
    val defaultPlaybackSpeed: Float = 1.0f,
    val enableVerticalBrightnessGesture: Boolean = true,
    val enableVerticalVolumeGesture: Boolean = true,
    val enableHorizontalSeekGesture: Boolean = true,
    val enableDoubleTapSeek: Boolean = true,
    val seekIncrementSec: Int = 10,
    val pauseOnHeadphoneDisconnect: Boolean = true,
    val resumeOnHeadphoneReconnect: Boolean = false,
    val defaultExportResolution: String = "1080p",
    val autosaveDrafts: Boolean = true
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val THEME_PRESET = stringPreferencesKey("theme_preset_id")
        val CUSTOM_PRIMARY = longPreferencesKey("custom_primary_hex")
        val CUSTOM_SECONDARY = longPreferencesKey("custom_secondary_hex")
        val CORNER_RADIUS = intPreferencesKey("corner_radius_dp")
        val DYNAMIC_ARTWORK = booleanPreferencesKey("dynamic_artwork_colors")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val REPEAT_MODE = stringPreferencesKey("repeat_mode")
        val REPEAT_TARGET_COUNT = intPreferencesKey("repeat_target_count")
        val PLAYBACK_SPEED = floatPreferencesKey("default_playback_speed")
        val GESTURE_BRIGHTNESS = booleanPreferencesKey("gesture_brightness")
        val GESTURE_VOLUME = booleanPreferencesKey("gesture_volume")
        val GESTURE_SEEK = booleanPreferencesKey("gesture_seek")
        val DOUBLE_TAP_SEEK = booleanPreferencesKey("double_tap_seek")
        val SEEK_INCREMENT = intPreferencesKey("seek_increment_sec")
        val PAUSE_ON_DISCONNECT = booleanPreferencesKey("pause_on_disconnect")
        val RESUME_ON_RECONNECT = booleanPreferencesKey("resume_on_reconnect")
        val EXPORT_RESOLUTION = stringPreferencesKey("default_export_resolution")
        val AUTOSAVE_DRAFTS = booleanPreferencesKey("autosave_drafts")
    }

    val settingsFlow: Flow<UserAppSettings> = context.alphDataStore.data.map { prefs ->
        UserAppSettings(
            themePresetId = prefs[Keys.THEME_PRESET] ?: AlphThemePreset.OBSIDIAN_BLACK.id,
            customPrimaryHex = prefs[Keys.CUSTOM_PRIMARY] ?: 0xFF6366F1,
            customSecondaryHex = prefs[Keys.CUSTOM_SECONDARY] ?: 0xFF818CF8,
            cornerRadiusDp = prefs[Keys.CORNER_RADIUS] ?: 22,
            dynamicArtworkColors = prefs[Keys.DYNAMIC_ARTWORK] ?: true,
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
            languageCode = prefs[Keys.LANGUAGE_CODE] ?: "en",
            repeatMode = runCatching {
                RepeatModeType.valueOf(prefs[Keys.REPEAT_MODE] ?: RepeatModeType.OFF.name)
            }.getOrDefault(RepeatModeType.OFF),
            repeatTargetCount = (prefs[Keys.REPEAT_TARGET_COUNT] ?: 2).coerceAtLeast(2),
            defaultPlaybackSpeed = prefs[Keys.PLAYBACK_SPEED] ?: 1.0f,
            enableVerticalBrightnessGesture = prefs[Keys.GESTURE_BRIGHTNESS] ?: true,
            enableVerticalVolumeGesture = prefs[Keys.GESTURE_VOLUME] ?: true,
            enableHorizontalSeekGesture = prefs[Keys.GESTURE_SEEK] ?: true,
            enableDoubleTapSeek = prefs[Keys.DOUBLE_TAP_SEEK] ?: true,
            seekIncrementSec = prefs[Keys.SEEK_INCREMENT] ?: 10,
            pauseOnHeadphoneDisconnect = prefs[Keys.PAUSE_ON_DISCONNECT] ?: true,
            resumeOnHeadphoneReconnect = prefs[Keys.RESUME_ON_RECONNECT] ?: false,
            defaultExportResolution = prefs[Keys.EXPORT_RESOLUTION] ?: "1080p",
            autosaveDrafts = prefs[Keys.AUTOSAVE_DRAFTS] ?: true
        )
    }

    suspend fun setThemePreset(presetId: String) {
        context.alphDataStore.edit { it[Keys.THEME_PRESET] = presetId }
    }

    suspend fun setCustomAccents(primaryHex: Long, secondaryHex: Long) {
        context.alphDataStore.edit {
            it[Keys.CUSTOM_PRIMARY] = primaryHex
            it[Keys.CUSTOM_SECONDARY] = secondaryHex
        }
    }

    suspend fun setLanguage(languageCode: String) {
        context.alphDataStore.edit { it[Keys.LANGUAGE_CODE] = languageCode }
    }

    suspend fun setRepeatConfiguration(mode: RepeatModeType, targetCount: Int) {
        context.alphDataStore.edit {
            it[Keys.REPEAT_MODE] = mode.name
            it[Keys.REPEAT_TARGET_COUNT] = targetCount.coerceAtLeast(2)
        }
    }

    suspend fun setPlaybackSpeed(speed: Float) {
        context.alphDataStore.edit { it[Keys.PLAYBACK_SPEED] = speed.coerceIn(0.5f, 2.0f) }
    }
}
