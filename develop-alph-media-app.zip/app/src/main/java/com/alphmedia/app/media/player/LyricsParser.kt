package com.alphmedia.app.media.player

import com.alphmedia.app.core.model.LrcLyricLine

object LyricsParser {

    private val TIME_TAG_REGEX = Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?]""")

    fun parseLrc(rawContent: String, syncOffsetMs: Long = 0L): List<LrcLyricLine> {
        if (rawContent.isBlank()) return emptyList()
        val parsedLines = mutableListOf<LrcLyricLine>()

        rawContent.lineSequence().forEach { line ->
            val matches = TIME_TAG_REGEX.findAll(line).toList()
            if (matches.isNotEmpty()) {
                val lyricText = line.replace(TIME_TAG_REGEX, "").trim()
                for (match in matches) {
                    val minutes = match.groupValues[1].toLongOrNull() ?: 0L
                    val seconds = match.groupValues[2].toLongOrNull() ?: 0L
                    val fractionRaw = match.groupValues.getOrNull(3) ?: "0"
                    val millis = when (fractionRaw.length) {
                        1 -> (fractionRaw.toLongOrNull() ?: 0L) * 100L
                        2 -> (fractionRaw.toLongOrNull() ?: 0L) * 10L
                        else -> fractionRaw.take(3).toLongOrNull() ?: 0L
                    }
                    val totalMs = ((minutes * 60_000L) + (seconds * 1_000L) + millis + syncOffsetMs)
                        .coerceAtLeast(0L)
                    parsedLines.add(LrcLyricLine(timestampMs = totalMs, text = lyricText))
                }
            }
        }
        return parsedLines.sortedBy { it.timestampMs }
    }

    fun findActiveLineIndex(lines: List<LrcLyricLine>, currentPositionMs: Long): Int {
        if (lines.isEmpty()) return -1
        var activeIndex = -1
        for (i in lines.indices) {
            if (currentPositionMs >= lines[i].timestampMs) {
                activeIndex = i
            } else {
                break
            }
        }
        return activeIndex
    }
}
