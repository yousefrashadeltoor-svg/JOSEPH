package com.alphmedia.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.alphmedia.app.core.database.AlphDatabase
import com.alphmedia.app.core.datastore.UserPreferencesRepository

class AlphMediaApplication : Application(), ImageLoaderFactory {

    lateinit var database: AlphDatabase
        private set

    lateinit var preferencesRepository: UserPreferencesRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = AlphDatabase.getInstance(this)
        preferencesRepository = UserPreferencesRepository(this)
        createNotificationChannels()
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.20) // Bounded 20% RAM ceiling for smooth performance on low-memory devices
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("alph_media_thumbs"))
                    .maxSizeBytes(120L * 1024L * 1024L) // Bounded 120MB thumbnail cache
                    .build()
            }
            .crossfade(true)
            .respectCacheHeaders(false)
            .build()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val playbackChannel = NotificationChannel(
                CHANNEL_PLAYBACK_ID,
                "ALPH Media Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background audio and video playback controls"
                setShowBadge(false)
            }
            val exportChannel = NotificationChannel(
                CHANNEL_EXPORT_ID,
                "Media Studio Export",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Progress notifications for video, audio, and ringtone exports"
            }
            manager?.createNotificationChannels(listOf(playbackChannel, exportChannel))
        }
    }

    companion object {
        const val CHANNEL_PLAYBACK_ID = "alph_media_playback_channel"
        const val CHANNEL_EXPORT_ID = "alph_media_export_channel"
    }
}
