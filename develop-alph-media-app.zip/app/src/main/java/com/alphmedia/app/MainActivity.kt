package com.alphmedia.app

import android.Manifest
import android.app.PictureInPictureParams
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alphmedia.app.core.datastore.UserAppSettings
import com.alphmedia.app.core.designsystem.AlphBottomTaskbarWithMiniPlayer
import com.alphmedia.app.core.designsystem.AlphDestination
import com.alphmedia.app.core.designsystem.AlphMediaTheme
import com.alphmedia.app.core.designsystem.LocalAlphColors
import com.alphmedia.app.core.model.AlphThemePreset
import com.alphmedia.app.core.model.AudioTrack
import com.alphmedia.app.core.model.PhotoItem
import com.alphmedia.app.core.model.RepeatConfiguration
import com.alphmedia.app.core.model.RepeatModeType
import com.alphmedia.app.core.model.TimedTextOverlay
import com.alphmedia.app.core.model.VideoItem
import com.alphmedia.app.media.library.MediaStoreScanner
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as AlphMediaApplication
        val scanner = MediaStoreScanner(this)

        setContent {
            val settings by app.preferencesRepository.settingsFlow.collectAsState(initial = UserAppSettings())
            val coroutineScope = rememberCoroutineScope()

            var currentDestination by remember { mutableStateOf(AlphDestination.HOME) }
            var audioTracks by remember { mutableStateOf<List<AudioTrack>>(emptyList()) }
            var videoItems by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
            var photoItems by remember { mutableStateOf<List<PhotoItem>>(emptyList()) }

            var activeTrack by remember { mutableStateOf<AudioTrack?>(null) }
            var isPlaying by remember { mutableStateOf(false) }
            var playbackProgress by remember { mutableFloatStateOf(0.32f) }
            var playbackSpeed by remember { mutableFloatStateOf(settings.defaultPlaybackSpeed) }
            var repeatConfig by remember {
                mutableStateOf(
                    RepeatConfiguration(
                        mode = settings.repeatMode,
                        targetPlayCount = settings.repeatTargetCount,
                        currentPlayIteration = 1
                    )
                )
            }

            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) {
                coroutineScope.launch {
                    audioTracks = scanner.scanAudioTracks()
                    videoItems = scanner.scanVideos()
                    photoItems = scanner.scanPhotos()
                }
            }

            LaunchedEffect(Unit) {
                val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    arrayOf(
                        Manifest.permission.READ_MEDIA_AUDIO,
                        Manifest.permission.READ_MEDIA_VIDEO,
                        Manifest.permission.READ_MEDIA_IMAGES,
                        Manifest.permission.POST_NOTIFICATIONS
                    )
                } else {
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
                permissionLauncher.launch(permissions)
            }

            AlphMediaTheme(settings = settings) {
                val colors = LocalAlphColors.current
                val isArabic = settings.languageCode == "ar"

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(colors.backgroundDeep),
                    containerColor = colors.backgroundDeep,
                    bottomBar = {
                        AlphBottomTaskbarWithMiniPlayer(
                            currentDestination = currentDestination,
                            isArabic = isArabic,
                            activeTrack = activeTrack,
                            isPlaying = isPlaying,
                            playbackProgress = playbackProgress,
                            repeatConfig = repeatConfig,
                            onSelectDestination = { currentDestination = it },
                            onTogglePlayPause = { isPlaying = !isPlaying },
                            onSkipNext = {
                                if (audioTracks.isNotEmpty()) {
                                    val idx = audioTracks.indexOf(activeTrack)
                                    activeTrack = audioTracks[(idx + 1) % audioTracks.size]
                                }
                            },
                            onExpandFullPlayer = { currentDestination = AlphDestination.MUSIC }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .statusBarsPadding()
                            .padding(innerPadding)
                    ) {
                        when (currentDestination) {
                            AlphDestination.HOME -> AlphHomeDashboardSection(
                                audioTracks = audioTracks,
                                videoItems = videoItems,
                                photoItems = photoItems,
                                isArabic = isArabic,
                                onSelectTrack = {
                                    activeTrack = it
                                    isPlaying = true
                                },
                                onOpenStudio = { currentDestination = AlphDestination.STUDIO }
                            )
                            AlphDestination.MUSIC -> AlphMusicPlayerSection(
                                tracks = audioTracks,
                                activeTrack = activeTrack,
                                isPlaying = isPlaying,
                                playbackSpeed = playbackSpeed,
                                repeatConfig = repeatConfig,
                                onSelectTrack = {
                                    activeTrack = it
                                    isPlaying = true
                                },
                                onUpdateRepeat = { mode, count ->
                                    repeatConfig = RepeatConfiguration(mode, count, 1)
                                    coroutineScope.launch {
                                        app.preferencesRepository.setRepeatConfiguration(mode, count)
                                    }
                                },
                                onUpdateSpeed = { speed ->
                                    playbackSpeed = speed
                                    coroutineScope.launch {
                                        app.preferencesRepository.setPlaybackSpeed(speed)
                                    }
                                }
                            )
                            AlphDestination.VIDEO, AlphDestination.GALLERY, AlphDestination.STUDIO, AlphDestination.FILES -> {
                                AlphCreativeStudioAndLibrarySection(
                                    destination = currentDestination,
                                    isArabic = isArabic
                                )
                            }
                            AlphDestination.SETTINGS -> AlphSettingsSection(
                                settings = settings,
                                onSelectTheme = { id ->
                                    coroutineScope.launch { app.preferencesRepository.setThemePreset(id) }
                                },
                                onToggleLanguage = {
                                    val nextLang = if (settings.languageCode == "ar") "en" else "ar"
                                    coroutineScope.launch { app.preferencesRepository.setLanguage(nextLang) }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    fun enterVideoPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }
}

@Composable
private fun AlphHomeDashboardSection(
    audioTracks: List<AudioTrack>,
    videoItems: List<VideoItem>,
    photoItems: List<PhotoItem>,
    isArabic: Boolean,
    onSelectTrack: (AudioTrack) -> Unit,
    onOpenStudio: () -> Unit
) {
    val colors = LocalAlphColors.current
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isArabic) "ALPH Media" else "ALPH Media",
                color = colors.textPrimary,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (isArabic) {
                    "المشغل الشامل واستوديو تحرير الوسائط الاحترافي"
                } else {
                    "All-in-One Media Player, Gallery & Professional Studio"
                },
                color = colors.textSecondary,
                fontSize = 14.sp
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatSummaryCard(
                    title = if (isArabic) "المقاطع الصوتية" else "Audio Tracks",
                    count = audioTracks.size.toString(),
                    modifier = Modifier.weight(1f)
                )
                StatSummaryCard(
                    title = if (isArabic) "الفيديوهات" else "Videos",
                    count = videoItems.size.toString(),
                    modifier = Modifier.weight(1f)
                )
                StatSummaryCard(
                    title = if (isArabic) "الصور" else "Photos",
                    count = photoItems.size.toString(),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(colors.surfaceCard)
                    .border(1.dp, colors.subtleBorder, RoundedCornerShape(22.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = if (isArabic) "استوديو التحرير السريع" else "Quick Creative Studio",
                    color = colors.textPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 17.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = onOpenStudio) {
                    Text(
                        text = if (isArabic) {
                            "فتح محرر الفيديو والصوت والصور وصانع النغمات"
                        } else {
                            "Open Video Editor, Ringtone Creator & Photo Studio"
                        }
                    )
                }
            }
        }

        items(audioTracks.take(15)) { track ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(colors.surfaceCard)
                    .clickable { onSelectTrack(track) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = track.title, color = colors.textPrimary, fontWeight = FontWeight.Medium)
                    Text(text = "${track.artist} • ${track.album}", color = colors.textSecondary, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun StatSummaryCard(title: String, count: String, modifier: Modifier = Modifier) {
    val colors = LocalAlphColors.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(colors.surfaceCard)
            .border(1.dp, colors.subtleBorder, RoundedCornerShape(18.dp))
            .padding(14.dp)
    ) {
        Text(text = count, color = colors.primaryAccent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(text = title, color = colors.textSecondary, fontSize = 12.sp)
    }
}

@Composable
private fun AlphMusicPlayerSection(
    tracks: List<AudioTrack>,
    activeTrack: AudioTrack?,
    isPlaying: Boolean,
    playbackSpeed: Float,
    repeatConfig: RepeatConfiguration,
    onSelectTrack: (AudioTrack) -> Unit,
    onUpdateRepeat: (RepeatModeType, Int) -> Unit,
    onUpdateSpeed: (Float) -> Unit
) {
    val colors = LocalAlphColors.current
    var customRepeatCount by remember { mutableIntStateOf(repeatConfig.targetPlayCount) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Music Player & Repeat N-Times Engine",
            color = colors.textPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Repeat Count Mode: Selected number means TOTAL PLAYS of the track before advancing to the next song.",
            color = colors.textSecondary,
            fontSize = 12.sp
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Button(onClick = { onUpdateRepeat(RepeatModeType.OFF, 2) }) { Text("Repeat Off") }
            }
            item {
                Button(onClick = { onUpdateRepeat(RepeatModeType.COUNT_TOTAL_PLAYS, 2) }) { Text("2x Total Plays") }
            }
            item {
                Button(onClick = { onUpdateRepeat(RepeatModeType.COUNT_TOTAL_PLAYS, 3) }) { Text("3x Total Plays") }
            }
            item {
                Button(onClick = { onUpdateRepeat(RepeatModeType.COUNT_TOTAL_PLAYS, 4) }) { Text("4x Total Plays") }
            }
            item {
                Button(onClick = {
                    customRepeatCount = (customRepeatCount + 1).coerceAtMost(20)
                    onUpdateRepeat(RepeatModeType.COUNT_TOTAL_PLAYS, customRepeatCount)
                }) {
                    Text("Custom (${customRepeatCount}x)")
                }
            }
        }

        Text(
            text = "Playback Speed: ${"%.2f".format(playbackSpeed)}x",
            color = colors.textPrimary,
            fontWeight = FontWeight.Medium
        )
        Slider(
            value = playbackSpeed,
            onValueChange = onUpdateSpeed,
            valueRange = 0.5f..2.0f
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tracks) { track ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (track == activeTrack) colors.surfaceElevated else colors.surfaceCard)
                        .clickable { onSelectTrack(track) }
                        .padding(14.dp)
                ) {
                    Column {
                        Text(text = track.title, color = colors.textPrimary, fontWeight = FontWeight.SemiBold)
                        Text(text = track.artist, color = colors.textSecondary, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun AlphCreativeStudioAndLibrarySection(
    destination: AlphDestination,
    isArabic: Boolean
) {
    val colors = LocalAlphColors.current
    var timedSegments by remember {
        mutableStateOf(
            listOf(
                TimedTextOverlay(
                    id = "seg_1",
                    text = "Intro Title (0s - 4s)",
                    startTimeMs = 0L,
                    endTimeMs = 4000L
                ),
                TimedTextOverlay(
                    id = "seg_2",
                    text = "Main Highlight Caption (10s - 15s)",
                    startTimeMs = 10_000L,
                    endTimeMs = 15_000L
                )
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = if (isArabic) destination.labelAr else destination.labelEn,
            color = colors.textPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Timed Text Segments on Video Timeline (${timedSegments.size} active intervals):",
            color = colors.textSecondary,
            fontSize = 13.sp
        )
        timedSegments.forEach { seg ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(colors.surfaceCard)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = seg.text, color = colors.textPrimary)
                Text(
                    text = "${seg.startTimeMs / 1000}s – ${seg.endTimeMs / 1000}s",
                    color = colors.primaryAccent,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun AlphSettingsSection(
    settings: UserAppSettings,
    onSelectTheme: (String) -> Unit,
    onToggleLanguage: () -> Unit
) {
    val colors = LocalAlphColors.current
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Appearance, Themes & Localization",
                color = colors.textPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = onToggleLanguage) {
                Text(
                    text = if (settings.languageCode == "ar") {
                        "Switch to English (LTR)"
                    } else {
                        "التبديل إلى العربية (RTL)"
                    }
                )
            }
        }

        items(AlphThemePreset.entries) { preset ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(colors.surfaceCard)
                    .border(
                        width = if (settings.themePresetId == preset.id) 2.dp else 1.dp,
                        color = if (settings.themePresetId == preset.id) colors.primaryAccent else colors.subtleBorder,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .clickable { onSelectTheme(preset.id) }
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = preset.displayNameEn, color = colors.textPrimary, fontWeight = FontWeight.SemiBold)
                    Text(text = preset.displayNameAr, color = colors.textSecondary, fontSize = 12.sp)
                }
            }
        }
    }
}
