package com.alphmedia.app.core.database

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(
    tableName = "favorite_media",
    indices = [Index(value = ["mediaUri"], unique = true), Index(value = ["mediaType"])]
)
data class FavoriteMediaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mediaId: Long,
    val mediaUri: String,
    val mediaType: String, // "AUDIO", "VIDEO", "PHOTO"
    val title: String,
    val subtitle: String,
    val addedTimestampMs: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playback_stats",
    indices = [Index(value = ["playCount"]), Index(value = ["lastPlayedTimestampMs"])]
)
data class PlaybackStatsEntity(
    @PrimaryKey val mediaId: Long,
    val mediaUri: String,
    val mediaType: String,
    val title: String,
    val playCount: Int = 0,
    val lastPositionMs: Long = 0L,
    val lastPlayedTimestampMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val playlistId: Long = 0,
    val name: String,
    val createdAtMs: Long = System.currentTimeMillis(),
    val trackIdsCsv: String = ""
)

@Entity(tableName = "editor_drafts")
data class EditorDraftEntity(
    @PrimaryKey val draftId: String,
    val projectType: String, // "VIDEO", "PHOTO", "RINGTONE"
    val title: String,
    val sourceUri: String,
    val stateJson: String,
    val updatedAtMs: Long = System.currentTimeMillis()
)

@Dao
interface AlphMediaDao {
    @Query("SELECT * FROM favorite_media ORDER BY addedTimestampMs DESC")
    fun observeFavorites(): Flow<List<FavoriteMediaEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFavorite(entity: FavoriteMediaEntity)

    @Query("DELETE FROM favorite_media WHERE mediaId = :mediaId AND mediaType = :mediaType")
    suspend fun removeFavorite(mediaId: Long, mediaType: String)

    @Query("SELECT * FROM playback_stats ORDER BY lastPlayedTimestampMs DESC LIMIT :limit")
    fun observeRecentPlayback(limit: Int = 30): Flow<List<PlaybackStatsEntity>>

    @Query("SELECT * FROM playback_stats WHERE mediaType = 'AUDIO' ORDER BY playCount DESC LIMIT :limit")
    fun observeMostPlayedTracks(limit: Int = 50): Flow<List<PlaybackStatsEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPlaybackStat(stat: PlaybackStatsEntity)

    @Query("SELECT * FROM playlists ORDER BY createdAtMs DESC")
    fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlaylist(playlist: PlaylistEntity): Long

    @Query("SELECT * FROM editor_drafts ORDER BY updatedAtMs DESC")
    fun observeDrafts(): Flow<List<EditorDraftEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveDraft(draft: EditorDraftEntity)

    @Query("DELETE FROM editor_drafts WHERE draftId = :draftId")
    suspend fun deleteDraft(draftId: String)

    @Query("DELETE FROM playback_stats")
    suspend fun clearHistory()
}

@Database(
    entities = [
        FavoriteMediaEntity::class,
        PlaybackStatsEntity::class,
        PlaylistEntity::class,
        EditorDraftEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AlphDatabase : RoomDatabase() {
    abstract fun mediaDao(): AlphMediaDao

    companion object {
        @Volatile
        private var INSTANCE: AlphDatabase? = null

        fun getInstance(context: Context): AlphDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AlphDatabase::class.java,
                    "alph_media_library.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
