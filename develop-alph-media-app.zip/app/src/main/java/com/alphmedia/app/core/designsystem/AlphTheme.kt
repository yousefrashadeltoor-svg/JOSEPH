package com.alphmedia.app.core.designsystem

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alphmedia.app.core.datastore.UserAppSettings
import com.alphmedia.app.core.model.AlphThemePreset

data class AlphExtendedColors(
    val preset: AlphThemePreset,
    val primaryAccent: Color,
    val secondaryAccent: Color,
    val backgroundDeep: Color,
    val surfaceCard: Color,
    val surfaceElevated: Color,
    val subtleBorder: Color,
    val textPrimary: Color,
    val textSecondary: Color
)

val LocalAlphColors = staticCompositionLocalOf {
    AlphExtendedColors(
        preset = AlphThemePreset.OBSIDIAN_BLACK,
        primaryAccent = Color(0xFF6366F1),
        secondaryAccent = Color(0xFF818CF8),
        backgroundDeep = Color(0xFF05070B),
        surfaceCard = Color(0xFF0F131D),
        surfaceElevated = Color(0xFF171D2B),
        subtleBorder = Color(0x22FFFFFF),
        textPrimary = Color(0xFFF8FAFC),
        textSecondary = Color(0xFF94A3B8)
    )
}

@Composable
fun AlphMediaTheme(
    settings: UserAppSettings,
    dynamicArtworkAccent: Color? = null,
    content: @Composable () -> Unit
) {
    val preset = AlphThemePreset.entries.find { it.id == settings.themePresetId }
        ?: AlphThemePreset.OBSIDIAN_BLACK

    val basePrimary = if (preset == AlphThemePreset.CUSTOM_ACCENT) {
        Color(settings.customPrimaryHex)
    } else {
        Color(preset.primaryHex)
    }

    val activePrimary = if (settings.dynamicArtworkColors && dynamicArtworkAccent != null) {
        dynamicArtworkAccent
    } else {
        basePrimary
    }

    val activeSecondary = if (preset == AlphThemePreset.CUSTOM_ACCENT) {
        Color(settings.customSecondaryHex)
    } else {
        Color(preset.secondaryHex)
    }

    val bg = Color(preset.backgroundHex)
    val surface = Color(preset.surfaceHex)
    val elevated = Color(preset.elevatedSurfaceHex)

    val extendedColors = AlphExtendedColors(
        preset = preset,
        primaryAccent = activePrimary,
        secondaryAccent = activeSecondary,
        backgroundDeep = bg,
        surfaceCard = surface,
        surfaceElevated = elevated,
        subtleBorder = if (preset.isDark) Color(0x1FFFFFFF) else Color(0x180F172A),
        textPrimary = if (preset.isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A),
        textSecondary = if (preset.isDark) Color(0xFF94A3B8) else Color(0xFF475569)
    )

    val colorScheme: ColorScheme = if (preset.isDark) {
        darkColorScheme(
            primary = activePrimary,
            secondary = activeSecondary,
            background = bg,
            surface = surface,
            surfaceVariant = elevated,
            onPrimary = Color.White,
            onBackground = extendedColors.textPrimary,
            onSurface = extendedColors.textPrimary
        )
    } else {
        lightColorScheme(
            primary = activePrimary,
            secondary = activeSecondary,
            background = bg,
            surface = surface,
            surfaceVariant = elevated,
            onPrimary = Color.White,
            onBackground = extendedColors.textPrimary,
            onSurface = extendedColors.textPrimary
        )
    }

    val radius = settings.cornerRadiusDp.dp
    val shapes = Shapes(
        small = RoundedCornerShape((settings.cornerRadiusDp / 2).dp),
        medium = RoundedCornerShape(radius),
        large = RoundedCornerShape((settings.cornerRadiusDp + 6).dp)
    )

    val typography = Typography(
        headlineLarge = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Bold,
            fontSize = 28.sp,
            lineHeight = 36.sp
        ),
        titleLarge = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.SemiBold,
            fontSize = 20.sp,
            lineHeight = 28.sp
        ),
        bodyLarge = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Normal,
            fontSize = 15.sp,
            lineHeight = 22.sp
        ),
        labelMedium = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp,
            lineHeight = 16.sp
        )
    )

    val layoutDirection = if (settings.languageCode == "ar") {
        LayoutDirection.Rtl
    } else {
        LayoutDirection.Ltr
    }

    CompositionLocalProvider(
        LocalAlphColors provides extendedColors,
        LocalLayoutDirection provides layoutDirection
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            shapes = shapes,
            typography = typography,
            content = content
        )
    }
}
