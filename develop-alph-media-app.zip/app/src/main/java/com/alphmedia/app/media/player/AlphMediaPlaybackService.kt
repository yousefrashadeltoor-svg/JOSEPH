package com.alphmedia.app.media.player

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.alphmedia.app.AlphMediaApplication
import com.alphmedia.app.MainActivity
import com.alphmedia.app.core.model.RepeatConfiguration
import com.alphmedia.app.core.model.RepeatModeType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AlphMediaPlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var sleepTimerJob: Job? = null

    private val _repeatConfig = MutableStateFlow(RepeatConfiguration())
    val repeatConfig: StateFlow<RepeatConfiguration> = _repeatConfig.asStateFlow()

    private val _sleepTimerRemainingSec = MutableStateFlow(0L)
    val sleepTimerRemainingSec: StateFlow<Long> = _sleepTimerRemainingSec.asStateFlow()

    private val noisyAudioReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                if (::player.isInitialized && player.isPlaying) {
                    player.pause()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()

        val audioAttributes = AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(C.USAGE_MEDIA)
            .build()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) {
                    handleTrackRepeatTransition()
                } else {
                    // Reset iteration counter to 1 when switching to a new track
                    _repeatConfig.value = _repeatConfig.value.copy(currentPlayIteration = 1)
                }
            }
        })

        val sessionActivityPendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivityPendingIntent)
            .build()

        setMediaNotificationProvider(
            DefaultMediaNotificationProvider.Builder(this)
                .setChannelId(AlphMediaApplication.CHANNEL_PLAYBACK_ID)
                .build()
        )

        registerReceiver(
            noisyAudioReceiver,
            IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        )
    }

    /**
     * Real Repeat N-Times Engine:
     * When RepeatModeType.COUNT_TOTAL_PLAYS is active, ExoPlayer is set to REPEAT_MODE_ONE
     * while currentPlayIteration < targetPlayCount. Once the target number of total plays
     * is reached, the engine resets the counter and advances to the next track in the queue.
     */
    fun configureRepeatMode(mode: RepeatModeType, targetTotalPlays: Int = 2) {
        val sanitizedCount = targetTotalPlays.coerceAtLeast(2)
        _repeatConfig.value = RepeatConfiguration(
            mode = mode,
            targetPlayCount = sanitizedCount,
            currentPlayIteration = 1
        )
        when (mode) {
            RepeatModeType.OFF -> player.repeatMode = Player.REPEAT_MODE_OFF
            RepeatModeType.ONE_FOREVER -> player.repeatMode = Player.REPEAT_MODE_ONE
            RepeatModeType.ALL_QUEUE, RepeatModeType.CURRENT_PLAYLIST -> {
                player.repeatMode = Player.REPEAT_MODE_ALL
            }
            RepeatModeType.COUNT_TOTAL_PLAYS -> {
                player.repeatMode = Player.REPEAT_MODE_ONE
            }
        }
    }

    private fun handleTrackRepeatTransition() {
        val current = _repeatConfig.value
        if (current.mode == RepeatModeType.COUNT_TOTAL_PLAYS) {
            val nextIteration = current.currentPlayIteration + 1
            if (nextIteration > current.targetPlayCount) {
                // Reached target play count: reset counter and advance to next track
                _repeatConfig.value = current.copy(currentPlayIteration = 1)
                if (player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                } else {
                    player.pause()
                    player.seekTo(0L)
                }
            } else {
                _repeatConfig.value = current.copy(currentPlayIteration = nextIteration)
            }
        }
    }

    /**
     * Background-safe Sleep Timer with optional gradual volume fade-out.
     */
    fun startSleepTimer(durationMinutes: Int, fadeOutSeconds: Int = 15) {
        sleepTimerJob?.cancel()
        val totalSeconds = (durationMinutes * 60L).coerceAtLeast(1L)
        _sleepTimerRemainingSec.value = totalSeconds

        sleepTimerJob = serviceScope.launch {
            val initialVolume = player.volume
            while (_sleepTimerRemainingSec.value > 0) {
                delay(1000L)
                val remaining = _sleepTimerRemainingSec.value - 1
                _sleepTimerRemainingSec.value = remaining

                if (fadeOutSeconds > 0 && remaining in 1..fadeOutSeconds) {
                    val ratio = remaining.toFloat() / fadeOutSeconds.toFloat()
                    player.volume = (initialVolume * ratio).coerceIn(0.02f, 1.0f)
                }
            }
            player.pause()
            player.volume = initialVolume
        }
    }

    fun addSleepTimerMinutes(extraMinutes: Int) {
        if (_sleepTimerRemainingSec.value > 0) {
            _sleepTimerRemainingSec.value += (extraMinutes * 60L)
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _sleepTimerRemainingSec.value = 0L
        player.volume = 1.0f
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(noisyAudioReceiver) }
        sleepTimerJob?.cancel()
        serviceScope.cancel()
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
