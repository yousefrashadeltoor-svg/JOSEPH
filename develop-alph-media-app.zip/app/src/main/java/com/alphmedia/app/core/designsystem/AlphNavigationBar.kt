package com.alphmedia.app.core.designsystem

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alphmedia.app.core.model.AudioTrack
import com.alphmedia.app.core.model.RepeatConfiguration
import com.alphmedia.app.core.model.RepeatModeType

enum class AlphDestination(
    val route: String,
    val labelEn: String,
    val labelAr: String,
    val icon: ImageVector
) {
    HOME("home", "Home", "الرئيسية", Icons.Rounded.Home),
    MUSIC("music", "Music", "الموسيقى", Icons.Rounded.MusicNote),
    VIDEO("video", "Video", "الفيديو", Icons.Rounded.VideoLibrary),
    GALLERY("gallery", "Gallery", "المعرض", Icons.Rounded.PhotoLibrary),
    STUDIO("studio", "Studio", "الاستوديو", Icons.Rounded.AutoFixHigh),
    FILES("files", "Files", "الملفات", Icons.Rounded.Folder),
    SETTINGS("settings", "Settings", "الإعدادات", Icons.Rounded.Settings)
}

@Composable
fun AlphBottomTaskbarWithMiniPlayer(
    currentDestination: AlphDestination,
    isArabic: Boolean,
    activeTrack: AudioTrack?,
    isPlaying: Boolean,
    playbackProgress: Float,
    repeatConfig: RepeatConfiguration,
    onSelectDestination: (AlphDestination) -> Unit,
    onTogglePlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onExpandFullPlayer: () -> Unit
) {
    val colors = LocalAlphColors.current
    val shape = RoundedCornerShape(26.dp)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // Floating Mini-Player
        AnimatedVisibility(
            visible = activeTrack != null,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            activeTrack?.let { track ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(colors.surfaceElevated)
                        .border(1.dp, colors.primaryAccent.copy(alpha = 0.35f), RoundedCornerShape(22.dp))
                        .clickable { onExpandFullPlayer() }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(colors.primaryAccent.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.MusicNote,
                                contentDescription = null,
                                tint = colors.primaryAccent
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = track.title,
                                color = colors.textPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val repeatBadge = if (repeatConfig.mode == RepeatModeType.COUNT_TOTAL_PLAYS) {
                                " • Play ${repeatConfig.currentPlayIteration}/${repeatConfig.targetPlayCount}"
                            } else ""
                            Text(
                                text = "${track.artist}$repeatBadge",
                                color = colors.textSecondary,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = onTogglePlayPause) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = colors.primaryAccent
                            )
                        }
                        IconButton(onClick = onSkipNext) {
                            Icon(
                                imageVector = Icons.Rounded.SkipNext,
                                contentDescription = "Next",
                                tint = colors.textPrimary
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { playbackProgress.coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(CircleShape),
                        color = colors.primaryAccent,
                        trackColor = colors.subtleBorder
                    )
                }
            }
        }

        // Refined Rounded Navigation Taskbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
                .clip(shape)
                .background(colors.surfaceCard)
                .border(1.dp, colors.subtleBorder, shape)
                .padding(horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlphDestination.entries.forEach { destination ->
                val selected = destination == currentDestination
                val pillColor by animateColorAsState(
                    targetValue = if (selected) colors.primaryAccent.copy(alpha = 0.18f) else colors.surfaceCard,
                    label = "navPill"
                )
                val contentColor by animateColorAsState(
                    targetValue = if (selected) colors.primaryAccent else colors.textSecondary,
                    label = "navContent"
                )

                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(pillColor)
                        .clickable { onSelectDestination(destination) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = destination.icon,
                        contentDescription = if (isArabic) destination.labelAr else destination.labelEn,
                        tint = contentColor,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (isArabic) destination.labelAr else destination.labelEn,
                        color = contentColor,
                        fontSize = 10.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
