package com.alphmedia.app.ui.video

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrightnessHigh
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alphmedia.app.core.designsystem.LocalAlphColors
import com.alphmedia.app.core.model.VideoItem
import kotlin.math.abs

@Composable
fun VideoPlayerScreen(
    video: VideoItem,
    isPlaying: Boolean,
    currentPositionMs: Long,
    durationMs: Long,
    playbackSpeed: Float,
    onTogglePlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSpeedChange: (Float) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val colors = LocalAlphColors.current

    var controlsVisible by remember { mutableStateOf(true) }
    var isScreenLocked by remember { mutableStateOf(false) }
    var windowBrightness by remember { mutableFloatStateOf(0.75f) }
    var volumeFraction by remember {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        mutableFloatStateOf(cur.toFloat() / max.toFloat())
    }

    var gestureOverlayText by remember { mutableStateOf<String?>(null) }
    var gestureIsBrightness by remember { mutableStateOf(false) }

    // A-B Repeat Markers
    var pointAMs by remember { mutableStateOf<Long?>(null) }
    var pointBMs by remember { mutableStateOf<Long?>(null) }
    var subtitleDelayMs by remember { mutableLongStateOf(0L) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isScreenLocked) {
                detectTapGestures(
                    onTap = { controlsVisible = !controlsVisible },
                    onDoubleTap = { offset ->
                        if (isScreenLocked) return@detectTapGestures
                        val width = size.width
                        when {
                            offset.x < width * 0.35f -> {
                                onSeekTo((currentPositionMs - 10_000L).coerceAtLeast(0L))
                                gestureOverlayText = "-10s"
                            }
                            offset.x > width * 0.65f -> {
                                onSeekTo((currentPositionMs + 10_000L).coerceAtMost(durationMs))
                                gestureOverlayText = "+10s"
                            }
                            else -> onTogglePlayPause()
                        }
                    }
                )
            }
            .pointerInput(isScreenLocked) {
                detectDragGestures(
                    onDragEnd = { gestureOverlayText = null },
                    onDragCancel = { gestureOverlayText = null },
                    onDrag = { change, dragAmount ->
                        if (isScreenLocked) return@detectDragGestures
                        change.consume()
                        val width = size.width.coerceAtLeast(1)
                        val height = size.height.coerceAtLeast(1)

                        if (abs(dragAmount.y) > abs(dragAmount.x)) {
                            // Vertical Gesture: Left = Window Brightness, Right = Stream Volume
                            val delta = -dragAmount.y / (height * 0.8f)
                            if (change.position.x < width * 0.5f) {
                                gestureIsBrightness = true
                                windowBrightness = (windowBrightness + delta).coerceIn(0.05f, 1.0f)
                                activity?.window?.let { win ->
                                    val params = win.attributes
                                    params.screenBrightness = windowBrightness
                                    win.attributes = params
                                }
                                gestureOverlayText = "Brightness ${(windowBrightness * 100).toInt()}%"
                            } else {
                                gestureIsBrightness = false
                                volumeFraction = (volumeFraction + delta).coerceIn(0f, 1f)
                                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                audioManager.setStreamVolume(
                                    AudioManager.STREAM_MUSIC,
                                    (volumeFraction * maxVol).toInt(),
                                    0
                                )
                                gestureOverlayText = "Volume ${(volumeFraction * 100).toInt()}%"
                            }
                        } else {
                            // Horizontal Gesture: Fine Seek
                            val seekDeltaMs = ((dragAmount.x / width) * 90_000f).toLong()
                            val targetMs = (currentPositionMs + seekDeltaMs).coerceIn(0L, durationMs)
                            onSeekTo(targetMs)
                            val sign = if (seekDeltaMs >= 0) "+" else ""
                            gestureOverlayText = "Seek $sign${seekDeltaMs / 1000}s"
                        }
                    }
                )
            }
    ) {
        // Temporary Gesture HUD Indicator
        AnimatedVisibility(
            visible = gestureOverlayText != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xCC0F172A))
                    .border(1.dp, colors.primaryAccent, RoundedCornerShape(18.dp))
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = if (gestureIsBrightness) Icons.Rounded.BrightnessHigh else Icons.Rounded.VolumeUp,
                    contentDescription = null,
                    tint = colors.primaryAccent
                )
                Text(
                    text = gestureOverlayText ?: "",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }

        // Dedicated Screen Lock Mode Button (Always Accessible when Controls Shown)
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
        ) {
            IconButton(
                onClick = { isScreenLocked = !isScreenLocked },
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xAA0F172A))
            ) {
                Icon(
                    imageVector = if (isScreenLocked) Icons.Rounded.Lock else Icons.Rounded.LockOpen,
                    contentDescription = "Toggle Screen Lock",
                    tint = if (isScreenLocked) colors.primaryAccent else Color.White
                )
            }
        }

        // Full Bottom Playback & Subtitle Controls (Hidden when Screen Locked)
        AnimatedVisibility(
            visible = controlsVisible && !isScreenLocked,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xCC090D16))
                    .padding(16.dp)
            ) {
                Text(
                    text = video.title,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Slider(
                    value = currentPositionMs.toFloat(),
                    onValueChange = { onSeekTo(it.toLong()) },
                    valueRange = 0f..durationMs.coerceAtLeast(1L).toFloat()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onTogglePlayPause) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = {
                        if (pointAMs == null) {
                            pointAMs = currentPositionMs
                        } else if (pointBMs == null) {
                            pointBMs = currentPositionMs
                        } else {
                            pointAMs = null
                            pointBMs = null
                        }
                    }) {
                        Icon(
                            imageVector = Icons.Rounded.Repeat,
                            contentDescription = "A-B Repeat",
                            tint = if (pointAMs != null) colors.primaryAccent else Color.White
                        )
                    }
                    IconButton(onClick = {
                        val nextSpeed = when (playbackSpeed) {
                            1.0f -> 1.25f
                            1.25f -> 1.5f
                            1.5f -> 2.0f
                            else -> 1.0f
                        }
                        onSpeedChange(nextSpeed)
                    }) {
                        Icon(
                            imageVector = Icons.Rounded.Speed,
                            contentDescription = "Playback Speed",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = { subtitleDelayMs += 250L }) {
                        Icon(
                            imageVector = Icons.Rounded.Subtitles,
                            contentDescription = "Subtitle Sync",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}
