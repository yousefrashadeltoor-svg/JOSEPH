package com.alphmedia.app.core.model

import android.net.Uri

enum class AlphThemePreset(
    val id: String,
    val displayNameEn: String,
    val displayNameAr: String,
    val isDark: Boolean,
    val primaryHex: Long,
    val secondaryHex: Long,
    val backgroundHex: Long,
    val surfaceHex: Long,
    val elevatedSurfaceHex: Long
) {
    OBSIDIAN_BLACK("obsidian_black", "Obsidian Black", "أسود سبجي", true, 0xFF6366F1, 0xFF818CF8, 0xFF05070B, 0xFF0F131D, 0xFF171D2B),
    MIDNIGHT_GRAPHITE("midnight_graphite", "Midnight Graphite", "جرافيت منتصف الليل", true, 0xFF38BDF8, 0xFF7DD3FC, 0xFF0B0F17, 0xFF151C28, 0xFF1E2738),
    DEEP_OCEAN("deep_ocean", "Deep Ocean", "المحيط العميق", true, 0xFF06B6D4, 0xFF22D3EE, 0xFF041019, 0xFF0A1D2C, 0xFF112A3E),
    EMERALD_NIGHT("emerald_night", "Emerald Night", "ليل زمردي", true, 0xFF10B981, 0xFF34D399, 0xFF05130E, 0xFF0B2119, 0xFF123126),
    ROYAL_PURPLE("royal_purple", "Royal Purple", "أرجواني ملكي", true, 0xFFA855F7, 0xFFC084FC, 0xFF0D0716, 0xFF180E29, 0xFF24163C),
    SOFT_TITANIUM("soft_titanium", "Soft Titanium", "تيتانيوم ناعم", true, 0xFF94A3B8, 0xFFCBD5E1, 0xFF121519, 0xFF1C2026, 0xFF262B33),
    PREMIUM_PEARL("premium_pearl", "Premium Pearl", "لؤلؤي فاخر", false, 0xFF4F46E5, 0xFF6366F1, 0xFFF8FAFC, 0xFFFFFFFF, 0xFFF1F5F9),
    WARM_LIGHT("warm_light", "Warm Light", "إضاءة دافئة", false, 0xFFD97706, 0xFFF59E0B, 0xFFFAF7F2, 0xFFFFFFFF, 0xFFF3EFE6),
    MINIMAL_MONOCHROME("minimal_monochrome", "Minimal Monochrome", "أحادي اللون بسيط", true, 0xFFF8FAFC, 0xFF94A3B8, 0xFF09090B, 0xFF141417, 0xFF1F1F23),
    CUSTOM_ACCENT("custom_accent", "Custom Accent Theme", "مظهر مخصص", true, 0xFFEC4899, 0xFFF472B6, 0xFF080A10, 0xFF121622, 0xFF1B2132)
}

/**
 * Advanced Repeat Mode supporting exact N-times track repetition.
 * Meaning is explicitly defined: [targetPlayCount] represents TOTAL PLAYS of the current track
 * before automatically advancing to the next item in the queue.
 */
enum class RepeatModeType {
    OFF,
    ONE_FOREVER,
    ALL_QUEUE,
    CURRENT_PLAYLIST,
    COUNT_TOTAL_PLAYS
}

data class RepeatConfiguration(
    val mode: RepeatModeType = RepeatModeType.OFF,
    val targetPlayCount: Int = 2, // e.g., 2, 3, 4, or custom count >= 2
    val currentPlayIteration: Int = 1 // 1-indexed current play count
) {
    val remainingPlays: Int
        get() = if (mode == RepeatModeType.COUNT_TOTAL_PLAYS) {
            (targetPlayCount - currentPlayIteration).coerceAtLeast(0)
        } else 0
}

data class AudioTrack(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val albumArtist: String = "",
    val genre: String = "Unknown",
    val durationMs: Long,
    val folderPath: String,
    val folderName: String,
    val sizeBytes: Long,
    val mimeType: String,
    val bitrateKbps: Int = 320,
    val sampleRateHz: Int = 44100,
    val year: Int = 2025,
    val trackNumber: Int = 1,
    val dateAddedSec: Long = 0L,
    val isFavorite: Boolean = false,
    val playCount: Int = 0,
    val albumArtUri: Uri? = null,
    val embeddedLyrics: String? = null
)

data class VideoItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val folderName: String,
    val mimeType: String,
    val frameRate: Float = 30f,
    val lastPositionMs: Long = 0L,
    val isFavorite: Boolean = false
)

data class PhotoItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val folderName: String,
    val dateTakenMs: Long,
    val mimeType: String,
    val cameraModel: String? = null,
    val iso: String? = null,
    val exposureTime: String? = null,
    val isFavorite: Boolean = false,
    val isHidden: Boolean = false
)

data class LrcLyricLine(
    val timestampMs: Long,
    val text: String
)

data class TimedTextOverlay(
    val id: String,
    val text: String,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val fontFamily: String = "Sans-Serif",
    val fontSizeSp: Float = 24f,
    val textColorHex: Long = 0xFFFFFFFF,
    val backgroundColorHex: Long = 0x88000000,
    val opacity: Float = 1.0f,
    val outlineWidth: Float = 2.0f,
    val hasShadow: Boolean = true,
    val normalizedX: Float = 0.5f, // 0.0..1.0 relative to video width
    val normalizedY: Float = 0.82f, // 0.0..1.0 relative to video height
    val rotationDegrees: Float = 0f
) {
    fun isActiveAt(positionMs: Long): Boolean {
        return positionMs in startTimeMs..endTimeMs
    }
}

data class VideoClipSegment(
    val id: String,
    val sourceUri: Uri,
    val title: String,
    val trimStartMs: Long,
    val trimEndMs: Long,
    val speedMultiplier: Float = 1.0f,
    val volume: Float = 1.0f,
    val isMuted: Boolean = false,
    val rotationDegrees: Int = 0,
    val flipHorizontal: Boolean = false,
    val flipVertical: Boolean = false
) {
    val effectiveDurationMs: Long
        get() = ((trimEndMs - trimStartMs).coerceAtLeast(0L) / speedMultiplier).toLong()
}

data class ColorAdjustments(
    val brightness: Float = 0f,     // -1f..1f
    val contrast: Float = 1f,       // 0.5f..2f
    val saturation: Float = 1f,     // 0f..2f
    val temperature: Float = 0f,    // -1f..1f
    val tint: Float = 0f,           // -1f..1f
    val exposure: Float = 0f,       // -1f..1f
    val highlights: Float = 0f,     // -1f..1f
    val shadows: Float = 0f,        // -1f..1f
    val sharpness: Float = 0f,      // 0f..1f
    val vignette: Float = 0f,       // 0f..1f
    val fade: Float = 0f            // 0f..1f
)

data class MediaMetadataPayload(
    val title: String,
    val artist: String,
    val album: String,
    val albumArtist: String,
    val genre: String,
    val year: String,
    val trackNumber: String,
    val discNumber: String,
    val composer: String,
    val comment: String,
    val lyrics: String,
    val newCoverBytes: ByteArray? = null,
    val removeCover: Boolean = false
)
