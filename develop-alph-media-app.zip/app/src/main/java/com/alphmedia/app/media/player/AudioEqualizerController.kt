package com.alphmedia.app.media.player

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer

data class EqualizerPresetProfile(
    val name: String,
    val bandGainsDb: List<Float>
)

class AudioEqualizerController(private val audioSessionId: Int) {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null

    var isEqualizerSupported: Boolean = false
        private set
    var isBassBoostSupported: Boolean = false
        private set
    var isVirtualizerSupported: Boolean = false
        private set

    init {
        if (audioSessionId != 0) {
            runCatching {
                equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
                isEqualizerSupported = true
            }
            runCatching {
                bassBoost = BassBoost(0, audioSessionId).apply {
                    if (strengthSupported) {
                        enabled = true
                        isBassBoostSupported = true
                    }
                }
            }
            runCatching {
                virtualizer = Virtualizer(0, audioSessionId).apply {
                    if (strengthSupported) {
                        enabled = true
                        isVirtualizerSupported = true
                    }
                }
            }
            runCatching {
                loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply { enabled = false }
            }
        }
    }

    fun applyBandLevel(bandIndex: Short, gainMillibels: Short) {
        val eq = equalizer ?: return
        val range = eq.bandLevelRange
        val clamped = gainMillibels.coerceIn(range[0], range[1])
        runCatching { eq.setBandLevel(bandIndex, clamped) }
    }

    fun setBassStrength(permille: Short) {
        if (!isBassBoostSupported) return
        runCatching { bassBoost?.setStrength(permille.coerceIn(0, 1000)) }
    }

    fun setVirtualizerStrength(permille: Short) {
        if (!isVirtualizerSupported) return
        runCatching { virtualizer?.setStrength(permille.coerceIn(0, 1000)) }
    }

    fun release() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        runCatching { loudnessEnhancer?.release() }
    }

    companion object {
        val BUILT_IN_PRESETS = listOf(
            EqualizerPresetProfile("Flat", listOf(0f, 0f, 0f, 0f, 0f)),
            EqualizerPresetProfile("Classical", listOf(4.5f, 3.5f, -1.5f, 4.0f, 5.0f)),
            EqualizerPresetProfile("Dance", listOf(6.0f, 4.5f, 1.5f, 4.0f, 3.5f)),
            EqualizerPresetProfile("Electronic", listOf(5.5f, 4.0f, 0.0f, 3.5f, 5.5f)),
            EqualizerPresetProfile("Hip-Hop", listOf(6.5f, 4.5f, 0.0f, 2.0f, 4.0f)),
            EqualizerPresetProfile("Jazz", listOf(4.0f, 2.5f, -1.5f, 2.5f, 4.5f)),
            EqualizerPresetProfile("Pop", listOf(-1.5f, 3.0f, 5.0f, 3.5f, -1.0f)),
            EqualizerPresetProfile("Rock", listOf(5.0f, 3.0f, -1.0f, 3.5f, 5.5f)),
            EqualizerPresetProfile("Vocal", listOf(-2.0f, 1.5f, 5.5f, 4.0f, 1.0f)),
            EqualizerPresetProfile("Acoustic", listOf(4.0f, 3.5f, 2.0f, 3.5f, 3.5f)),
            EqualizerPresetProfile("Custom", listOf(2.0f, 1.0f, 0.0f, 2.0f, 3.0f))
        )
    }
}
