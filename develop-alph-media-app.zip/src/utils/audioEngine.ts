export const EQ_FREQUENCIES = [60, 230, 910, 3600, 14000] as const;

export const EQ_PRESETS: Record<string, number[]> = {
  Flat: [0, 0, 0, 0, 0],
  Classical: [4.5, 3.5, -1.5, 4.0, 5.0],
  Dance: [6.0, 4.5, 1.5, 4.0, 3.5],
  Electronic: [5.5, 4.0, 0.0, 3.5, 5.5],
  'Hip-Hop': [6.5, 4.5, 0.0, 2.0, 4.0],
  Jazz: [4.0, 2.5, -1.5, 2.5, 4.5],
  Pop: [-1.5, 3.0, 5.0, 3.5, -1.0],
  Rock: [5.0, 3.0, -1.0, 3.5, 5.5],
  Vocal: [-2.0, 1.5, 5.5, 4.0, 1.0],
  Acoustic: [4.0, 3.5, 2.0, 3.5, 3.5],
  Custom: [2.0, 1.5, 0.5, 2.5, 3.5],
};

/**
 * Generates a real 16-bit PCM WAV Blob for a trimmed audio segment [startSec..endSec]
 * with configurable fade-in, fade-out, and volume normalization.
 */
export function generateTrimmedWavBlob(
  notesHz: number[],
  startSec: number,
  endSec: number,
  fadeInSec: number,
  fadeOutSec: number,
  normalize: boolean
): Blob {
  const sampleRate = 44100;
  const durationSec = Math.max(0.5, endSec - startSec);
  const numSamples = Math.floor(sampleRate * durationSec);
  const samples = new Float32Array(numSamples);

  const safeNotes = notesHz.length > 0 ? notesHz : [220, 277.18, 329.63, 440];
  let peak = 0.001;

  for (let i = 0; i < numSamples; i++) {
    const tGlobal = startSec + i / sampleRate;
    const tLocal = i / sampleRate;
    const noteIdx = Math.floor(tGlobal * 1.6) % safeNotes.length;
    const freq = safeNotes[noteIdx];

    // Warm harmonic synth tone
    const fundamental = Math.sin(2 * Math.PI * freq * tGlobal);
    const fifth = 0.35 * Math.sin(2 * Math.PI * (freq * 1.498) * tGlobal);
    const octave = 0.2 * Math.sin(2 * Math.PI * (freq * 2) * tGlobal);
    const noteBeat = (tGlobal * 1.6) % 1;
    const noteEnv = Math.min(1, noteBeat * 12) * Math.exp(-noteBeat * 2.1);

    let fadeGain = 1.0;
    if (fadeInSec > 0 && tLocal < fadeInSec) {
      fadeGain *= tLocal / fadeInSec;
    }
    if (fadeOutSec > 0 && durationSec - tLocal < fadeOutSec) {
      fadeGain *= Math.max(0, (durationSec - tLocal) / fadeOutSec);
    }

    const val = (fundamental + fifth + octave) * 0.45 * noteEnv * fadeGain;
    samples[i] = val;
    const absVal = Math.abs(val);
    if (absVal > peak) peak = absVal;
  }

  const normFactor = normalize ? 0.92 / peak : 1.0;

  // Encode standard 44-byte RIFF WAV header + 16-bit PCM payload
  const buffer = new ArrayBuffer(44 + numSamples * 2);
  const view = new DataView(buffer);

  const writeStr = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 2, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true); // PCM chunk size
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, 1, true); // Mono channel
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, 'data');
  view.setUint32(40, numSamples * 2, true);

  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    const clamped = Math.max(-1, Math.min(1, samples[i] * normFactor));
    view.setInt16(offset, clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff, true);
    offset += 2;
  }

  return new Blob([buffer], { type: 'audio/wav' });
}

export interface ParsedLyricLine {
  timestampSec: number;
  text: string;
}

export function parseLrcLyrics(rawLrc: string, offsetMs: number = 0): ParsedLyricLine[] {
  const regex = /\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?\](.*)/;
  const lines: ParsedLyricLine[] = [];
  rawLrc.split('\n').forEach((row) => {
    const match = row.trim().match(regex);
    if (match) {
      const min = parseInt(match[1], 10);
      const sec = parseInt(match[2], 10);
      const fracStr = match[3] || '0';
      const ms =
        fracStr.length === 1
          ? parseInt(fracStr, 10) * 100
          : fracStr.length === 2
          ? parseInt(fracStr, 10) * 10
          : parseInt(fracStr.slice(0, 3), 10);
      const totalSec = Math.max(0, min * 60 + sec + (ms + offsetMs) / 1000);
      lines.push({ timestampSec: totalSec, text: match[4].trim() });
    }
  });
  return lines.sort((a, b) => a.timestampSec - b.timestampSec);
}
