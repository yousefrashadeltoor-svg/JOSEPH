import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Lock,
  Unlock,
  Sun,
  Volume2,
  Subtitles,
  Repeat,
  Bookmark,
  Maximize2,
  Upload,
  Gauge,
  SlidersHorizontal,
} from 'lucide-react';
import { AlphThemeDefinition, VideoMediaItem } from '../data/mediaCatalogAndThemes';

interface Props {
  videos: VideoMediaItem[];
  activeVideo: VideoMediaItem;
  onSelectVideo: (video: VideoMediaItem) => void;
  onUpdateVideo: (updated: VideoMediaItem) => void;
  theme: AlphThemeDefinition;
  isArabic: boolean;
  cornerRadius: number;
  enableBrightnessGesture: boolean;
  enableVolumeGesture: boolean;
  enableHorizontalSeek: boolean;
  seekIncrementSec: number;
}

export const AdvancedVideoPlayerView: React.FC<Props> = ({
  videos,
  activeVideo,
  onSelectVideo,
  onUpdateVideo,
  theme,
  isArabic,
  cornerRadius,
  enableBrightnessGesture,
  enableVolumeGesture,
  enableHorizontalSeek,
  seekIncrementSec,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [positionSec, setPositionSec] = useState(activeVideo.lastPositionSec || 0);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [inAppBrightness, setInAppBrightness] = useState(92); // 10..100%
  const [playbackVolume, setPlaybackVolume] = useState(80); // 0..100%
  const [isScreenLocked, setIsScreenLocked] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [aspectRatioMode, setAspectRatioMode] = useState<'16:9 Fit' | 'Fill' | '4:3' | '21:9'>('16:9 Fit');

  // A-B Repeat
  const [pointASec, setPointASec] = useState<number | null>(null);
  const [pointBSec, setPointBSec] = useState<number | null>(null);

  // Subtitles
  const [subtitlesEnabled, setSubtitlesEnabled] = useState(true);
  const [subtitleDelayMs, setSubtitleDelayMs] = useState(0);
  const [subtitleFontSize, setSubtitleFontSize] = useState(16);
  const [subtitleColor, setSubtitleColor] = useState('#FFFFFF');
  const [subtitleBgOpacity, setSubtitleBgOpacity] = useState(0.75);
  const [showSubtitlePanel, setShowSubtitlePanel] = useState(false);

  // Gesture HUD feedback
  const [hudOverlay, setHudOverlay] = useState<{
    type: 'brightness' | 'volume' | 'seek';
    label: string;
  } | null>(null);

  const dragStartRef = useRef<{
    x: number;
    y: number;
    zone: 'left' | 'right';
    initBrightness: number;
    initVolume: number;
    initPos: number;
  } | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const hudTimeoutRef = useRef<number | null>(null);

  const triggerHud = (type: 'brightness' | 'volume' | 'seek', label: string) => {
    setHudOverlay({ type, label });
    if (hudTimeoutRef.current) window.clearTimeout(hudTimeoutRef.current);
    hudTimeoutRef.current = window.setTimeout(() => setHudOverlay(null), 1100);
  };

  useEffect(() => {
    setPositionSec(activeVideo.lastPositionSec || 0);
    setPointASec(null);
    setPointBSec(null);
  }, [activeVideo.id]);

  // Playback loop with A-B repeat support
  useEffect(() => {
    if (!isPlaying) return;
    const interval = window.setInterval(() => {
      setPositionSec((prev) => {
        const next = prev + 0.1 * playbackSpeed;
        if (pointASec !== null && pointBSec !== null && next >= pointBSec) {
          return pointASec;
        }
        if (next >= activeVideo.durationSec) {
          return 0;
        }
        return next;
      });
    }, 100);
    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed, activeVideo.durationSec, pointASec, pointBSec]);

  // Render 60fps Cinema Surface
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Rich animated backdrop
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, '#040711');
    grad.addColorStop(0.5, activeVideo.themeColor);
    grad.addColorStop(1, '#0F172A');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Animated aurora waves
    for (let layer = 0; layer < 5; layer++) {
      ctx.beginPath();
      const baseY = h * 0.3 + layer * 32;
      ctx.moveTo(0, baseY);
      for (let x = 0; x <= w; x += 20) {
        const y =
          baseY +
          Math.sin(x * 0.012 + positionSec * (1.2 + layer * 0.25)) * (22 + layer * 4);
        ctx.lineTo(x, y);
      }
      ctx.lineTo(w, h);
      ctx.lineTo(0, h);
      ctx.closePath();
      ctx.fillStyle = `rgba(255, 255, 255, ${0.05 + layer * 0.025})`;
      ctx.fill();
    }

    // In-App Window Brightness dimming overlay (never modifies OS global brightness)
    const darknessAlpha = Math.max(0, Math.min(0.85, (100 - inAppBrightness) / 100));
    if (darknessAlpha > 0.01) {
      ctx.fillStyle = `rgba(0, 0, 0, ${darknessAlpha})`;
      ctx.fillRect(0, 0, w, h);
    }
  }, [activeVideo, positionSec, inAppBrightness]);

  // Pointer Gesture Handlers (Left = Brightness, Right = Volume, Horizontal = Seek)
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isScreenLocked) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const relX = e.clientX - rect.left;
    const zone = relX < rect.width / 2 ? 'left' : 'right';
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      zone,
      initBrightness: inAppBrightness,
      initVolume: playbackVolume,
      initPos: positionSec,
    };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isScreenLocked || !dragStartRef.current) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;

    if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;

    if (Math.abs(dy) > Math.abs(dx)) {
      // Vertical gesture
      const deltaPct = Math.round((-dy / 180) * 100);
      if (dragStartRef.current.zone === 'left' && enableBrightnessGesture) {
        const nextB = Math.max(10, Math.min(100, dragStartRef.current.initBrightness + deltaPct));
        setInAppBrightness(nextB);
        triggerHud('brightness', `${isArabic ? 'السطوع' : 'Brightness'} ${nextB}%`);
      } else if (dragStartRef.current.zone === 'right' && enableVolumeGesture) {
        const nextV = Math.max(0, Math.min(100, dragStartRef.current.initVolume + deltaPct));
        setPlaybackVolume(nextV);
        triggerHud('volume', `${isArabic ? 'الصوت' : 'Volume'} ${nextV}%`);
      }
    } else if (enableHorizontalSeek) {
      // Horizontal Seek Gesture
      const deltaSec = (dx / 240) * 12;
      const nextPos = Math.max(
        0,
        Math.min(activeVideo.durationSec, dragStartRef.current.initPos + deltaSec)
      );
      setPositionSec(nextPos);
      const sign = deltaSec >= 0 ? '+' : '';
      triggerHud('seek', `${sign}${deltaSec.toFixed(1)}s (${nextPos.toFixed(1)}s)`);
    }
  };

  const handlePointerUp = () => {
    dragStartRef.current = null;
  };

  // Double-tap left/right/center
  const handleDoubleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isScreenLocked) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const relX = e.clientX - rect.left;
    if (relX < rect.width * 0.35) {
      const target = Math.max(0, positionSec - seekIncrementSec);
      setPositionSec(target);
      triggerHud('seek', `-${seekIncrementSec}s`);
    } else if (relX > rect.width * 0.65) {
      const target = Math.min(activeVideo.durationSec, positionSec + seekIncrementSec);
      setPositionSec(target);
      triggerHud('seek', `+${seekIncrementSec}s`);
    } else {
      setIsPlaying((p) => !p);
    }
  };

  // Active synchronized subtitle line
  const effectiveSubTime = positionSec - subtitleDelayMs / 1000;
  const activeSubtitle = activeVideo.subtitles.find(
    (s) => effectiveSubTime >= s.startSec && effectiveSubTime <= s.endSec
  );

  const handleToggleABLoop = () => {
    if (pointASec === null) {
      setPointASec(positionSec);
    } else if (pointBSec === null && positionSec > pointASec + 0.5) {
      setPointBSec(positionSec);
    } else {
      setPointASec(null);
      setPointBSec(null);
    }
  };

  const handleAddBookmark = () => {
    const rounded = Math.round(positionSec * 10) / 10;
    if (!activeVideo.bookmarksSec.includes(rounded)) {
      onUpdateVideo({
        ...activeVideo,
        bookmarksSec: [...activeVideo.bookmarksSec, rounded].sort((a, b) => a - b),
      });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Main Interactive Video Player Surface */}
      <div className="lg:col-span-8 space-y-4">
        <div
          className="relative overflow-hidden border select-none bg-black shadow-2xl"
          style={{
            borderColor: theme.border,
            borderRadius: `${cornerRadius}px`,
          }}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onDoubleClick={handleDoubleClick}
        >
          <canvas
            ref={canvasRef}
            width={860}
            height={480}
            className="w-full h-[320px] sm:h-[410px] object-cover cursor-pointer"
            onClick={() => setShowControls((s) => !s)}
          />

          {/* Subtle Gesture Zone Guides (When Controls Shown & Not Locked) */}
          {showControls && !isScreenLocked && (
            <div className="pointer-events-none absolute top-3 start-3 flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-black/65 text-white/90 border border-white/15">
                {isArabic
                  ? 'اسحب عمودياً يساراً للسطوع • يميناً للصوت • أفقياً للتقديم'
                  : 'Swipe Left Zone: Brightness • Right Zone: Volume • Horizontal: Fine Seek'}
              </span>
              {pointASec !== null && (
                <span
                  className="px-2.5 py-1 rounded-full text-[11px] font-bold text-white"
                  style={{ backgroundColor: theme.primary }}
                >
                  A-B Loop: {pointASec.toFixed(1)}s → {pointBSec ? `${pointBSec.toFixed(1)}s` : '...'}
                </span>
              )}
            </div>
          )}

          {/* Dedicated Lock Button (Always Accessible Without Triggering Underlying Controls) */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsScreenLocked((locked) => !locked);
            }}
            className="absolute top-3 end-3 z-20 flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-bold border transition-all cursor-pointer"
            style={{
              backgroundColor: isScreenLocked ? theme.primary : 'rgba(9, 13, 22, 0.78)',
              borderColor: isScreenLocked ? theme.primary : 'rgba(255,255,255,0.2)',
              color: '#FFFFFF',
            }}
          >
            {isScreenLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
            <span>
              {isScreenLocked
                ? isArabic
                  ? 'الشاشة مقفلة — انقر للفتح'
                  : 'Screen Locked — Tap to Unlock'
                : isArabic
                ? 'قفل اللمس'
                : 'Lock Controls'}
            </span>
          </button>

          {/* Temporary Gesture HUD Indicator */}
          {hudOverlay && (
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
              <div
                className="flex items-center gap-2.5 px-5 py-3 rounded-2xl border text-white font-bold text-sm shadow-xl"
                style={{
                  backgroundColor: 'rgba(9, 13, 22, 0.85)',
                  borderColor: theme.primary,
                }}
              >
                {hudOverlay.type === 'brightness' && (
                  <Sun className="w-5 h-5" style={{ color: theme.primary }} />
                )}
                {hudOverlay.type === 'volume' && (
                  <Volume2 className="w-5 h-5" style={{ color: theme.primary }} />
                )}
                <span>{hudOverlay.label}</span>
              </div>
            </div>
          )}

          {/* Synchronized Subtitle Overlay */}
          {subtitlesEnabled && activeSubtitle && (
            <div className="pointer-events-none absolute bottom-24 inset-x-0 flex justify-center px-6">
              <div
                className="px-4 py-1.5 rounded-xl font-semibold text-center transition-all"
                style={{
                  fontSize: `${subtitleFontSize}px`,
                  color: subtitleColor,
                  backgroundColor: `rgba(0, 0, 0, ${subtitleBgOpacity})`,
                  textShadow: '0 2px 4px rgba(0,0,0,0.8)',
                }}
              >
                {isArabic ? activeSubtitle.textAr : activeSubtitle.textEn}
              </div>
            </div>
          )}

          {/* Bottom Control Bar (Hidden When Screen Locked) */}
          {showControls && !isScreenLocked && (
            <div
              className="absolute bottom-0 inset-x-0 p-4 space-y-2.5"
              style={{
                background: 'linear-gradient(to top, rgba(4,7,17,0.95), rgba(4,7,17,0.6), transparent)',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Timeline & Bookmark Ticks */}
              <div className="space-y-1">
                <input
                  type="range"
                  min={0}
                  max={activeVideo.durationSec}
                  step={0.1}
                  value={positionSec}
                  onChange={(e) => setPositionSec(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
                <div className="flex justify-between text-[11px] text-white/80 font-mono">
                  <span>{positionSec.toFixed(1)}s</span>
                  <span>
                    {activeVideo.title} • {activeVideo.resolution}
                  </span>
                  <span>{activeVideo.durationSec.toFixed(1)}s</span>
                </div>
              </div>

              {/* Control Actions Row */}
              <div className="flex flex-wrap items-center justify-between gap-2 text-white">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setPositionSec((p) => Math.max(0, p - seekIncrementSec))}
                    className="p-2 rounded-xl bg-white/10 hover:bg-white/20 cursor-pointer"
                    title={`Rewind ${seekIncrementSec}s`}
                  >
                    <SkipBack className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setIsPlaying((p) => !p)}
                    className="p-2.5 rounded-2xl text-white cursor-pointer"
                    style={{ backgroundColor: theme.primary }}
                  >
                    {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  </button>
                  <button
                    onClick={() =>
                      setPositionSec((p) => Math.min(activeVideo.durationSec, p + seekIncrementSec))
                    }
                    className="p-2 rounded-xl bg-white/10 hover:bg-white/20 cursor-pointer"
                    title={`Forward ${seekIncrementSec}s`}
                  >
                    <SkipForward className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    onClick={handleToggleABLoop}
                    className="px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    style={{
                      backgroundColor: pointASec !== null ? theme.primary : 'rgba(255,255,255,0.12)',
                    }}
                  >
                    <Repeat className="w-3.5 h-3.5" />
                    <span>
                      {pointASec === null
                        ? 'A-B Loop'
                        : pointBSec === null
                        ? 'Set B'
                        : 'Clear A-B'}
                    </span>
                  </button>

                  <button
                    onClick={handleAddBookmark}
                    className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white/12 hover:bg-white/20 flex items-center gap-1 cursor-pointer"
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                    <span>Bookmark ({activeVideo.bookmarksSec.length})</span>
                  </button>

                  <button
                    onClick={() => {
                      const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];
                      const next = speeds[(speeds.indexOf(playbackSpeed) + 1) % speeds.length];
                      setPlaybackSpeed(next);
                    }}
                    className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white/12 hover:bg-white/20 flex items-center gap-1 cursor-pointer"
                  >
                    <Gauge className="w-3.5 h-3.5" />
                    <span>{playbackSpeed}x</span>
                  </button>

                  <button
                    onClick={() => {
                      const modes: ('16:9 Fit' | 'Fill' | '4:3' | '21:9')[] = [
                        '16:9 Fit',
                        'Fill',
                        '4:3',
                        '21:9',
                      ];
                      setAspectRatioMode(
                        modes[(modes.indexOf(aspectRatioMode) + 1) % modes.length]
                      );
                    }}
                    className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white/12 hover:bg-white/20 flex items-center gap-1 cursor-pointer"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>{aspectRatioMode}</span>
                  </button>

                  <button
                    onClick={() => setShowSubtitlePanel((s) => !s)}
                    className="px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    style={{
                      backgroundColor: showSubtitlePanel ? theme.primary : 'rgba(255,255,255,0.12)',
                    }}
                  >
                    <Subtitles className="w-3.5 h-3.5" />
                    <span>Subtitles</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Subtitle Sync & Appearance Customization Panel */}
        {showSubtitlePanel && (
          <div
            className="p-4 border space-y-3"
            style={{
              backgroundColor: theme.surface,
              borderColor: theme.border,
              borderRadius: `${cornerRadius}px`,
            }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-sm">
                <SlidersHorizontal className="w-4 h-4" style={{ color: theme.primary }} />
                <span>SRT / WebVTT Subtitle Synchronization &amp; Styling</span>
              </div>
              <label className="flex items-center gap-2 text-xs cursor-pointer">
                <input
                  type="checkbox"
                  checked={subtitlesEnabled}
                  onChange={(e) => setSubtitlesEnabled(e.target.checked)}
                  className="accent-indigo-500"
                />
                <span>Show Subtitles</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block mb-1" style={{ color: theme.textSecondary }}>
                  Sync Delay: <strong>{subtitleDelayMs} ms</strong>
                </label>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => setSubtitleDelayMs((d) => d - 250)}
                    className="px-2.5 py-1 rounded-lg border cursor-pointer"
                    style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
                  >
                    -250ms
                  </button>
                  <button
                    onClick={() => setSubtitleDelayMs(0)}
                    className="px-2.5 py-1 rounded-lg border cursor-pointer"
                    style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
                  >
                    Reset
                  </button>
                  <button
                    onClick={() => setSubtitleDelayMs((d) => d + 250)}
                    className="px-2.5 py-1 rounded-lg border cursor-pointer"
                    style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
                  >
                    +250ms
                  </button>
                </div>
              </div>

              <div>
                <label className="block mb-1" style={{ color: theme.textSecondary }}>
                  Font Size ({subtitleFontSize}px)
                </label>
                <input
                  type="range"
                  min={12}
                  max={26}
                  value={subtitleFontSize}
                  onChange={(e) => setSubtitleFontSize(parseInt(e.target.value, 10))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block mb-1" style={{ color: theme.textSecondary }}>
                  Background Opacity ({Math.round(subtitleBgOpacity * 100)}%)
                </label>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.1}
                  value={subtitleBgOpacity}
                  onChange={(e) => setSubtitleBgOpacity(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block mb-1" style={{ color: theme.textSecondary }}>
                  Text Color
                </label>
                <input
                  type="color"
                  value={subtitleColor}
                  onChange={(e) => setSubtitleColor(e.target.value)}
                  className="w-full h-7 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Right Column: Video Library, Bookmarks & Gesture Controls */}
      <div className="lg:col-span-4 space-y-4">
        <div
          className="p-5 border space-y-3"
          style={{
            backgroundColor: theme.surface,
            borderColor: theme.border,
            borderRadius: `${cornerRadius}px`,
          }}
        >
          <h3 className="font-bold text-base">
            {isArabic ? 'مكتبة الفيديو المحلية' : 'Local Video Library'}
          </h3>

          <div className="space-y-2">
            {videos.map((vid) => {
              const selected = vid.id === activeVideo.id;
              return (
                <button
                  key={vid.id}
                  onClick={() => onSelectVideo(vid)}
                  className="w-full text-start p-3 rounded-2xl border transition-all flex items-center justify-between cursor-pointer"
                  style={{
                    backgroundColor: selected ? `${theme.primary}18` : theme.elevated,
                    borderColor: selected ? theme.primary : theme.border,
                  }}
                >
                  <div className="min-w-0">
                    <div className="font-semibold text-xs truncate">{vid.title}</div>
                    <div className="text-[11px]" style={{ color: theme.textSecondary }}>
                      {vid.resolution} • {vid.fps}fps • {vid.sizeMb} MB
                    </div>
                  </div>
                  <Play
                    className="w-4 h-4 shrink-0"
                    style={{ color: selected ? theme.primary : theme.textSecondary }}
                  />
                </button>
              );
            })}
          </div>
        </div>

        {/* Saved Video Bookmarks */}
        <div
          className="p-5 border space-y-3"
          style={{
            backgroundColor: theme.surface,
            borderColor: theme.border,
            borderRadius: `${cornerRadius}px`,
          }}
        >
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-sm">Saved Position Bookmarks</h4>
            <Upload className="w-4 h-4" style={{ color: theme.primary }} />
          </div>
          <div className="flex flex-wrap gap-2">
            {activeVideo.bookmarksSec.map((bm) => (
              <button
                key={bm}
                onClick={() => setPositionSec(bm)}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold border cursor-pointer"
                style={{
                  backgroundColor: theme.elevated,
                  borderColor: theme.border,
                  color: theme.primary,
                }}
              >
                Jump to {bm}s
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
