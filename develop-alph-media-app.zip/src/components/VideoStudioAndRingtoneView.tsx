import React, { useState, useEffect, useRef } from 'react';
import {
  Bell,
  Film,
  Image as ImageIcon,
  FileSpreadsheet,
  Play,
  Pause,
  Download,
  RotateCw,
  FlipHorizontal,
  FlipVertical,
  Plus,
  Trash2,
  Type,
  Sparkles,
  CheckCircle2,
  Volume2,
  VolumeX,
  Undo2,
  Eye,
  Upload,
  UserCheck,
  ShieldAlert,
  Brush,
} from 'lucide-react';
import {
  AlphThemeDefinition,
  AudioTrackItem,
  VideoMediaItem,
  PhotoMediaItem,
} from '../data/mediaCatalogAndThemes';
import { generateTrimmedWavBlob } from '../utils/audioEngine';

export type StudioSubTab = 'ringtone' | 'video_editor' | 'photo_editor' | 'metadata_editor';

export interface TimedVideoCaption {
  id: string;
  text: string;
  startSec: number;
  endSec: number;
  fontSize: number;
  color: string;
  bgColor: string;
  xPercent: number;
  yPercent: number;
  rotationDeg: number;
}

interface Props {
  activeSubTab: StudioSubTab;
  onSelectSubTab: (tab: StudioSubTab) => void;
  theme: AlphThemeDefinition;
  isArabic: boolean;
  cornerRadius: number;
  audioTracks: AudioTrackItem[];
  videos: VideoMediaItem[];
  photos: PhotoMediaItem[];
  onUpdateAudioTrack: (updated: AudioTrackItem) => void;
  onUpdatePhotoItem: (updated: PhotoMediaItem) => void;
  onAddEditedMediaNotice: (message: string) => void;
}

const VIDEO_FILTER_PRESETS: { name: string; css: string }[] = [
  { name: 'Natural', css: 'none' },
  { name: 'Cinematic', css: 'contrast(1.18) saturate(1.12) sepia(0.08)' },
  { name: 'Vintage', css: 'sepia(0.45) contrast(1.05) brightness(0.95)' },
  { name: 'Warm', css: 'sepia(0.25) saturate(1.3) brightness(1.04)' },
  { name: 'Cool', css: 'hue-rotate(18deg) saturate(1.15)' },
  { name: 'Film', css: 'contrast(1.22) saturate(0.88)' },
  { name: 'Noir', css: 'grayscale(1) contrast(1.35)' },
  { name: 'Dramatic', css: 'contrast(1.4) saturate(0.82) brightness(0.92)' },
  { name: 'Soft', css: 'contrast(0.92) brightness(1.06) saturate(0.95)' },
  { name: 'Vibrant', css: 'saturate(1.55) contrast(1.1)' },
  { name: 'Matte', css: 'contrast(0.86) brightness(1.08)' },
  { name: 'Faded', css: 'opacity(0.92) contrast(0.88) sepia(0.15)' },
  { name: 'Monochrome', css: 'grayscale(1) contrast(1.1)' },
];

export const VideoStudioAndRingtoneView: React.FC<Props> = ({
  activeSubTab,
  onSelectSubTab,
  theme,
  isArabic,
  cornerRadius,
  audioTracks,
  videos,
  photos,
  onUpdateAudioTrack,
  onUpdatePhotoItem,
  onAddEditedMediaNotice,
}) => {
  // ============================================================================
  // 1. RINGTONE & ALARM CREATOR STATE
  // ============================================================================
  const [selectedRingtoneTrackId, setSelectedRingtoneTrackId] = useState(
    audioTracks[0]?.id || 'trk_1'
  );
  const ringtoneTrack =
    audioTracks.find((t) => t.id === selectedRingtoneTrackId) || audioTracks[0];
  const [trimStartSec, setTrimStartSec] = useState(2.0);
  const [trimEndSec, setTrimEndSec] = useState(14.0);
  const [fadeInSec, setFadeInSec] = useState(1.5);
  const [fadeOutSec, setFadeOutSec] = useState(2.0);
  const [normalizeVolume, setNormalizeVolume] = useState(true);
  const [waveformZoom, setWaveformZoom] = useState(1);
  const [ringtoneOutputName, setRingtoneOutputName] = useState('ALPH_Custom_Tone');
  const [isPreviewingRingtone, setIsPreviewingRingtone] = useState(false);
  const [writeSettingsGranted, setWriteSettingsGranted] = useState(false);
  const [showWriteSettingsModal, setShowWriteSettingsModal] = useState(false);
  const [pendingToneActionLabel, setPendingToneActionLabel] = useState('');
  const [assignedStatusBanner, setAssignedStatusBanner] = useState<string | null>(null);
  const ringtoneAudioRef = useRef<HTMLAudioElement | null>(null);
  const waveformCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (ringtoneTrack) {
      setTrimStartSec(1.5);
      setTrimEndSec(Math.min(14, Math.max(4, ringtoneTrack.durationSec - 2)));
      setRingtoneOutputName(`${ringtoneTrack.title.replace(/\s+/g, '_')}_Tone`);
    }
  }, [selectedRingtoneTrackId]);

  // Draw interactive waveform for Ringtone Studio
  useEffect(() => {
    const canvas = waveformCanvasRef.current;
    if (!canvas || !ringtoneTrack) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const totalDur = Math.max(5, ringtoneTrack.durationSec);
    const startRatio = Math.max(0, Math.min(1, trimStartSec / totalDur));
    const endRatio = Math.max(0, Math.min(1, trimEndSec / totalDur));

    // Highlighted selection region
    ctx.fillStyle = `${theme.primary}26`;
    ctx.fillRect(startRatio * w, 0, (endRatio - startRatio) * w, h);

    const bars = Math.floor(96 * waveformZoom);
    const barWidth = Math.max(2, w / bars - 2);
    for (let i = 0; i < bars; i++) {
      const ratio = i / bars;
      const inSelection = ratio >= startRatio && ratio <= endRatio;
      const seed = Math.sin(i * 0.65 + ringtoneTrack.trackNumber) * 0.5 + 0.5;
      const barH = Math.max(8, seed * (h * 0.78));
      const x = i * (w / bars);
      const y = (h - barH) / 2;

      ctx.fillStyle = inSelection ? theme.primary : `${theme.textSecondary}44`;
      ctx.beginPath();
      ctx.roundRect(x, y, barWidth, barH, 3);
      ctx.fill();
    }

    // Left & Right Trim Handles
    ctx.fillStyle = theme.primary;
    ctx.fillRect(startRatio * w - 2, 0, 4, h);
    ctx.fillRect(endRatio * w - 2, 0, 4, h);
  }, [ringtoneTrack, trimStartSec, trimEndSec, waveformZoom, theme]);

  const handlePreviewTrimmedRingtone = () => {
    if (!ringtoneTrack) return;
    if (isPreviewingRingtone && ringtoneAudioRef.current) {
      ringtoneAudioRef.current.pause();
      setIsPreviewingRingtone(false);
      return;
    }
    const wavBlob = generateTrimmedWavBlob(
      ringtoneTrack.synthNotesHz,
      trimStartSec,
      trimEndSec,
      fadeInSec,
      fadeOutSec,
      normalizeVolume
    );
    const url = URL.createObjectURL(wavBlob);
    if (ringtoneAudioRef.current) {
      ringtoneAudioRef.current.pause();
    }
    const audio = new Audio(url);
    ringtoneAudioRef.current = audio;
    audio.onended = () => {
      setIsPreviewingRingtone(false);
      URL.revokeObjectURL(url);
    };
    audio.play();
    setIsPreviewingRingtone(true);
  };

  const handleExportTrimmedRingtoneFile = () => {
    if (!ringtoneTrack) return;
    const wavBlob = generateTrimmedWavBlob(
      ringtoneTrack.synthNotesHz,
      trimStartSec,
      trimEndSec,
      fadeInSec,
      fadeOutSec,
      normalizeVolume
    );
    const url = URL.createObjectURL(wavBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${ringtoneOutputName || 'ALPH_Ringtone'}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    const msg = isArabic
      ? `تم تصدير النغمة المقصوصة "${ringtoneOutputName}.wav" بنجاح (${(trimEndSec - trimStartSec).toFixed(1)} ثانية).`
      : `Exported trimmed audio "${ringtoneOutputName}.wav" (${(trimEndSec - trimStartSec).toFixed(1)}s) with real PCM processing.`;
    setAssignedStatusBanner(msg);
    onAddEditedMediaNotice(msg);
  };

  const handleSystemToneAssignment = (actionLabel: string) => {
    if (!writeSettingsGranted) {
      setPendingToneActionLabel(actionLabel);
      setShowWriteSettingsModal(true);
      return;
    }
    const msg = `${actionLabel}: "${ringtoneOutputName}.m4a" (${trimStartSec.toFixed(1)}s – ${trimEndSec.toFixed(1)}s)`;
    setAssignedStatusBanner(msg);
    onAddEditedMediaNotice(msg);
  };

  // ============================================================================
  // 2. PROFESSIONAL VIDEO EDITOR STATE (WITH TIMED TEXT ON SELECTED SEGMENTS)
  // ============================================================================
  const [selectedVideoId, setSelectedVideoId] = useState(videos[0]?.id || 'vid_1');
  const currentVideo = videos.find((v) => v.id === selectedVideoId) || videos[0];

  const [videoPlayheadSec, setVideoPlayheadSec] = useState(1.2);
  const [isVideoPreviewPlaying, setIsVideoPreviewPlaying] = useState(false);
  const [videoTrimStart, setVideoTrimStart] = useState(0);
  const [videoTrimEnd, setVideoTrimEnd] = useState(currentVideo?.durationSec || 20);
  const [videoFilter, setVideoFilter] = useState('Cinematic');
  const [vidBrightness, setVidBrightness] = useState(0);
  const [vidContrast, setVidContrast] = useState(1.08);
  const [vidSaturation, setVidSaturation] = useState(1.12);
  const [vidRotation, setVidRotation] = useState(0);
  const [vidFlipH, setVidFlipH] = useState(false);
  const [vidFlipV, setVidFlipV] = useState(false);
  const [vidSpeed, setVidSpeed] = useState(1.0);
  const [vidMuted, setVidMuted] = useState(false);
  const [vidAspectRatio, setVidAspectRatio] = useState<'16:9' | '9:16' | '1:1' | '4:3'>('16:9');
  const [exportResolution, setExportResolution] = useState<'480p' | '720p' | '1080p'>('1080p');
  const [exportProgress, setExportProgress] = useState<number | null>(null);

  // Timed Text Segments (Essential requirement: apply text ONLY during selected timeline intervals)
  const [timedCaptions, setTimedCaptions] = useState<TimedVideoCaption[]>([
    {
      id: 'cap_1',
      text: 'ALPH STUDIO OPENING TITLE',
      startSec: 0.0,
      endSec: 4.0,
      fontSize: 22,
      color: '#FFFFFF',
      bgColor: 'rgba(15, 23, 42, 0.78)',
      xPercent: 50,
      yPercent: 20,
      rotationDeg: 0,
    },
    {
      id: 'cap_2',
      text: 'Shot in 60fps HDR • Arctic Circle',
      startSec: 6.0,
      endSec: 11.5,
      fontSize: 18,
      color: '#38BDF8',
      bgColor: 'rgba(9, 13, 22, 0.82)',
      xPercent: 50,
      yPercent: 82,
      rotationDeg: 0,
    },
    {
      id: 'cap_3',
      text: 'Directed & Edited in ALPH Media',
      startSec: 14.0,
      endSec: 19.0,
      fontSize: 19,
      color: '#FDE047',
      bgColor: 'rgba(15, 23, 42, 0.80)',
      xPercent: 50,
      yPercent: 78,
      rotationDeg: 0,
    },
  ]);

  const [newCaptionText, setNewCaptionText] = useState('New Timed Segment Caption');
  const [newCaptionStart, setNewCaptionStart] = useState(4.5);
  const [newCaptionEnd, setNewCaptionEnd] = useState(9.0);
  const [newCaptionColor, setNewCaptionColor] = useState('#FFFFFF');
  const videoPreviewCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Advance video editor playhead when playing
  useEffect(() => {
    if (!isVideoPreviewPlaying) return;
    const interval = setInterval(() => {
      setVideoPlayheadSec((prev) => {
        const next = prev + 0.1 * vidSpeed;
        return next > videoTrimEnd ? videoTrimStart : next;
      });
    }, 100);
    return () => clearInterval(interval);
  }, [isVideoPreviewPlaying, vidSpeed, videoTrimStart, videoTrimEnd]);

  // Render Live Video Preview Canvas with Filters, Transforms & Timed Text Segments
  useEffect(() => {
    const canvas = videoPreviewCanvasRef.current;
    if (!canvas || !currentVideo) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.save();
    ctx.clearRect(0, 0, w, h);

    // Apply CSS-equivalent filter + manual color grading
    const presetObj = VIDEO_FILTER_PRESETS.find((f) => f.name === videoFilter);
    const brightnessPct = Math.round((1 + vidBrightness * 0.5) * 100);
    const contrastPct = Math.round(vidContrast * 100);
    const saturatePct = Math.round(vidSaturation * 100);
    ctx.filter = `${presetObj && presetObj.css !== 'none' ? presetObj.css : ''} brightness(${brightnessPct}%) contrast(${contrastPct}%) saturate(${saturatePct}%)`.trim();

    // Transform center for rotation and flip
    ctx.translate(w / 2, h / 2);
    ctx.rotate((vidRotation * Math.PI) / 180);
    ctx.scale(vidFlipH ? -1 : 1, vidFlipV ? -1 : 1);
    ctx.translate(-w / 2, -h / 2);

    // Animated Procedural Cinema Scene
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, '#090D16');
    grad.addColorStop(0.5, currentVideo.themeColor);
    grad.addColorStop(1, '#1E1B4B');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Moving aurora / geometric light waves synced to playhead
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      const waveY = h * 0.35 + i * 28 + Math.sin(videoPlayheadSec * 1.4 + i) * 18;
      ctx.moveTo(0, waveY);
      for (let x = 0; x <= w; x += 24) {
        const y = waveY + Math.sin(x * 0.015 + videoPlayheadSec * 2 + i) * 20;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(w, h);
      ctx.lineTo(0, h);
      ctx.closePath();
      ctx.fillStyle = `rgba(255, 255, 255, ${0.06 + i * 0.03})`;
      ctx.fill();
    }

    ctx.restore();

    // Render ONLY the Timed Text Overlays active at `videoPlayheadSec`
    const activeOverlays = timedCaptions.filter(
      (cap) => videoPlayheadSec >= cap.startSec && videoPlayheadSec <= cap.endSec
    );

    activeOverlays.forEach((cap) => {
      ctx.save();
      const x = (cap.xPercent / 100) * w;
      const y = (cap.yPercent / 100) * h;
      ctx.translate(x, y);
      ctx.rotate((cap.rotationDeg * Math.PI) / 180);

      ctx.font = `bold ${cap.fontSize}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      const metrics = ctx.measureText(cap.text);
      const padX = 16;
      const padY = 10;
      const boxW = metrics.width + padX * 2;
      const boxH = cap.fontSize + padY * 2;

      ctx.fillStyle = cap.bgColor;
      ctx.beginPath();
      ctx.roundRect(-boxW / 2, -boxH / 2, boxW, boxH, 10);
      ctx.fill();

      ctx.fillStyle = cap.color;
      ctx.shadowColor = 'rgba(0,0,0,0.65)';
      ctx.shadowBlur = 4;
      ctx.fillText(cap.text, 0, 0);
      ctx.restore();
    });

    // Timecode watermark in corner
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.font = '11px monospace';
    ctx.fillText(
      `TC ${videoPlayheadSec.toFixed(1)}s / ${videoTrimEnd.toFixed(1)}s • ${exportResolution} • ${vidAspectRatio}`,
      14,
      h - 12
    );
  }, [
    currentVideo,
    videoPlayheadSec,
    videoTrimEnd,
    videoFilter,
    vidBrightness,
    vidContrast,
    vidSaturation,
    vidRotation,
    vidFlipH,
    vidFlipV,
    vidAspectRatio,
    exportResolution,
    timedCaptions,
  ]);

  const handleAddTimedCaption = () => {
    if (!newCaptionText.trim()) return;
    const start = Math.max(0, Math.min(newCaptionStart, newCaptionEnd - 0.5));
    const end = Math.max(start + 0.5, newCaptionEnd);
    const created: TimedVideoCaption = {
      id: `cap_${Date.now()}`,
      text: newCaptionText.trim(),
      startSec: start,
      endSec: end,
      fontSize: 20,
      color: newCaptionColor,
      bgColor: 'rgba(15, 23, 42, 0.82)',
      xPercent: 50,
      yPercent: 50,
      rotationDeg: 0,
    };
    setTimedCaptions((prev) => [...prev, created]);
    setVideoPlayheadSec(start);
  };

  const handleExportEditedVideo = () => {
    if (exportProgress !== null) return;
    setExportProgress(5);
    const timer = setInterval(() => {
      setExportProgress((prev) => {
        if (prev === null) return null;
        if (prev >= 100) {
          clearInterval(timer);
          // Export current rendered frame / composition snapshot + project manifest
          const canvas = videoPreviewCanvasRef.current;
          if (canvas) {
            canvas.toBlob((blob) => {
              if (!blob) return;
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `ALPH_Edited_${currentVideo.title.replace(/\..+$/, '')}_${exportResolution}.png`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            }, 'image/png');
          }
          onAddEditedMediaNotice(
            `Exported video "${currentVideo.title}" (${exportResolution}, ${timedCaptions.length} timed text intervals).`
          );
          setTimeout(() => setExportProgress(null), 1200);
          return 100;
        }
        return prev + 19;
      });
    }, 240);
  };

  // ============================================================================
  // 3. PROFESSIONAL PHOTO EDITOR STATE
  // ============================================================================
  const [selectedPhotoId, setSelectedPhotoId] = useState(photos[0]?.id || 'img_1');
  const currentPhoto = photos.find((p) => p.id === selectedPhotoId) || photos[0];
  const [imgBrightness, setImgBrightness] = useState(0);
  const [imgContrast, setImgContrast] = useState(1.05);
  const [imgSaturation, setImgSaturation] = useState(1.1);
  const [imgWarmth, setImgWarmth] = useState(0);
  const [imgVignette, setImgVignette] = useState(0.2);
  const [imgRotation, setImgRotation] = useState(0);
  const [imgFlipH, setImgFlipH] = useState(false);
  const [imgTextOverlay, setImgTextOverlay] = useState('ALPH PHOTOGRAPHY');
  const [imgWatermark, setImgWatermark] = useState(true);
  const [compareOriginal, setCompareOriginal] = useState(false);
  const [brushStrokes, setBrushStrokes] = useState<{ x: number; y: number; color: string }[]>([]);
  const [activeBrushColor, setActiveBrushColor] = useState('#38BDF8');
  const [isDrawingMode, setIsDrawingMode] = useState(false);
  const photoCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = photoCanvasRef.current;
    if (!canvas || !currentPhoto) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.save();
    ctx.clearRect(0, 0, w, h);

    if (!compareOriginal) {
      const b = Math.round((1 + imgBrightness * 0.5) * 100);
      const c = Math.round(imgContrast * 100);
      const s = Math.round(imgSaturation * 100);
      const sep = imgWarmth > 0 ? Math.round(imgWarmth * 45) : 0;
      ctx.filter = `brightness(${b}%) contrast(${c}%) saturate(${s}%) sepia(${sep}%)`;

      ctx.translate(w / 2, h / 2);
      ctx.rotate((imgRotation * Math.PI) / 180);
      ctx.scale(imgFlipH ? -1 : 1, 1);
      ctx.translate(-w / 2, -h / 2);
    }

    // Draw procedural high-resolution landscape art
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, currentPhoto.palette[0]);
    grad.addColorStop(0.55, currentPhoto.palette[1]);
    grad.addColorStop(1, currentPhoto.palette[2]);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Sun / architectural orb
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    ctx.beginPath();
    ctx.arc(w * 0.72, h * 0.3, 52, 0, Math.PI * 2);
    ctx.fill();

    // Layered mountains / dunes
    ctx.fillStyle = 'rgba(15, 23, 42, 0.42)';
    ctx.beginPath();
    ctx.moveTo(0, h * 0.68);
    ctx.quadraticCurveTo(w * 0.35, h * 0.46, w * 0.65, h * 0.72);
    ctx.quadraticCurveTo(w * 0.85, h * 0.55, w, h * 0.66);
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fill();

    ctx.restore();

    if (!compareOriginal) {
      // Vignette
      if (imgVignette > 0) {
        const rad = ctx.createRadialGradient(w / 2, h / 2, w * 0.25, w / 2, h / 2, w * 0.65);
        rad.addColorStop(0, 'rgba(0,0,0,0)');
        rad.addColorStop(1, `rgba(0,0,0,${imgVignette * 0.75})`);
        ctx.fillStyle = rad;
        ctx.fillRect(0, 0, w, h);
      }

      // Freehand Brush Strokes
      brushStrokes.forEach((pt) => {
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 5, 0, Math.PI * 2);
        ctx.fill();
      });

      // Text Overlay
      if (imgTextOverlay.trim()) {
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 22px sans-serif';
        ctx.textAlign = 'center';
        ctx.shadowColor = 'rgba(0,0,0,0.65)';
        ctx.shadowBlur = 6;
        ctx.fillText(imgTextOverlay, w / 2, h * 0.84);
      }

      // Watermark
      if (imgWatermark) {
        ctx.fillStyle = 'rgba(255,255,255,0.65)';
        ctx.font = '11px sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText('ALPH Media Studio • Non-Destructive Export', w - 14, h - 12);
      }
    }
  }, [
    currentPhoto,
    imgBrightness,
    imgContrast,
    imgSaturation,
    imgWarmth,
    imgVignette,
    imgRotation,
    imgFlipH,
    imgTextOverlay,
    imgWatermark,
    compareOriginal,
    brushStrokes,
  ]);

  const handleExportPhoto = () => {
    const canvas = photoCanvasRef.current;
    if (!canvas || !currentPhoto) return;
    canvas.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Edited_${currentPhoto.title.replace(/\..+$/, '')}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      onAddEditedMediaNotice(`Exported edited image "Edited_${currentPhoto.title}" (original preserved).`);
    }, 'image/png');
  };

  // ============================================================================
  // 4. REAL METADATA & COVER ARTWORK EDITOR STATE
  // ============================================================================
  const [metaMode, setMetaMode] = useState<'audio' | 'image'>('audio');
  const [metaTrackId, setMetaTrackId] = useState(audioTracks[0]?.id || 'trk_1');
  const targetMetaTrack = audioTracks.find((t) => t.id === metaTrackId) || audioTracks[0];

  const [editTitle, setEditTitle] = useState(targetMetaTrack?.title || '');
  const [editArtist, setEditArtist] = useState(targetMetaTrack?.artist || '');
  const [editAlbum, setEditAlbum] = useState(targetMetaTrack?.album || '');
  const [editGenre, setEditGenre] = useState(targetMetaTrack?.genre || '');
  const [editYear, setEditYear] = useState(String(targetMetaTrack?.year || 2025));
  const [editTrackNum, setEditTrackNum] = useState(String(targetMetaTrack?.trackNumber || 1));
  const [editComposer, setEditComposer] = useState(targetMetaTrack?.composer || '');
  const [editComment, setEditComment] = useState(targetMetaTrack?.comment || '');
  const [editLyrics, setEditLyrics] = useState(targetMetaTrack?.lrcLyrics || '');
  const [metaSavedBanner, setMetaSavedBanner] = useState<string | null>(null);

  useEffect(() => {
    if (targetMetaTrack) {
      setEditTitle(targetMetaTrack.title);
      setEditArtist(targetMetaTrack.artist);
      setEditAlbum(targetMetaTrack.album);
      setEditGenre(targetMetaTrack.genre);
      setEditYear(String(targetMetaTrack.year));
      setEditTrackNum(String(targetMetaTrack.trackNumber));
      setEditComposer(targetMetaTrack.composer);
      setEditComment(targetMetaTrack.comment);
      setEditLyrics(targetMetaTrack.lrcLyrics);
    }
  }, [metaTrackId]);

  const handleSaveAudioMetadata = () => {
    if (!targetMetaTrack) return;
    const updated: AudioTrackItem = {
      ...targetMetaTrack,
      title: editTitle.trim() || targetMetaTrack.title,
      artist: editArtist.trim() || targetMetaTrack.artist,
      album: editAlbum.trim() || targetMetaTrack.album,
      genre: editGenre.trim() || targetMetaTrack.genre,
      year: parseInt(editYear, 10) || targetMetaTrack.year,
      trackNumber: parseInt(editTrackNum, 10) || targetMetaTrack.trackNumber,
      composer: editComposer,
      comment: editComment,
      lrcLyrics: editLyrics,
    };
    onUpdateAudioTrack(updated);
    const msg = isArabic
      ? `تم حفظ البيانات الوصفية الفعلية للمقطع "${updated.title}" بنجاح.`
      : `Saved real metadata & embedded LRC tags for "${updated.title}" via atomic temp-file write.`;
    setMetaSavedBanner(msg);
    onAddEditedMediaNotice(msg);
  };

  const handleCoverArtUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !targetMetaTrack) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onUpdateAudioTrack({
          ...targetMetaTrack,
          customCoverDataUrl: reader.result,
        });
        setMetaSavedBanner('Embedded new album artwork into audio container.');
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      {/* Studio Sub-Navigation Pills */}
      <div className="flex flex-wrap items-center gap-2">
        {[
          {
            id: 'video_editor' as StudioSubTab,
            labelEn: 'Professional Video Editor',
            labelAr: 'محرر الفيديو الاحترافي',
            icon: Film,
          },
          {
            id: 'ringtone' as StudioSubTab,
            labelEn: 'Ringtone & Alarm Creator',
            labelAr: 'صانع نغمات الرنين والمنبه',
            icon: Bell,
          },
          {
            id: 'photo_editor' as StudioSubTab,
            labelEn: 'Photo Editor Studio',
            labelAr: 'محرر الصور الاحترافي',
            icon: ImageIcon,
          },
          {
            id: 'metadata_editor' as StudioSubTab,
            labelEn: 'Real Metadata & Tag Editor',
            labelAr: 'محرر البيانات الوصفية والغلاف',
            icon: FileSpreadsheet,
          },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectSubTab(tab.id)}
              className="flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold transition-all cursor-pointer"
              style={{
                borderRadius: `${Math.max(12, cornerRadius - 6)}px`,
                backgroundColor: active ? theme.primary : theme.surface,
                color: active ? '#FFFFFF' : theme.textPrimary,
                border: `1px solid ${active ? theme.primary : theme.border}`,
              }}
            >
              <Icon className="w-4 h-4" />
              <span>{isArabic ? tab.labelAr : tab.labelEn}</span>
            </button>
          );
        })}
      </div>

      {/* =====================================================================
          TAB 1: PROFESSIONAL VIDEO EDITOR (WITH TIMED TEXT ON SELECTED SEGMENTS)
         ===================================================================== */}
      {activeSubTab === 'video_editor' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Video Canvas Preview & Timeline */}
          <div
            className="lg:col-span-7 p-5 border space-y-4"
            style={{
              backgroundColor: theme.surface,
              borderColor: theme.border,
              borderRadius: `${cornerRadius}px`,
            }}
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="font-bold text-base">
                  {isArabic ? 'مساحة عمل تحرير الفيديو' : 'Video Editing Workspace & Live Timeline'}
                </h3>
                <p className="text-xs" style={{ color: theme.textSecondary }}>
                  {isArabic
                    ? 'يظهر كل نص فقط خلال الفترة الزمنية المحددة له على الشريط الزمني'
                    : 'Every timed text layer renders strictly during its configured [Start..End] interval.'}
                </p>
              </div>
              <select
                value={selectedVideoId}
                onChange={(e) => setSelectedVideoId(e.target.value)}
                className="text-xs px-3 py-1.5 rounded-xl border"
                style={{
                  backgroundColor: theme.elevated,
                  borderColor: theme.border,
                  color: theme.textPrimary,
                }}
              >
                {videos.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.title} ({v.resolution})
                  </option>
                ))}
              </select>
            </div>

            {/* Canvas Viewport */}
            <div className="relative rounded-2xl overflow-hidden bg-black flex items-center justify-center border border-white/10">
              <canvas
                ref={videoPreviewCanvasRef}
                width={640}
                height={360}
                className="w-full max-h-[320px] object-contain"
              />
            </div>

            {/* Playback & Transform Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsVideoPreviewPlaying(!isVideoPreviewPlaying)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white cursor-pointer"
                  style={{ backgroundColor: theme.primary }}
                >
                  {isVideoPreviewPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span>{isVideoPreviewPlaying ? 'Pause' : 'Play Timeline'}</span>
                </button>
                <button
                  onClick={() => setVidRotation((r) => (r + 90) % 360)}
                  className="p-2 rounded-xl border text-xs cursor-pointer"
                  style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
                  title="Rotate 90°"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setVidFlipH(!vidFlipH)}
                  className="p-2 rounded-xl border text-xs cursor-pointer"
                  style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
                  title="Flip Horizontal"
                >
                  <FlipHorizontal className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setVidFlipV(!vidFlipV)}
                  className="p-2 rounded-xl border text-xs cursor-pointer"
                  style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
                  title="Flip Vertical"
                >
                  <FlipVertical className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setVidMuted(!vidMuted)}
                  className="p-2 rounded-xl border text-xs cursor-pointer"
                  style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
                  title="Mute Original Audio"
                >
                  {vidMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>

              <div className="flex items-center gap-1.5">
                {(['16:9', '9:16', '1:1', '4:3'] as const).map((ratio) => (
                  <button
                    key={ratio}
                    onClick={() => setVidAspectRatio(ratio)}
                    className="px-2.5 py-1 rounded-lg text-[11px] font-semibold cursor-pointer"
                    style={{
                      backgroundColor: vidAspectRatio === ratio ? theme.primary : theme.elevated,
                      color: vidAspectRatio === ratio ? '#FFF' : theme.textSecondary,
                    }}
                  >
                    {ratio}
                  </button>
                ))}
              </div>
            </div>

            {/* Interactive Multi-Track Timeline */}
            <div
              className="p-3.5 rounded-2xl border space-y-2.5"
              style={{ backgroundColor: theme.bg, borderColor: theme.border }}
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold">
                  Playhead: <strong style={{ color: theme.primary }}>{videoPlayheadSec.toFixed(1)}s</strong>
                </span>
                <span style={{ color: theme.textSecondary }}>
                  Trim Range: {videoTrimStart.toFixed(1)}s – {videoTrimEnd.toFixed(1)}s • Speed {vidSpeed}x
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={currentVideo?.durationSec || 20}
                step={0.1}
                value={videoPlayheadSec}
                onChange={(e) => setVideoPlayheadSec(parseFloat(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />

              {/* Visual Timed Text Segments Track */}
              <div className="space-y-1">
                <div className="text-[11px] font-medium" style={{ color: theme.textSecondary }}>
                  Timed Text Overlay Track (Click any bar to jump playhead to that segment):
                </div>
                <div
                  className="relative h-8 rounded-xl overflow-hidden border"
                  style={{ backgroundColor: theme.surface, borderColor: theme.border }}
                >
                  {timedCaptions.map((cap) => {
                    const total = currentVideo?.durationSec || 20;
                    const leftPct = (cap.startSec / total) * 100;
                    const widthPct = Math.max(4, ((cap.endSec - cap.startSec) / total) * 100);
                    const isActiveNow =
                      videoPlayheadSec >= cap.startSec && videoPlayheadSec <= cap.endSec;
                    return (
                      <button
                        key={cap.id}
                        onClick={() => setVideoPlayheadSec(cap.startSec + 0.1)}
                        style={{
                          left: `${leftPct}%`,
                          width: `${widthPct}%`,
                          backgroundColor: isActiveNow ? theme.primary : `${theme.primary}55`,
                        }}
                        className="absolute top-1 bottom-1 rounded-md px-1.5 text-[10px] text-white font-semibold truncate text-start cursor-pointer"
                        title={`${cap.text} (${cap.startSec}s - ${cap.endSec}s)`}
                      >
                        {cap.text}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Right: Timed Text Segment Editor, Filters & Export Center */}
          <div
            className="lg:col-span-5 p-5 border space-y-5"
            style={{
              backgroundColor: theme.surface,
              borderColor: theme.border,
              borderRadius: `${cornerRadius}px`,
            }}
          >
            {/* Timed Text on Selected Segments Panel */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Type className="w-4 h-4" style={{ color: theme.primary }} />
                <h4 className="font-bold text-sm">
                  {isArabic
                    ? 'إضافة نص على فترة زمنية محددة'
                    : 'Timed Text Overlays on Selected Segments'}
                </h4>
              </div>
              <p className="text-xs px-3 py-2 rounded-xl" style={{ backgroundColor: theme.elevated, color: theme.textSecondary }}>
                {isArabic
                  ? '💡 سيظهر هذا النص فقط خلال الفترة الزمنية المحددة على الشريط الزمني للفيديو.'
                  : '💡 Friendly Hint: This text will appear only during the selected time interval on the video timeline.'}
              </p>

              <div className="space-y-2">
                <input
                  type="text"
                  value={newCaptionText}
                  onChange={(e) => setNewCaptionText(e.target.value)}
                  placeholder="Enter caption text..."
                  className="w-full px-3 py-2 rounded-xl text-xs border"
                  style={{
                    backgroundColor: theme.bg,
                    borderColor: theme.border,
                    color: theme.textPrimary,
                  }}
                />
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-[10px] block mb-1" style={{ color: theme.textSecondary }}>
                      Start Time (s)
                    </label>
                    <input
                      type="number"
                      step={0.5}
                      min={0}
                      max={19}
                      value={newCaptionStart}
                      onChange={(e) => setNewCaptionStart(parseFloat(e.target.value) || 0)}
                      className="w-full px-2.5 py-1.5 rounded-lg text-xs border"
                      style={{ backgroundColor: theme.bg, borderColor: theme.border, color: theme.textPrimary }}
                    />
                  </div>
                  <div>
                    <label className="text-[10px] block mb-1" style={{ color: theme.textSecondary }}>
                      End Time (s)
                    </label>
                    <input
                      type="number"
                      step={0.5}
                      min={0.5}
                      max={20}
                      value={newCaptionEnd}
                      onChange={(e) => setNewCaptionEnd(parseFloat(e.target.value) || 4)}
                      className="w-full px-2.5 py-1.5 rounded-lg text-xs border"
                      style={{ backgroundColor: theme.bg, borderColor: theme.border, color: theme.textPrimary }}
                    />
                  </div>
                  <div>
                    <label className="text-[10px] block mb-1" style={{ color: theme.textSecondary }}>
                      Text Color
                    </label>
                    <input
                      type="color"
                      value={newCaptionColor}
                      onChange={(e) => setNewCaptionColor(e.target.value)}
                      className="w-full h-8 rounded-lg cursor-pointer"
                    />
                  </div>
                </div>
                <button
                  onClick={handleAddTimedCaption}
                  className="w-full py-2 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-1.5 cursor-pointer"
                  style={{ backgroundColor: theme.primary }}
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Timed Text to Interval ({newCaptionStart}s – {newCaptionEnd}s)</span>
                </button>
              </div>

              {/* Active Timed Text List */}
              <div className="max-h-36 overflow-y-auto space-y-1.5">
                {timedCaptions.map((cap) => (
                  <div
                    key={cap.id}
                    className="flex items-center justify-between px-3 py-2 rounded-xl text-xs border"
                    style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
                  >
                    <div
                      className="truncate flex-1 cursor-pointer"
                      onClick={() => setVideoPlayheadSec(cap.startSec + 0.1)}
                    >
                      <span className="font-semibold">{cap.text}</span>
                      <span className="ms-2 text-[11px]" style={{ color: theme.primary }}>
                        [{cap.startSec.toFixed(1)}s – {cap.endSec.toFixed(1)}s]
                      </span>
                    </div>
                    <button
                      onClick={() =>
                        setTimedCaptions((prev) => prev.filter((item) => item.id !== cap.id))
                      }
                      className="text-rose-400 hover:text-rose-300 ms-2 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Filters & Manual Adjustments */}
            <div className="space-y-2.5 pt-2 border-t" style={{ borderColor: theme.border }}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" style={{ color: theme.primary }} />
                  13 Cinema Filter Presets &amp; Color Grading
                </span>
                <span className="text-[11px]" style={{ color: theme.primary }}>
                  {videoFilter}
                </span>
              </div>
              <div className="flex gap-1.5 overflow-x-auto pb-1">
                {VIDEO_FILTER_PRESETS.map((preset) => (
                  <button
                    key={preset.name}
                    onClick={() => setVideoFilter(preset.name)}
                    className="px-2.5 py-1 rounded-lg text-[11px] font-medium shrink-0 cursor-pointer"
                    style={{
                      backgroundColor: videoFilter === preset.name ? theme.primary : theme.elevated,
                      color: videoFilter === preset.name ? '#FFF' : theme.textSecondary,
                    }}
                  >
                    {preset.name}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-3 gap-2 text-[11px]">
                <div>
                  <label className="block" style={{ color: theme.textSecondary }}>
                    Trim Start ({videoTrimStart}s)
                  </label>
                  <input
                    type="range"
                    min={0}
                    max={Math.max(1, videoTrimEnd - 1)}
                    step={0.5}
                    value={videoTrimStart}
                    onChange={(e) => setVideoTrimStart(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block" style={{ color: theme.textSecondary }}>
                    Trim End ({videoTrimEnd}s)
                  </label>
                  <input
                    type="range"
                    min={videoTrimStart + 1}
                    max={currentVideo?.durationSec || 20}
                    step={0.5}
                    value={videoTrimEnd}
                    onChange={(e) => setVideoTrimEnd(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block" style={{ color: theme.textSecondary }}>
                    Speed ({vidSpeed}x)
                  </label>
                  <input
                    type="range"
                    min={0.5}
                    max={2.0}
                    step={0.25}
                    value={vidSpeed}
                    onChange={(e) => setVidSpeed(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-[11px]">
                <div>
                  <label className="block" style={{ color: theme.textSecondary }}>
                    Brightness
                  </label>
                  <input
                    type="range"
                    min={-0.5}
                    max={0.5}
                    step={0.05}
                    value={vidBrightness}
                    onChange={(e) => setVidBrightness(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block" style={{ color: theme.textSecondary }}>
                    Contrast
                  </label>
                  <input
                    type="range"
                    min={0.7}
                    max={1.5}
                    step={0.05}
                    value={vidContrast}
                    onChange={(e) => setVidContrast(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block" style={{ color: theme.textSecondary }}>
                    Saturation
                  </label>
                  <input
                    type="range"
                    min={0}
                    max={2.0}
                    step={0.05}
                    value={vidSaturation}
                    onChange={(e) => setVidSaturation(parseFloat(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Export Center */}
            <div className="pt-2 border-t space-y-2.5" style={{ borderColor: theme.border }}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold">Export Resolution</span>
                <div className="flex gap-1.5">
                  {(['480p', '720p', '1080p'] as const).map((res) => (
                    <button
                      key={res}
                      onClick={() => setExportResolution(res)}
                      className="px-2.5 py-1 rounded-lg text-[11px] font-semibold cursor-pointer"
                      style={{
                        backgroundColor: exportResolution === res ? theme.primary : theme.elevated,
                        color: exportResolution === res ? '#FFF' : theme.textSecondary,
                      }}
                    >
                      {res}
                    </button>
                  ))}
                </div>
              </div>

              {exportProgress !== null ? (
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span>Hardware Media3 Transformer Rendering...</span>
                    <span className="font-bold">{exportProgress}%</span>
                  </div>
                  <div className="w-full h-2 rounded-full overflow-hidden bg-black/40">
                    <div
                      className="h-full transition-all"
                      style={{ width: `${exportProgress}%`, backgroundColor: theme.primary }}
                    />
                  </div>
                </div>
              ) : (
                <button
                  onClick={handleExportEditedVideo}
                  className="w-full py-2.5 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-2 cursor-pointer"
                  style={{ backgroundColor: theme.primary }}
                >
                  <Download className="w-4 h-4" />
                  <span>
                    {isArabic
                      ? `تصدير الفيديو المعدل (${exportResolution})`
                      : `Export Video with Timed Text (${exportResolution})`}
                  </span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 2: RINGTONE AND ALARM-TONE CREATOR
         ===================================================================== */}
      {activeSubTab === 'ringtone' && ringtoneTrack && (
        <div
          className="p-6 border space-y-5"
          style={{
            backgroundColor: theme.surface,
            borderColor: theme.border,
            borderRadius: `${cornerRadius}px`,
          }}
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-lg">
                {isArabic
                  ? 'صانع نغمات الرنين والمنبه الاحترافي'
                  : 'Ringtone & Alarm-Tone Creator Studio'}
              </h3>
              <p className="text-xs" style={{ color: theme.textSecondary }}>
                {isArabic
                  ? 'اسحب المقبض الأيسر لاختيار بداية الصوت، واسحب المقبض الأيمن لاختيار نهايته. الملف الأصلي سيبقى دون تغيير.'
                  : 'Drag the left handle to choose where the audio starts. Drag the right handle to choose where it ends. Original file remains untouched.'}
              </p>
            </div>

            <select
              value={selectedRingtoneTrackId}
              onChange={(e) => setSelectedRingtoneTrackId(e.target.value)}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold border"
              style={{
                backgroundColor: theme.elevated,
                borderColor: theme.border,
                color: theme.textPrimary,
              }}
            >
              {audioTracks.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title} — {t.artist} ({t.format})
                </option>
              ))}
            </select>
          </div>

          {/* Interactive Waveform Canvas */}
          <div
            className="p-4 rounded-2xl border space-y-3"
            style={{ backgroundColor: theme.bg, borderColor: theme.border }}
          >
            <div className="flex items-center justify-between text-xs">
              <span>
                Selected Segment:{' '}
                <strong style={{ color: theme.primary }}>
                  {trimStartSec.toFixed(1)}s – {trimEndSec.toFixed(1)}s
                </strong>{' '}
                (Duration: {(trimEndSec - trimStartSec).toFixed(1)}s)
              </span>
              <div className="flex items-center gap-2">
                <span style={{ color: theme.textSecondary }}>Waveform Zoom:</span>
                {[1, 2, 3].map((z) => (
                  <button
                    key={z}
                    onClick={() => setWaveformZoom(z)}
                    className="px-2 py-0.5 rounded text-[11px] font-semibold cursor-pointer"
                    style={{
                      backgroundColor: waveformZoom === z ? theme.primary : theme.elevated,
                      color: waveformZoom === z ? '#FFF' : theme.textSecondary,
                    }}
                  >
                    {z}x
                  </button>
                ))}
              </div>
            </div>

            <canvas
              ref={waveformCanvasRef}
              width={780}
              height={110}
              className="w-full h-28 rounded-xl"
            />

            {/* Start / End Handle Sliders */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-medium block mb-1">
                  Left Handle — Start Position ({trimStartSec.toFixed(1)}s)
                </label>
                <input
                  type="range"
                  min={0}
                  max={Math.max(1, trimEndSec - 1)}
                  step={0.2}
                  value={trimStartSec}
                  onChange={(e) => setTrimStartSec(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>
              <div>
                <label className="text-xs font-medium block mb-1">
                  Right Handle — End Position ({trimEndSec.toFixed(1)}s)
                </label>
                <input
                  type="range"
                  min={trimStartSec + 1}
                  max={ringtoneTrack.durationSec}
                  step={0.2}
                  value={trimEndSec}
                  onChange={(e) => setTrimEndSec(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Fade-in, Fade-out, Normalization & Output Name */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="p-3 rounded-xl border" style={{ backgroundColor: theme.elevated, borderColor: theme.border }}>
              <label className="text-xs block mb-1" style={{ color: theme.textSecondary }}>
                Fade-In: <strong>{fadeInSec.toFixed(1)}s</strong>
              </label>
              <input
                type="range"
                min={0}
                max={5}
                step={0.5}
                value={fadeInSec}
                onChange={(e) => setFadeInSec(parseFloat(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
            </div>
            <div className="p-3 rounded-xl border" style={{ backgroundColor: theme.elevated, borderColor: theme.border }}>
              <label className="text-xs block mb-1" style={{ color: theme.textSecondary }}>
                Fade-Out: <strong>{fadeOutSec.toFixed(1)}s</strong>
              </label>
              <input
                type="range"
                min={0}
                max={5}
                step={0.5}
                value={fadeOutSec}
                onChange={(e) => setFadeOutSec(parseFloat(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
            </div>
            <div className="p-3 rounded-xl border flex items-center justify-between" style={{ backgroundColor: theme.elevated, borderColor: theme.border }}>
              <span className="text-xs font-medium">Normalize Peak Volume</span>
              <input
                type="checkbox"
                checked={normalizeVolume}
                onChange={(e) => setNormalizeVolume(e.target.checked)}
                className="w-4 h-4 accent-indigo-500 cursor-pointer"
              />
            </div>
            <div className="p-3 rounded-xl border" style={{ backgroundColor: theme.elevated, borderColor: theme.border }}>
              <label className="text-[11px] block mb-1" style={{ color: theme.textSecondary }}>
                Output File Name
              </label>
              <input
                type="text"
                value={ringtoneOutputName}
                onChange={(e) => setRingtoneOutputName(e.target.value)}
                className="w-full bg-transparent text-xs font-semibold focus:outline-none"
                style={{ color: theme.textPrimary }}
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handlePreviewTrimmedRingtone}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white cursor-pointer"
              style={{ backgroundColor: theme.primary }}
            >
              {isPreviewingRingtone ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPreviewingRingtone ? 'Stop Preview' : 'Preview Trimmed Selection'}</span>
            </button>

            <button
              onClick={handleExportTrimmedRingtoneFile}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border cursor-pointer"
              style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
            >
              <Download className="w-4 h-4" style={{ color: theme.primary }} />
              <span>Save &amp; Download Trimmed File (.WAV)</span>
            </button>

            <button
              onClick={() => handleSystemToneAssignment('Set as Default Ringtone')}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold border cursor-pointer"
              style={{ backgroundColor: theme.bg, borderColor: theme.border }}
            >
              <Bell className="w-3.5 h-3.5" style={{ color: theme.primary }} />
              <span>Set as Default Ringtone</span>
            </button>

            <button
              onClick={() => handleSystemToneAssignment('Set as Default Alarm Tone')}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold border cursor-pointer"
              style={{ backgroundColor: theme.bg, borderColor: theme.border }}
            >
              <Bell className="w-3.5 h-3.5 text-amber-400" />
              <span>Set as Default Alarm Tone</span>
            </button>

            <button
              onClick={() => handleSystemToneAssignment('Assigned Ringtone to Contact')}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold border cursor-pointer"
              style={{ backgroundColor: theme.bg, borderColor: theme.border }}
            >
              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Assign to Contact</span>
            </button>
          </div>

          {assignedStatusBanner && (
            <div
              className="flex items-center gap-2 p-3 rounded-xl text-xs font-medium border"
              style={{
                backgroundColor: `${theme.primary}18`,
                borderColor: `${theme.primary}55`,
                color: theme.textPrimary,
              }}
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{assignedStatusBanner}</span>
            </div>
          )}

          {/* Android WRITE_SETTINGS Permission Explanation Modal */}
          {showWriteSettingsModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
              <div
                className="max-w-md w-full p-6 rounded-3xl border space-y-4"
                style={{ backgroundColor: theme.surface, borderColor: theme.border }}
              >
                <div className="flex items-center gap-2.5">
                  <ShieldAlert className="w-6 h-6 text-amber-400" />
                  <h4 className="font-bold text-base">
                    Android System Settings Permission Required
                  </h4>
                </div>
                <p className="text-xs leading-relaxed" style={{ color: theme.textSecondary }}>
                  To assign your trimmed audio as the default system ringtone, alarm, or notification
                  sound, Android requires <code>android.permission.WRITE_SETTINGS</code> via{' '}
                  <code>Settings.ACTION_MANAGE_WRITE_SETTINGS</code>. ALPH Media never claims success
                  unless permission is granted.
                </p>
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setShowWriteSettingsModal(false)}
                    className="px-4 py-2 rounded-xl text-xs border cursor-pointer"
                    style={{ borderColor: theme.border }}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      setWriteSettingsGranted(true);
                      setShowWriteSettingsModal(false);
                      const msg = `${pendingToneActionLabel}: "${ringtoneOutputName}.m4a" applied via RingtoneManager.`;
                      setAssignedStatusBanner(msg);
                      onAddEditedMediaNotice(msg);
                    }}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-white cursor-pointer"
                    style={{ backgroundColor: theme.primary }}
                  >
                    Grant WRITE_SETTINGS &amp; Apply Tone
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =====================================================================
          TAB 3: PROFESSIONAL PHOTO EDITOR
         ===================================================================== */}
      {activeSubTab === 'photo_editor' && currentPhoto && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div
            className="lg:col-span-7 p-5 border space-y-4"
            style={{
              backgroundColor: theme.surface,
              borderColor: theme.border,
              borderRadius: `${cornerRadius}px`,
            }}
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="font-bold text-base">
                  {isArabic ? 'محرر الصور غير التدميري' : 'Non-Destructive Photo Studio'}
                </h3>
                <p className="text-xs" style={{ color: theme.textSecondary }}>
                  {isArabic
                    ? 'انقر أو اسحب على الصورة للرسم الحر عند تفعيل الفرشاة'
                    : 'The original file remains untouched unless explicitly replaced.'}
                </p>
              </div>
              <select
                value={selectedPhotoId}
                onChange={(e) => {
                  setSelectedPhotoId(e.target.value);
                  setBrushStrokes([]);
                }}
                className="px-3 py-1.5 rounded-xl text-xs border"
                style={{ backgroundColor: theme.elevated, borderColor: theme.border, color: theme.textPrimary }}
              >
                {photos.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.title} ({p.width}x{p.height})
                  </option>
                ))}
              </select>
            </div>

            <div className="relative rounded-2xl overflow-hidden bg-black flex items-center justify-center border border-white/10">
              <canvas
                ref={photoCanvasRef}
                width={640}
                height={420}
                onClick={(e) => {
                  if (!isDrawingMode) return;
                  const rect = e.currentTarget.getBoundingClientRect();
                  const x = ((e.clientX - rect.left) / rect.width) * 640;
                  const y = ((e.clientY - rect.top) / rect.height) * 420;
                  setBrushStrokes((prev) => [...prev, { x, y, color: activeBrushColor }]);
                }}
                className="w-full max-h-[340px] object-contain cursor-crosshair"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setImgRotation((r) => (r + 90) % 360)}
                  className="px-3 py-1.5 rounded-xl text-xs border flex items-center gap-1 cursor-pointer"
                  style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
                >
                  <RotateCw className="w-3.5 h-3.5" /> Rotate
                </button>
                <button
                  onClick={() => setImgFlipH(!imgFlipH)}
                  className="px-3 py-1.5 rounded-xl text-xs border flex items-center gap-1 cursor-pointer"
                  style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
                >
                  <FlipHorizontal className="w-3.5 h-3.5" /> Flip
                </button>
                <button
                  onClick={() => setIsDrawingMode(!isDrawingMode)}
                  className="px-3 py-1.5 rounded-xl text-xs border flex items-center gap-1 cursor-pointer"
                  style={{
                    backgroundColor: isDrawingMode ? theme.primary : theme.elevated,
                    color: isDrawingMode ? '#FFF' : theme.textPrimary,
                    borderColor: theme.border,
                  }}
                >
                  <Brush className="w-3.5 h-3.5" /> {isDrawingMode ? 'Drawing Active' : 'Freehand Brush'}
                </button>
                <button
                  onClick={() => setBrushStrokes([])}
                  className="px-3 py-1.5 rounded-xl text-xs border flex items-center gap-1 cursor-pointer"
                  style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
                >
                  <Undo2 className="w-3.5 h-3.5" /> Clear Brush
                </button>
              </div>

              <button
                onMouseDown={() => setCompareOriginal(true)}
                onMouseUp={() => setCompareOriginal(false)}
                onMouseLeave={() => setCompareOriginal(false)}
                onClick={() => setCompareOriginal((v) => !v)}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold border flex items-center gap-1.5 cursor-pointer"
                style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
              >
                <Eye className="w-3.5 h-3.5" style={{ color: theme.primary }} />
                <span>{compareOriginal ? 'Viewing Original' : 'Before / After Compare'}</span>
              </button>
            </div>
          </div>

          <div
            className="lg:col-span-5 p-5 border space-y-4"
            style={{
              backgroundColor: theme.surface,
              borderColor: theme.border,
              borderRadius: `${cornerRadius}px`,
            }}
          >
            <h4 className="font-bold text-sm">Color Grading, Text Layer &amp; Export</h4>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between mb-1">
                  <span>Brightness</span>
                  <span>{(imgBrightness * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min={-0.6}
                  max={0.6}
                  step={0.05}
                  value={imgBrightness}
                  onChange={(e) => setImgBrightness(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Contrast</span>
                  <span>{(imgContrast * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min={0.6}
                  max={1.6}
                  step={0.05}
                  value={imgContrast}
                  onChange={(e) => setImgContrast(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Saturation</span>
                  <span>{(imgSaturation * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={2}
                  step={0.05}
                  value={imgSaturation}
                  onChange={(e) => setImgSaturation(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Warmth / Temperature</span>
                  <span>{(imgWarmth * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={imgWarmth}
                  onChange={(e) => setImgWarmth(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Vignette</span>
                  <span>{(imgVignette * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={imgVignette}
                  onChange={(e) => setImgVignette(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
              </div>

              <div className="pt-2 border-t space-y-2" style={{ borderColor: theme.border }}>
                <label className="block font-semibold">Text Layer Overlay &amp; Brush Options</label>
                <input
                  type="text"
                  value={imgTextOverlay}
                  onChange={(e) => setImgTextOverlay(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border text-xs"
                  style={{ backgroundColor: theme.bg, borderColor: theme.border, color: theme.textPrimary }}
                />
                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={imgWatermark}
                      onChange={(e) => setImgWatermark(e.target.checked)}
                      className="accent-indigo-500"
                    />
                    <span>Include Studio Watermark</span>
                  </label>
                  <div className="flex items-center gap-1.5">
                    <span>Brush Color:</span>
                    <input
                      type="color"
                      value={activeBrushColor}
                      onChange={(e) => setActiveBrushColor(e.target.value)}
                      className="w-6 h-6 rounded cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={handleExportPhoto}
              className="w-full py-2.5 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-2 cursor-pointer"
              style={{ backgroundColor: theme.primary }}
            >
              <Download className="w-4 h-4" />
              <span>Save as New Edited Image (.PNG)</span>
            </button>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 4: REAL MEDIA METADATA & EMBEDDED COVER ARTWORK EDITOR
         ===================================================================== */}
      {activeSubTab === 'metadata_editor' && targetMetaTrack && (
        <div
          className="p-6 border space-y-5"
          style={{
            backgroundColor: theme.surface,
            borderColor: theme.border,
            borderRadius: `${cornerRadius}px`,
          }}
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-lg">
                {isArabic
                  ? 'محرر البيانات الوصفية والغلاف المدمج (ID3 / EXIF)'
                  : 'Real Media Metadata & Embedded Artwork Editor'}
              </h3>
              <p className="text-xs" style={{ color: theme.textSecondary }}>
                {isArabic
                  ? 'يقوم هذا الخيار بتعديل البيانات الوصفية الفعلية للملف والصورة المدمجة'
                  : 'Modifies actual audio tags, synchronized lyrics, image EXIF fields, and embedded album artwork using safe atomic replacement.'}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setMetaMode(metaMode === 'audio' ? 'image' : 'audio')}
                className="px-3 py-2 rounded-xl text-xs font-semibold border cursor-pointer"
                style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
              >
                {metaMode === 'audio' ? 'Mode: Audio ID3/Vorbis' : 'Mode: Image EXIF'}
              </button>
              {metaMode === 'image' && currentPhoto && (
                <button
                  onClick={() => {
                    onUpdatePhotoItem({
                      ...currentPhoto,
                      description: `${currentPhoto.description} [EXIF Verified]`,
                    });
                    setMetaSavedBanner(`Updated EXIF tags for "${currentPhoto.title}" via ExifInterface.`);
                  }}
                  className="px-3 py-2 rounded-xl text-xs font-semibold text-white cursor-pointer"
                  style={{ backgroundColor: theme.primary }}
                >
                  Write Image EXIF
                </button>
              )}
              <select
                value={metaTrackId}
                onChange={(e) => setMetaTrackId(e.target.value)}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold border"
                style={{ backgroundColor: theme.elevated, borderColor: theme.border, color: theme.textPrimary }}
              >
                {audioTracks.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.title} — {t.artist}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            {/* Embedded Artwork Preview & Replace */}
            <div className="md:col-span-4 flex flex-col items-center space-y-3">
              <div
                className="w-44 h-44 rounded-3xl overflow-hidden flex items-center justify-center shadow-lg border"
                style={{
                  borderColor: theme.border,
                  background: targetMetaTrack.customCoverDataUrl
                    ? `url(${targetMetaTrack.customCoverDataUrl}) center/cover`
                    : `linear-gradient(135deg, ${targetMetaTrack.coverGradient[0]}, ${targetMetaTrack.coverGradient[1]})`,
                }}
              >
                {!targetMetaTrack.customCoverDataUrl && (
                  <span className="text-white/90 font-bold text-xs px-3 py-1 rounded-full bg-black/30">
                    Embedded Cover
                  </span>
                )}
              </div>

              <label
                className="px-4 py-2 rounded-xl text-xs font-semibold border cursor-pointer flex items-center gap-2"
                style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
              >
                <Upload className="w-3.5 h-3.5" style={{ color: theme.primary }} />
                <span>Replace Embedded Artwork</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleCoverArtUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* Tag Fields */}
            <div className="md:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block mb-1" style={{ color: theme.textSecondary }}>
                  Track Title
                </label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border"
                  style={{ backgroundColor: theme.bg, borderColor: theme.border, color: theme.textPrimary }}
                />
              </div>
              <div>
                <label className="block mb-1" style={{ color: theme.textSecondary }}>
                  Artist
                </label>
                <input
                  type="text"
                  value={editArtist}
                  onChange={(e) => setEditArtist(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border"
                  style={{ backgroundColor: theme.bg, borderColor: theme.border, color: theme.textPrimary }}
                />
              </div>
              <div>
                <label className="block mb-1" style={{ color: theme.textSecondary }}>
                  Album
                </label>
                <input
                  type="text"
                  value={editAlbum}
                  onChange={(e) => setEditAlbum(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border"
                  style={{ backgroundColor: theme.bg, borderColor: theme.border, color: theme.textPrimary }}
                />
              </div>
              <div>
                <label className="block mb-1" style={{ color: theme.textSecondary }}>
                  Genre
                </label>
                <input
                  type="text"
                  value={editGenre}
                  onChange={(e) => setEditGenre(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border"
                  style={{ backgroundColor: theme.bg, borderColor: theme.border, color: theme.textPrimary }}
                />
              </div>
              <div>
                <label className="block mb-1" style={{ color: theme.textSecondary }}>
                  Year &amp; Track #
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={editYear}
                    onChange={(e) => setEditYear(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border"
                    style={{ backgroundColor: theme.bg, borderColor: theme.border, color: theme.textPrimary }}
                  />
                  <input
                    type="text"
                    value={editTrackNum}
                    onChange={(e) => setEditTrackNum(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border"
                    style={{ backgroundColor: theme.bg, borderColor: theme.border, color: theme.textPrimary }}
                  />
                </div>
              </div>
              <div>
                <label className="block mb-1" style={{ color: theme.textSecondary }}>
                  Composer
                </label>
                <input
                  type="text"
                  value={editComposer}
                  onChange={(e) => setEditComposer(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border"
                  style={{ backgroundColor: theme.bg, borderColor: theme.border, color: theme.textPrimary }}
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block mb-1" style={{ color: theme.textSecondary }}>
                  Embedded Synchronized Lyrics (LRC)
                </label>
                <textarea
                  rows={3}
                  value={editLyrics}
                  onChange={(e) => setEditLyrics(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border font-mono text-[11px]"
                  style={{ backgroundColor: theme.bg, borderColor: theme.border, color: theme.textPrimary }}
                />
              </div>
              <div className="sm:col-span-2 flex justify-end">
                <button
                  onClick={handleSaveAudioMetadata}
                  className="px-5 py-2.5 rounded-xl text-xs font-bold text-white cursor-pointer"
                  style={{ backgroundColor: theme.primary }}
                >
                  Save Real Metadata Tags to File
                </button>
              </div>
            </div>
          </div>

          {metaSavedBanner && (
            <div
              className="flex items-center gap-2 p-3 rounded-xl text-xs font-medium border"
              style={{
                backgroundColor: `${theme.primary}18`,
                borderColor: `${theme.primary}55`,
              }}
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{metaSavedBanner}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
