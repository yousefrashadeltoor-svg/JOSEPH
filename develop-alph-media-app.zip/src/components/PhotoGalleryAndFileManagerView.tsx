import React, { useState, useEffect } from 'react';
import {
  Heart,
  Play,
  Pause,
  ZoomIn,
  ZoomOut,
  Info,
  Edit3,
  Trash2,
  EyeOff,
  Eye,
  Folder,
  Grid,
  List,
  CheckSquare,
  Copy,
  HardDrive,
  Sparkles,
  X,
} from 'lucide-react';
import {
  AlphThemeDefinition,
  PhotoMediaItem,
  AudioTrackItem,
  VideoMediaItem,
} from '../data/mediaCatalogAndThemes';

interface GalleryProps {
  photos: PhotoMediaItem[];
  onUpdatePhoto: (photo: PhotoMediaItem) => void;
  onDeletePhoto: (id: string) => void;
  onOpenInPhotoEditor: (photoId: string) => void;
  theme: AlphThemeDefinition;
  isArabic: boolean;
  cornerRadius: number;
}

export const PhotoGalleryView: React.FC<GalleryProps> = ({
  photos,
  onUpdatePhoto,
  onDeletePhoto,
  onOpenInPhotoEditor,
  theme,
  isArabic,
  cornerRadius,
}) => {
  const [category, setCategory] = useState<
    'all' | 'albums' | 'screenshots' | 'favorites' | 'hidden'
  >('all');
  const [viewerPhotoId, setViewerPhotoId] = useState<string | null>(null);
  const [zoomScale, setZoomScale] = useState(1.0);
  const [showExifDrawer, setShowExifDrawer] = useState(true);

  // Slideshow state
  const [isSlideshowActive, setIsSlideshowActive] = useState(false);
  const [slideshowIntervalSec, setSlideshowIntervalSec] = useState(3);
  const [slideshowIndex, setSlideshowIndex] = useState(0);

  const visiblePhotos = photos.filter((p) => {
    if (category === 'hidden') return p.isHidden;
    if (p.isHidden) return false;
    if (category === 'favorites') return p.isFavorite;
    if (category === 'screenshots') return p.isScreenshot;
    return true;
  });

  useEffect(() => {
    if (!isSlideshowActive || visiblePhotos.length === 0) return;
    const timer = window.setInterval(() => {
      setSlideshowIndex((prev) => (prev + 1) % visiblePhotos.length);
    }, slideshowIntervalSec * 1000);
    return () => clearInterval(timer);
  }, [isSlideshowActive, slideshowIntervalSec, visiblePhotos.length]);

  const activeViewerPhoto = photos.find((p) => p.id === viewerPhotoId) || null;

  return (
    <div className="space-y-5">
      {/* Category & Slideshow Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: 'all', labelEn: 'All Photos', labelAr: 'كل الصور' },
            { id: 'albums', labelEn: 'Albums & Folders', labelAr: 'الألبومات والمجلدات' },
            { id: 'screenshots', labelEn: 'Screenshots', labelAr: 'لقطات الشاشة' },
            { id: 'favorites', labelEn: 'Favorites', labelAr: 'المفضلة' },
            { id: 'hidden', labelEn: 'Hidden Vault', labelAr: 'العناصر المخفية' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setCategory(tab.id as typeof category)}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer"
              style={{
                backgroundColor: category === tab.id ? theme.primary : theme.surface,
                color: category === tab.id ? '#FFFFFF' : theme.textPrimary,
                borderColor: category === tab.id ? theme.primary : theme.border,
              }}
            >
              {isArabic ? tab.labelAr : tab.labelEn}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <select
            value={slideshowIntervalSec}
            onChange={(e) => setSlideshowIntervalSec(Number(e.target.value))}
            className="px-2.5 py-1.5 rounded-xl text-xs border"
            style={{ backgroundColor: theme.surface, borderColor: theme.border, color: theme.textPrimary }}
          >
            <option value={2}>2s / Slide</option>
            <option value={3}>3s / Slide</option>
            <option value={5}>5s / Slide</option>
          </select>
          <button
            onClick={() => {
              setSlideshowIndex(0);
              setIsSlideshowActive(!isSlideshowActive);
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white cursor-pointer"
            style={{ backgroundColor: theme.primary }}
          >
            {isSlideshowActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isSlideshowActive ? 'Stop Slideshow' : 'Start Slideshow'}</span>
          </button>
        </div>
      </div>

      {/* Active Slideshow Stage */}
      {isSlideshowActive && visiblePhotos[slideshowIndex] && (
        <div
          className="p-6 border rounded-3xl flex flex-col items-center space-y-3"
          style={{ backgroundColor: theme.surface, borderColor: theme.border }}
        >
          <div
            className="w-full h-64 rounded-2xl flex items-end p-5 text-white shadow-xl transition-all"
            style={{
              background: `linear-gradient(135deg, ${visiblePhotos[slideshowIndex].palette[0]}, ${visiblePhotos[slideshowIndex].palette[1]}, ${visiblePhotos[slideshowIndex].palette[2]})`,
            }}
          >
            <div>
              <div className="text-lg font-bold">{visiblePhotos[slideshowIndex].title}</div>
              <div className="text-xs opacity-85">
                {visiblePhotos[slideshowIndex].description} • Slide {slideshowIndex + 1} of{' '}
                {visiblePhotos.length}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Photo Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {visiblePhotos.map((photo) => (
          <div
            key={photo.id}
            className="overflow-hidden border group transition-all"
            style={{
              backgroundColor: theme.surface,
              borderColor: theme.border,
              borderRadius: `${cornerRadius}px`,
            }}
          >
            <div
              onClick={() => {
                setViewerPhotoId(photo.id);
                setZoomScale(1.0);
              }}
              className="h-44 relative p-4 flex flex-col justify-between cursor-pointer"
              style={{
                background: `linear-gradient(135deg, ${photo.palette[0]}, ${photo.palette[1]}, ${photo.palette[2]})`,
              }}
            >
              <div className="flex justify-between items-center">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-black/45 text-white">
                  {photo.album}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onUpdatePhoto({ ...photo, isFavorite: !photo.isFavorite });
                  }}
                  className="p-1.5 rounded-full bg-black/45 text-white cursor-pointer"
                >
                  <Heart
                    className={`w-4 h-4 ${photo.isFavorite ? 'fill-rose-500 text-rose-500' : ''}`}
                  />
                </button>
              </div>
              <div className="text-white text-xs font-semibold truncate drop-shadow">
                {photo.title}
              </div>
            </div>

            <div className="p-3.5 space-y-2 text-xs">
              <div className="flex justify-between" style={{ color: theme.textSecondary }}>
                <span>
                  {photo.width}×{photo.height}
                </span>
                <span>{photo.sizeMb} MB</span>
              </div>
              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={() => onOpenInPhotoEditor(photo.id)}
                  className="flex items-center gap-1 font-semibold cursor-pointer"
                  style={{ color: theme.primary }}
                >
                  <Edit3 className="w-3.5 h-3.5" /> Edit in Studio
                </button>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onUpdatePhoto({ ...photo, isHidden: !photo.isHidden })}
                    title={photo.isHidden ? 'Unhide Photo' : 'Move to Hidden Vault'}
                    className="cursor-pointer"
                    style={{ color: theme.textSecondary }}
                  >
                    {photo.isHidden ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => onDeletePhoto(photo.id)}
                    className="text-rose-400 cursor-pointer"
                    title="Delete Photo"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Full-Screen Zoomable Photo Viewer & EXIF Inspector Modal */}
      {activeViewerPhoto && (
        <div className="fixed inset-0 z-50 bg-black/90 flex flex-col justify-between p-4 sm:p-6">
          <div className="flex items-center justify-between text-white">
            <div>
              <h4 className="font-bold text-base">{activeViewerPhoto.title}</h4>
              <p className="text-xs text-white/70">{activeViewerPhoto.folder}</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setZoomScale((z) => Math.max(1, z - 0.5))}
                className="p-2 rounded-xl bg-white/10 text-white cursor-pointer"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-xs font-mono">{zoomScale.toFixed(1)}x</span>
              <button
                onClick={() => setZoomScale((z) => Math.min(3, z + 0.5))}
                className="p-2 rounded-xl bg-white/10 text-white cursor-pointer"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={() => setShowExifDrawer((s) => !s)}
                className="p-2 rounded-xl bg-white/10 text-white cursor-pointer"
              >
                <Info className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewerPhotoId(null)}
                className="p-2 rounded-xl bg-white/15 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="flex-1 flex items-center justify-center overflow-hidden my-4">
            <div
              onDoubleClick={() => setZoomScale((z) => (z > 1 ? 1 : 2))}
              className="w-full max-w-2xl h-80 rounded-3xl flex items-center justify-center text-white font-bold transition-transform cursor-zoom-in shadow-2xl"
              style={{
                transform: `scale(${zoomScale})`,
                background: `linear-gradient(135deg, ${activeViewerPhoto.palette[0]}, ${activeViewerPhoto.palette[1]}, ${activeViewerPhoto.palette[2]})`,
              }}
            >
              <span>{activeViewerPhoto.description} (Double-Click to Zoom)</span>
            </div>
          </div>

          {showExifDrawer && (
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-white/15 text-white text-xs grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div>
                <span className="text-white/60 block">Camera Model</span>
                <strong>{activeViewerPhoto.cameraModel}</strong>
              </div>
              <div>
                <span className="text-white/60 block">Resolution</span>
                <strong>
                  {activeViewerPhoto.width}×{activeViewerPhoto.height}
                </strong>
              </div>
              <div>
                <span className="text-white/60 block">EXIF Exposure</span>
                <strong>
                  {activeViewerPhoto.aperture} • {activeViewerPhoto.exposureTime} • ISO{' '}
                  {activeViewerPhoto.iso}
                </strong>
              </div>
              <div>
                <span className="text-white/60 block">Date Taken</span>
                <strong>{activeViewerPhoto.dateTaken}</strong>
              </div>
              <div className="flex items-center justify-end">
                <button
                  onClick={() => {
                    const id = activeViewerPhoto.id;
                    setViewerPhotoId(null);
                    onOpenInPhotoEditor(id);
                  }}
                  className="px-4 py-2 rounded-xl font-bold text-white cursor-pointer"
                  style={{ backgroundColor: theme.primary }}
                >
                  Open in Photo Editor
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// ============================================================================
// BUILT-IN MEDIA FILE MANAGER COMPONENT
// ============================================================================
interface FileManagerProps {
  audioTracks: AudioTrackItem[];
  videos: VideoMediaItem[];
  photos: PhotoMediaItem[];
  onBulkRenamePrefix: (prefix: string) => void;
  theme: AlphThemeDefinition;
  isArabic: boolean;
  cornerRadius: number;
}

export const MediaFileManagerView: React.FC<FileManagerProps> = ({
  audioTracks,
  videos,
  photos,
  onBulkRenamePrefix,
  theme,
  isArabic,
  cornerRadius,
}) => {
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [folderFilter, setFolderFilter] = useState<'all' | 'audio' | 'video' | 'photos'>('all');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [renamePrefix, setRenamePrefix] = useState('ALPH_');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const audioTotalMb = audioTracks.reduce((acc, a) => acc + a.sizeMb, 0);
  const videoTotalMb = videos.reduce((acc, v) => acc + v.sizeMb, 0);
  const photoTotalMb = photos.reduce((acc, p) => acc + p.sizeMb, 0);
  const totalUsedMb = audioTotalMb + videoTotalMb + photoTotalMb;

  const unifiedFiles = [
    ...audioTracks.map((a) => ({
      id: a.id,
      name: `${a.title}.${a.format.toLowerCase().split(' ')[0]}`,
      folder: a.folder,
      type: 'audio' as const,
      sizeMb: a.sizeMb,
      detail: `${a.bitrateKbps} kbps • ${a.sampleRateHz} Hz`,
    })),
    ...videos.map((v) => ({
      id: v.id,
      name: v.title,
      folder: `/storage/emulated/0/${v.folder}`,
      type: 'video' as const,
      sizeMb: v.sizeMb,
      detail: `${v.resolution} • ${v.fps}fps`,
    })),
    ...photos.map((p) => ({
      id: p.id,
      name: p.title,
      folder: `/storage/emulated/0/${p.folder}`,
      type: 'photos' as const,
      sizeMb: p.sizeMb,
      detail: `${p.width}×${p.height}`,
    })),
  ].filter((f) => (folderFilter === 'all' ? true : f.type === folderFilter));

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-5">
      {/* Storage Overview Card */}
      <div
        className="p-5 border space-y-3"
        style={{
          backgroundColor: theme.surface,
          borderColor: theme.border,
          borderRadius: `${cornerRadius}px`,
        }}
      >
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <HardDrive className="w-5 h-5" style={{ color: theme.primary }} />
            <div>
              <h3 className="font-bold text-base">
                {isArabic
                  ? 'مدير ملفات الوسائط وتحليل التخزين'
                  : 'Scoped Storage Media File Manager'}
              </h3>
              <p className="text-xs" style={{ color: theme.textSecondary }}>
                Indexed Media Footprint: <strong>{totalUsedMb.toFixed(1)} MB</strong> across{' '}
                {unifiedFiles.length} accessible local files
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={() =>
                setStatusMessage(
                  'Duplicate Scan Complete: 0 byte-identical duplicate files detected across MediaStore.'
                )
              }
              className="px-3 py-1.5 rounded-xl font-semibold border flex items-center gap-1.5 cursor-pointer"
              style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
            >
              <Sparkles className="w-3.5 h-3.5" style={{ color: theme.primary }} />
              <span>Scan Duplicates</span>
            </button>
            <button
              onClick={() => setViewMode(viewMode === 'list' ? 'grid' : 'list')}
              className="p-2 rounded-xl border cursor-pointer"
              style={{ backgroundColor: theme.elevated, borderColor: theme.border }}
            >
              {viewMode === 'list' ? <Grid className="w-4 h-4" /> : <List className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Storage Segmented Progress Bar */}
        <div className="w-full h-3 rounded-full overflow-hidden flex bg-black/30">
          <div
            style={{ width: `${(audioTotalMb / totalUsedMb) * 100}%`, backgroundColor: '#6366F1' }}
            title="Audio"
          />
          <div
            style={{ width: `${(videoTotalMb / totalUsedMb) * 100}%`, backgroundColor: '#06B6D4' }}
            title="Video"
          />
          <div
            style={{ width: `${(photoTotalMb / totalUsedMb) * 100}%`, backgroundColor: '#10B981' }}
            title="Photos"
          />
        </div>
        <div className="flex flex-wrap gap-4 text-xs" style={{ color: theme.textSecondary }}>
          <span>● Audio: {audioTotalMb.toFixed(1)} MB</span>
          <span>● Video: {videoTotalMb.toFixed(1)} MB</span>
          <span>● Photos: {photoTotalMb.toFixed(1)} MB</span>
        </div>
      </div>

      {/* Category & Bulk Actions Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          {(['all', 'audio', 'video', 'photos'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setFolderFilter(cat)}
              className="px-3.5 py-1.5 rounded-xl text-xs font-semibold border capitalize cursor-pointer"
              style={{
                backgroundColor: folderFilter === cat ? theme.primary : theme.surface,
                color: folderFilter === cat ? '#FFF' : theme.textPrimary,
                borderColor: folderFilter === cat ? theme.primary : theme.border,
              }}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <input
            type="text"
            value={renamePrefix}
            onChange={(e) => setRenamePrefix(e.target.value)}
            placeholder="Bulk prefix..."
            className="px-3 py-1.5 rounded-xl text-xs border w-28"
            style={{ backgroundColor: theme.surface, borderColor: theme.border, color: theme.textPrimary }}
          />
          <button
            onClick={() => {
              onBulkRenamePrefix(renamePrefix);
              setStatusMessage(`Applied bulk prefix "${renamePrefix}" to audio tracks.`);
            }}
            className="px-3 py-1.5 rounded-xl text-xs font-semibold text-white cursor-pointer"
            style={{ backgroundColor: theme.primary }}
          >
            Bulk Rename Audio
          </button>
        </div>
      </div>

      {statusMessage && (
        <div
          className="p-3 rounded-xl text-xs border flex items-center justify-between"
          style={{ backgroundColor: `${theme.primary}18`, borderColor: `${theme.primary}55` }}
        >
          <span>{statusMessage}</span>
          <button onClick={() => setStatusMessage(null)} className="cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* File Browser List / Grid */}
      <div
        className={
          viewMode === 'grid'
            ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3'
            : 'space-y-2'
        }
      >
        {unifiedFiles.map((file) => {
          const isSelected = selectedIds.includes(file.id);
          return (
            <div
              key={file.id}
              onClick={() => toggleSelect(file.id)}
              className="p-3.5 border flex items-center justify-between gap-3 cursor-pointer transition-all"
              style={{
                backgroundColor: isSelected ? `${theme.primary}18` : theme.surface,
                borderColor: isSelected ? theme.primary : theme.border,
                borderRadius: `${Math.max(12, cornerRadius - 6)}px`,
              }}
            >
              <div className="flex items-center gap-3 min-w-0">
                <Folder className="w-5 h-5 shrink-0" style={{ color: theme.primary }} />
                <div className="min-w-0">
                  <div className="text-xs font-semibold truncate">{file.name}</div>
                  <div className="text-[11px] truncate" style={{ color: theme.textSecondary }}>
                    {file.folder} • {file.detail}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3 shrink-0 text-xs">
                <span className="font-mono" style={{ color: theme.textSecondary }}>
                  {file.sizeMb} MB
                </span>
                <CheckSquare
                  className="w-4 h-4"
                  style={{ color: isSelected ? theme.primary : theme.textSecondary }}
                />
                <Copy
                  className="w-3.5 h-3.5"
                  style={{ color: theme.textSecondary }}
                  onClick={(e) => {
                    e.stopPropagation();
                    setStatusMessage(`Copied file URI for "${file.name}" to clipboard.`);
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
