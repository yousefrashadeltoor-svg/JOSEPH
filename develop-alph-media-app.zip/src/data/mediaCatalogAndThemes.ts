export interface AlphThemeDefinition {
  id: string;
  nameEn: string;
  nameAr: string;
  isDark: boolean;
  bg: string;
  surface: string;
  elevated: string;
  border: string;
  textPrimary: string;
  textSecondary: string;
  primary: string;
  secondary: string;
}

export const ALPH_THEMES: AlphThemeDefinition[] = [
  {
    id: 'obsidian_black',
    nameEn: 'Obsidian Black',
    nameAr: 'أسود سبجي',
    isDark: true,
    bg: '#05070B',
    surface: '#0E121B',
    elevated: '#171E2E',
    border: 'rgba(255,255,255,0.09)',
    textPrimary: '#F8FAFC',
    textSecondary: '#94A3B8',
    primary: '#6366F1',
    secondary: '#818CF8',
  },
  {
    id: 'midnight_graphite',
    nameEn: 'Midnight Graphite',
    nameAr: 'جرافيت منتصف الليل',
    isDark: true,
    bg: '#0B0F17',
    surface: '#141B26',
    elevated: '#1E2838',
    border: 'rgba(255,255,255,0.10)',
    textPrimary: '#F1F5F9',
    textSecondary: '#94A3B8',
    primary: '#38BDF8',
    secondary: '#7DD3FC',
  },
  {
    id: 'deep_ocean',
    nameEn: 'Deep Ocean',
    nameAr: 'المحيط العميق',
    isDark: true,
    bg: '#041018',
    surface: '#0A1D2B',
    elevated: '#112B3F',
    border: 'rgba(34,211,238,0.16)',
    textPrimary: '#ECFEFF',
    textSecondary: '#67E8F9',
    primary: '#06B6D4',
    secondary: '#22D3EE',
  },
  {
    id: 'emerald_night',
    nameEn: 'Emerald Night',
    nameAr: 'ليل زمردي',
    isDark: true,
    bg: '#04120D',
    surface: '#0A2018',
    elevated: '#123125',
    border: 'rgba(52,211,153,0.16)',
    textPrimary: '#ECFDF5',
    textSecondary: '#6EE7B7',
    primary: '#10B981',
    secondary: '#34D399',
  },
  {
    id: 'royal_purple',
    nameEn: 'Royal Purple',
    nameAr: 'أرجواني ملكي',
    isDark: true,
    bg: '#0C0614',
    surface: '#170D26',
    elevated: '#23143A',
    border: 'rgba(192,132,252,0.16)',
    textPrimary: '#FAF5FF',
    textSecondary: '#D8B4FE',
    primary: '#A855F7',
    secondary: '#C084FC',
  },
  {
    id: 'soft_titanium',
    nameEn: 'Soft Titanium',
    nameAr: 'تيتانيوم ناعم',
    isDark: true,
    bg: '#121519',
    surface: '#1B2026',
    elevated: '#262C35',
    border: 'rgba(255,255,255,0.12)',
    textPrimary: '#F8FAFC',
    textSecondary: '#CBD5E1',
    primary: '#94A3B8',
    secondary: '#E2E8F0',
  },
  {
    id: 'premium_pearl',
    nameEn: 'Premium Pearl',
    nameAr: 'لؤلؤي فاخر',
    isDark: false,
    bg: '#F8FAFC',
    surface: '#FFFFFF',
    elevated: '#F1F5F9',
    border: 'rgba(15,23,42,0.10)',
    textPrimary: '#0F172A',
    textSecondary: '#475569',
    primary: '#4F46E5',
    secondary: '#6366F1',
  },
  {
    id: 'warm_light',
    nameEn: 'Warm Light',
    nameAr: 'إضاءة دافئة',
    isDark: false,
    bg: '#FAF7F2',
    surface: '#FFFFFF',
    elevated: '#F3EFE6',
    border: 'rgba(120,53,15,0.12)',
    textPrimary: '#1C1917',
    textSecondary: '#57534E',
    primary: '#D97706',
    secondary: '#F59E0B',
  },
  {
    id: 'minimal_monochrome',
    nameEn: 'Minimal Monochrome',
    nameAr: 'أحادي اللون بسيط',
    isDark: true,
    bg: '#09090B',
    surface: '#141417',
    elevated: '#202024',
    border: 'rgba(255,255,255,0.12)',
    textPrimary: '#FAFAFA',
    textSecondary: '#A1A1AA',
    primary: '#E4E4E7',
    secondary: '#A1A1AA',
  },
  {
    id: 'custom_accent',
    nameEn: 'Custom Accent Theme',
    nameAr: 'مظهر مخصص',
    isDark: true,
    bg: '#080A11',
    surface: '#121624',
    elevated: '#1B2236',
    border: 'rgba(236,72,153,0.22)',
    textPrimary: '#F8FAFC',
    textSecondary: '#94A3B8',
    primary: '#EC4899',
    secondary: '#F472B6',
  },
];

export interface AudioTrackItem {
  id: string;
  title: string;
  artist: string;
  album: string;
  albumArtist: string;
  genre: string;
  folder: string;
  durationSec: number;
  year: number;
  trackNumber: number;
  discNumber: number;
  composer: string;
  comment: string;
  bitrateKbps: number;
  sampleRateHz: number;
  format: string;
  sizeMb: number;
  isFavorite: boolean;
  playCount: number;
  coverGradient: [string, string];
  customCoverDataUrl?: string;
  audioUrl?: string; // If user imported a real local audio file
  synthNotesHz: number[]; // Real WebAudio harmonic progression for instant offline playback
  lrcLyrics: string;
}

export interface VideoMediaItem {
  id: string;
  title: string;
  folder: string;
  durationSec: number;
  resolution: string;
  fps: number;
  format: string;
  sizeMb: number;
  lastPositionSec: number;
  isFavorite: boolean;
  themeColor: string;
  videoUrl?: string;
  subtitles: { startSec: number; endSec: number; textEn: string; textAr: string }[];
  bookmarksSec: number[];
}

export interface PhotoMediaItem {
  id: string;
  title: string;
  album: string;
  folder: string;
  width: number;
  height: number;
  sizeMb: number;
  dateTaken: string;
  cameraModel: string;
  iso: string;
  aperture: string;
  exposureTime: string;
  orientation: number;
  description: string;
  author: string;
  isFavorite: boolean;
  isScreenshot: boolean;
  isHidden: boolean;
  palette: [string, string, string];
  imageUrl?: string;
}

export const INITIAL_AUDIO_TRACKS: AudioTrackItem[] = [
  {
    id: 'trk_1',
    title: 'Horizon of Glass',
    artist: 'Aether Ensemble',
    album: 'Nocturne Architecture',
    albumArtist: 'Aether Ensemble',
    genre: 'Electronic',
    folder: '/storage/emulated/0/Music/FLAC_Masters',
    durationSec: 28,
    year: 2025,
    trackNumber: 1,
    discNumber: 1,
    composer: 'L. Vance & K. Rostova',
    comment: '24-bit Studio Master',
    bitrateKbps: 1411,
    sampleRateHz: 48000,
    format: 'FLAC',
    sizeMb: 18.4,
    isFavorite: true,
    playCount: 42,
    coverGradient: ['#4F46E5', '#06B6D4'],
    synthNotesHz: [220.0, 277.18, 329.63, 440.0, 329.63, 293.66, 246.94, 220.0],
    lrcLyrics: `[00:00.00]Crystal light across the silent bay
[00:04.50]Every echo finds a clearer way
[00:09.00]Drifting through the horizon of glass
[00:14.00]Watching midnight constellations pass
[00:19.00]Resonance in every pulse and frame
[00:23.50]Calling out the morning by its name`,
  },
  {
    id: 'trk_2',
    title: 'Desert Mirage Overture',
    artist: 'Tariq Al-Mansoor',
    album: 'Dunes & Strings',
    albumArtist: 'Tariq Al-Mansoor',
    genre: 'Acoustic',
    folder: '/storage/emulated/0/Music/World_Sessions',
    durationSec: 24,
    year: 2024,
    trackNumber: 2,
    discNumber: 1,
    composer: 'Tariq Al-Mansoor',
    comment: 'Recorded in Marrakech & Cairo',
    bitrateKbps: 320,
    sampleRateHz: 44100,
    format: 'MP3',
    sizeMb: 7.2,
    isFavorite: true,
    playCount: 31,
    coverGradient: ['#D97706', '#EF4444'],
    synthNotesHz: [196.0, 246.94, 293.66, 392.0, 349.23, 293.66, 246.94, 196.0],
    lrcLyrics: `[00:00.00]Golden winds above the ancient sand
[00:05.00]Footsteps traced across a timeless land
[00:10.00]Oud and strings beneath the amber sky
[00:15.50]Silver stars awake as shadows fly
[00:20.00]Peace returns before the break of dawn`,
  },
  {
    id: 'trk_3',
    title: 'VelvetSubway 3AM',
    artist: 'Kuroshio Quartet',
    album: 'Tokyo Rain Tapes',
    albumArtist: 'Kuroshio Quartet',
    genre: 'Jazz',
    folder: '/storage/emulated/0/Music/Jazz_Vault',
    durationSec: 26,
    year: 2025,
    trackNumber: 4,
    discNumber: 1,
    composer: 'H. Takahashi',
    comment: 'Analog Tape Transfer',
    bitrateKbps: 320,
    sampleRateHz: 48000,
    format: 'AAC / M4A',
    sizeMb: 8.1,
    isFavorite: false,
    playCount: 19,
    coverGradient: ['#9333EA', '#EC4899'],
    synthNotesHz: [261.63, 311.13, 392.0, 466.16, 392.0, 349.23, 311.13, 261.63],
    lrcLyrics: `[00:00.00]Neon reflections on the station floor
[00:05.00]Last express is closing every door
[00:10.50]Saxophone and rain in gentle time
[00:16.00]Every chord a quiet midnight rhyme
[00:21.50]Fading out into the city glow`,
  },
  {
    id: 'trk_4',
    title: 'Emerald Solitude',
    artist: 'Nordic Chamber Project',
    album: 'Fjord Harmonics',
    albumArtist: 'Nordic Chamber Project',
    genre: 'Classical',
    folder: '/storage/emulated/0/Music/FLAC_Masters',
    durationSec: 30,
    year: 2023,
    trackNumber: 7,
    discNumber: 1,
    composer: 'S. Lindqvist',
    comment: 'Symphonic Hall Recording',
    bitrateKbps: 1411,
    sampleRateHz: 96000,
    format: 'FLAC',
    sizeMb: 24.6,
    isFavorite: false,
    playCount: 11,
    coverGradient: ['#10B981', '#0284C7'],
    synthNotesHz: [174.61, 220.0, 261.63, 349.23, 329.63, 261.63, 220.0, 174.61],
    lrcLyrics: `[00:00.00]Stillness resting on the northern sea
[00:06.00]Strings unfold a quiet symphony
[00:12.00]Glacier light and pine-covered heights
[00:18.00]Guiding travelers through winter nights
[00:24.00]Calm and clear as morning mist ascends`,
  },
  {
    id: 'trk_5',
    title: 'Solaris Pulse',
    artist: 'Nova Vector',
    album: 'Hyperion',
    albumArtist: 'Nova Vector',
    genre: 'Dance',
    folder: '/storage/emulated/0/Download',
    durationSec: 22,
    year: 2025,
    trackNumber: 3,
    discNumber: 1,
    composer: 'Nova Vector',
    comment: 'Club Edit',
    bitrateKbps: 320,
    sampleRateHz: 44100,
    format: 'MP3',
    sizeMb: 6.4,
    isFavorite: true,
    playCount: 55,
    coverGradient: ['#F43F5E', '#F59E0B'],
    synthNotesHz: [293.66, 369.99, 440.0, 587.33, 440.0, 369.99, 329.63, 293.66],
    lrcLyrics: `[00:00.00]Ignite the skyline with a single spark
[00:04.50]Electric motion cutting through the dark
[00:09.50]Solaris pulse is rising in our veins
[00:15.00]Breaking free from gravity and chains`,
  },
];

export const INITIAL_VIDEO_ITEMS: VideoMediaItem[] = [
  {
    id: 'vid_1',
    title: 'Alpine Aurora Borealis 4K.mp4',
    folder: 'Camera',
    durationSec: 20,
    resolution: '3840x2160 (4K)',
    fps: 60,
    format: 'MP4 (HEVC)',
    sizeMb: 68.4,
    lastPositionSec: 4,
    isFavorite: true,
    themeColor: '#06B6D4',
    bookmarksSec: [3, 11, 16],
    subtitles: [
      { startSec: 0, endSec: 5, textEn: 'High above the Arctic Circle at 2,400 meters.', textAr: 'أعلى الدائرة القطبية الشمالية على ارتفاع ٢٤٠٠ متر.' },
      { startSec: 5, endSec: 11, textEn: 'Solar winds collide with the upper magnetosphere.', textAr: 'تتصادم الرياح الشمسية مع الغلاف المغناطيسي العلوي.' },
      { startSec: 11, endSec: 16, textEn: 'Ribbons of emerald and violet dance across the peaks.', textAr: 'تتراقص أشرطة الزمرد والبنفسج فوق القمم الجبلية.' },
      { startSec: 16, endSec: 20, textEn: 'Captured in native 60fps HDR with spatial audio.', textAr: 'تم التصوير بدقة ٦٠ إطاراً في الثانية مع صوت محيطي.' },
    ],
  },
  {
    id: 'vid_2',
    title: 'Architectural Light Study.mp4',
    folder: 'Movies',
    durationSec: 18,
    resolution: '1920x1080 (FHD)',
    fps: 30,
    format: 'MP4 (H.264)',
    sizeMb: 29.2,
    lastPositionSec: 0,
    isFavorite: false,
    themeColor: '#F59E0B',
    bookmarksSec: [4, 12],
    subtitles: [
      { startSec: 0, endSec: 6, textEn: 'Morning sunlight enters the concrete atrium.', textAr: 'يدخل ضوء الصباح إلى البهو الخرساني.' },
      { startSec: 6, endSec: 12, textEn: 'Geometric shadows shift with every passing minute.', textAr: 'تتحرك الظلال الهندسية مع مرور كل دقيقة.' },
      { startSec: 12, endSec: 18, textEn: 'Designed for harmony between glass and stone.', textAr: 'صُمم لتحقيق الانسجام بين الزجاج والحجر.' },
    ],
  },
  {
    id: 'vid_3',
    title: 'Cybernetic Coastline Drone.webm',
    folder: 'Drone_Captures',
    durationSec: 24,
    resolution: '2560x1440 (QHD)',
    fps: 60,
    format: 'WebM (VP9)',
    sizeMb: 44.8,
    lastPositionSec: 8,
    isFavorite: true,
    themeColor: '#8B5CF6',
    bookmarksSec: [5, 14],
    subtitles: [
      { startSec: 0, endSec: 8, textEn: 'Low-altitude flight along the volcanic cliffs.', textAr: 'تحليق منخفض على طول المنحدرات البركانية.' },
      { startSec: 8, endSec: 16, textEn: 'Ocean swells crashing against basalt columns.', textAr: 'أمواج المحيط تتكسر على أعمدة البازلت.' },
      { startSec: 16, endSec: 24, textEn: 'Twilight horizon illuminated by coastal beacons.', textAr: 'أفق الغسق يضيء بمنارات الساحل.' },
    ],
  },
];

export const INITIAL_PHOTO_ITEMS: PhotoMediaItem[] = [
  {
    id: 'img_1',
    title: 'Sahara_Golden_Dunes.jpg',
    album: 'Travel & Nature',
    folder: 'DCIM/Camera',
    width: 4032,
    height: 3024,
    sizeMb: 4.8,
    dateTaken: '2025:02:14 17:42:10',
    cameraModel: 'Galaxy S24 Ultra',
    iso: '64',
    aperture: 'f/1.7',
    exposureTime: '1/1200s',
    orientation: 1,
    description: 'Sunset ridge over Erg Chebbi dunes',
    author: 'ALPH Photographer',
    isFavorite: true,
    isScreenshot: false,
    isHidden: false,
    palette: ['#F59E0B', '#B45309', '#1E1B4B'],
  },
  {
    id: 'img_2',
    title: 'Kyoto_Bamboo_Sanctuary.jpg',
    album: 'Travel & Nature',
    folder: 'DCIM/Camera',
    width: 3840,
    height: 2160,
    sizeMb: 3.9,
    dateTaken: '2025:01:28 07:15:44',
    cameraModel: 'Pixel 9 Pro',
    iso: '100',
    aperture: 'f/1.68',
    exposureTime: '1/320s',
    orientation: 1,
    description: 'Early morning mist in Arashiyama',
    author: 'ALPH Photographer',
    isFavorite: true,
    isScreenshot: false,
    isHidden: false,
    palette: ['#10B981', '#064E3B', '#022C22'],
  },
  {
    id: 'img_3',
    title: 'Nordic_Minimal_Pavilion.png',
    album: 'Architecture',
    folder: 'Pictures/Studio',
    width: 3200,
    height: 2400,
    sizeMb: 5.2,
    dateTaken: '2025:02:02 14:20:00',
    cameraModel: 'Sony A7 IV',
    iso: '125',
    aperture: 'f/2.8',
    exposureTime: '1/640s',
    orientation: 1,
    description: 'Oslo waterfront glass pavilion reflection',
    author: 'Studio Nord',
    isFavorite: false,
    isScreenshot: false,
    isHidden: false,
    palette: ['#38BDF8', '#0284C7', '#0F172A'],
  },
  {
    id: 'img_4',
    title: 'Screenshot_Equalizer_Setup.png',
    album: 'Screenshots',
    folder: 'Pictures/Screenshots',
    width: 1440,
    height: 3120,
    sizeMb: 1.4,
    dateTaken: '2025:02:18 21:08:12',
    cameraModel: 'Android System Capture',
    iso: 'N/A',
    aperture: 'N/A',
    exposureTime: 'N/A',
    orientation: 1,
    description: 'Reference audio equalizer curve',
    author: 'System',
    isFavorite: false,
    isScreenshot: true,
    isHidden: false,
    palette: ['#6366F1', '#A855F7', '#090D16'],
  },
];
