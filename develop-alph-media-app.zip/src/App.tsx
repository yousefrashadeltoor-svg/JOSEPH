import React, { useState, useEffect, useRef } from 'react';
import {
  Home,
  Music,
  Film,
  Image as ImageIcon,
  Wand2,
  FolderOpen,
  Settings,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Repeat,
  Shuffle,
  Heart,
  Sliders,
  Moon,
  Search,
  FolderGit2,
  Globe,
  Palette,
  Volume2,
  Upload,
  Bell,
  Clock,
  CheckCircle2,
  Sparkles,
  ListMusic,
  Mic2,
  Gauge,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import {
  ALPH_THEMES,
  AlphThemeDefinition,
  INITIAL_AUDIO_TRACKS,
  INITIAL_VIDEO_ITEMS,
  INITIAL_PHOTO_ITEMS,
  AudioTrackItem,
  VideoMediaItem,
  PhotoMediaItem,
} from './data/mediaCatalogAndThemes';
import { EQ_FREQUENCIES, EQ_PRESETS, parseLrcLyrics } from './utils/audioEngine';
import { AndroidSourceExplorerModal } from './components/AndroidSourceExplorerModal';
import { VideoStudioAndRingtoneView, StudioSubTab } from './components/VideoStudioAndRingtoneView';
import { AdvancedVideoPlayerView } from './components/AdvancedVideoPlayerView';
import {
  PhotoGalleryView,
  MediaFileManagerView,
} from './components/PhotoGalleryAndFileManagerView';

type MainTab = 'home' | 'music' | 'video' | 'gallery' | 'studio' | 'files' | 'settings';
type RepeatMode = 'off' | 'one' | 'all' | 'playlist' | 'count';

export function App() {
  // ============================================================================
  // THEME, LOCALIZATION & PERSONALIZATION STATE (PERSISTED IN LOCALSTORAGE)
  // ============================================================================
  const [themeId, setThemeId] = useState<string>(
    () => localStorage.getItem('alph_theme_id') || 'obsidian_black'
  );
  const [customPrimary, setCustomPrimary] = useState<string>(
    () => localStorage.getItem('alph_custom_primary') || '#EC4899'
  );
  const [customSecondary, setCustomSecondary] = useState<string>(
    () => localStorage.getItem('alph_custom_secondary') || '#F472B6'
  );
  const [cornerRadius, setCornerRadius] = useState<number>(
    () => Number(localStorage.getItem('alph_corner_radius')) || 22
  );
  const [dynamicArtworkColors, setDynamicArtworkColors] = useState<boolean>(true);
  const [isArabic, setIsArabic] = useState<boolean>(
    () => localStorage.getItem('alph_lang') === 'ar'
  );

  useEffect(() => {
    localStorage.setItem('alph_theme_id', themeId);
    localStorage.setItem('alph_custom_primary', customPrimary);
    localStorage.setItem('alph_custom_secondary', customSecondary);
    localStorage.setItem('alph_corner_radius', String(cornerRadius));
    localStorage.setItem('alph_lang', isArabic ? 'ar' : 'en');
  }, [themeId, customPrimary, customSecondary, cornerRadius, isArabic]);

  // ============================================================================
  // MEDIA LIBRARY STATE
  // ============================================================================
  const [audioTracks, setAudioTracks] = useState<AudioTrackItem[]>(INITIAL_AUDIO_TRACKS);
  const [videos, setVideos] = useState<VideoMediaItem[]>(INITIAL_VIDEO_ITEMS);
  const [photos, setPhotos] = useState<PhotoMediaItem[]>(INITIAL_PHOTO_ITEMS);
  const [recentlyEditedNotices, setRecentlyEditedNotices] = useState<string[]>([
    'Alpine Aurora Borealis 4K.mp4 — Timed text intervals [0s–4s] & [6s–11.5s] verified',
    'Horizon_of_Glass_Tone.wav — Ringtone trimmed (2.0s – 14.0s)',
  ]);

  // Navigation & Modals
  const [activeTab, setActiveTab] = useState<MainTab>('home');
  const [studioSubTab, setStudioSubTab] = useState<StudioSubTab>('video_editor');
  const [isRepoModalOpen, setIsRepoModalOpen] = useState<boolean>(false);
  const [globalSearch, setGlobalSearch] = useState<string>('');

  // Configurable Home Dashboard Sections
  const [homeSections, setHomeSections] = useState<
    { id: string; titleEn: string; titleAr: string; visible: boolean }[]
  >([
    { id: 'quick_studio', titleEn: 'Creative Studio & Ringtone Tools', titleAr: 'استوديو التحرير وصانع النغمات', visible: true },
    { id: 'continue_listening', titleEn: 'Continue Listening & Favorites', titleAr: 'متابعة الاستماع والمفضلة', visible: true },
    { id: 'continue_watching', titleEn: 'Continue Watching Videos', titleAr: 'متابعة مشاهدة الفيديو', visible: true },
    { id: 'recent_edits', titleEn: 'Recently Edited & Exported Media', titleAr: 'الوسائط المحررة مؤخراً', visible: true },
  ]);

  // ============================================================================
  // ADVANCED MUSIC PLAYER, REPEAT N-TIMES ENGINE & SLEEP TIMER STATE
  // ============================================================================
  const [activeTrackId, setActiveTrackId] = useState<string>(INITIAL_AUDIO_TRACKS[0].id);
  const activeTrack =
    audioTracks.find((t) => t.id === activeTrackId) || audioTracks[0];

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTimeSec, setCurrentTimeSec] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [isShuffle, setIsShuffle] = useState<boolean>(false);

  // Advanced Repeat System:
  // 'count' mode means TOTAL PLAYS of the current track before advancing to the next track.
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('count');
  const [repeatTargetPlays, setRepeatTargetPlays] = useState<number>(3);
  const [currentPlayIteration, setCurrentPlayIteration] = useState<number>(1);

  // Music Library Filter & Sub-panels
  const [musicCategory, setMusicCategory] = useState<
    'all' | 'albums' | 'artists' | 'genres' | 'folders' | 'favorites' | 'most_played'
  >('all');
  const [artworkStyle, setArtworkStyle] = useState<'rounded' | 'vinyl' | 'minimal'>('rounded');
  const [activeMusicPanel, setActiveMusicPanel] = useState<'lyrics' | 'equalizer' | 'queue'>('lyrics');
  const [lrcOffsetMs, setLrcOffsetMs] = useState<number>(0);

  // Equalizer & Audio Enhancements
  const [eqPreset, setEqPreset] = useState<string>('Flat');
  const [eqBandsDb, setEqBandsDb] = useState<number[]>([0, 0, 0, 0, 0]);
  const [bassBoostPct, setBassBoostPct] = useState<number>(35);
  const [virtualizerPct, setVirtualizerPct] = useState<number>(25);
  const [channelBalance, setChannelBalance] = useState<number>(0); // -1 (L) .. 0 .. +1 (R)
  const [masterVolume, setMasterVolume] = useState<number>(0.85);

  // Sleep Timer & Fade-Out Automation
  const [sleepTimerRemainingSec, setSleepTimerRemainingSec] = useState<number>(0);
  const [sleepTimerFadeOutSec, setSleepTimerFadeOutSec] = useState<number>(10);
  const [pauseOnHeadphoneDisconnect, setPauseOnHeadphoneDisconnect] = useState<boolean>(true);

  // Video gesture settings
  const [enableBrightnessGesture, setEnableBrightnessGesture] = useState<boolean>(true);
  const [enableVolumeGesture, setEnableVolumeGesture] = useState<boolean>(true);
  const [enableHorizontalSeek, setEnableHorizontalSeek] = useState<boolean>(true);
  const [seekIncrementSec, setSeekIncrementSec] = useState<number>(10);
  const [activeVideoId, setActiveVideoId] = useState<string>(INITIAL_VIDEO_ITEMS[0].id);

  // Compute active theme with optional Dynamic Artwork Accent
  const baseTheme: AlphThemeDefinition =
    ALPH_THEMES.find((t) => t.id === themeId) || ALPH_THEMES[0];
  const activeTheme: AlphThemeDefinition = {
    ...baseTheme,
    primary:
      themeId === 'custom_accent'
        ? customPrimary
        : dynamicArtworkColors && activeTrack
        ? activeTrack.coverGradient[0]
        : baseTheme.primary,
    secondary:
      themeId === 'custom_accent'
        ? customSecondary
        : dynamicArtworkColors && activeTrack
        ? activeTrack.coverGradient[1]
        : baseTheme.secondary,
  };

  // ============================================================================
  // REAL WEB AUDIO API SYNTHESIZER + EQUALIZER ENGINE
  // ============================================================================
  const audioCtxRef = useRef<AudioContext | null>(null);
  const uploadedAudioElRef = useRef<HTMLAudioElement | null>(null);

  // Trigger a soft harmonic chord note through WebAudio when playing built-in tracks
  const playWebAudioNotePulse = (freqHz: number, gainLevel: number) => {
    try {
      if (!audioCtxRef.current) {
        const AudioContextClass =
          window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        audioCtxRef.current = new AudioContextClass();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const panner = ctx.createStereoPanner();

      // Apply EQ Bass Boost & High Treble shaping
      const lowBoostFactor = 1 + (eqBandsDb[0] + bassBoostPct / 20) * 0.04;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freqHz * playbackSpeed, now);

      const fadeMultiplier =
        sleepTimerRemainingSec > 0 && sleepTimerRemainingSec <= sleepTimerFadeOutSec
          ? sleepTimerRemainingSec / sleepTimerFadeOutSec
          : 1.0;

      const effectiveGain = Math.max(
        0.001,
        Math.min(0.28, gainLevel * masterVolume * fadeMultiplier * lowBoostFactor * 0.14)
      );

      panner.pan.setValueAtTime(channelBalance, now);
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(effectiveGain, now + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0008, now + 0.42);

      osc.connect(panner);
      panner.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.45);
    } catch {
      // Ignore if autoplay blocked until user gesture
    }
  };

  // Advance Music Playback Timeline & Handle Real Repeat N-Times Advancement
  useEffect(() => {
    if (!isPlaying || !activeTrack) return;
    const tickMs = 250;
    const timer = window.setInterval(() => {
      setCurrentTimeSec((prev) => {
        const next = prev + (tickMs / 1000) * playbackSpeed;

        // Play subtle WebAudio harmonic note every ~0.75s for built-in synth tracks
        if (!activeTrack.audioUrl && Math.floor(next * 2) !== Math.floor(prev * 2)) {
          const idx = Math.floor(next * 1.5) % activeTrack.synthNotesHz.length;
          playWebAudioNotePulse(activeTrack.synthNotesHz[idx], 1.0);
        }

        if (next >= activeTrack.durationSec) {
          // Track finished! Evaluate Repeat Mode:
          if (repeatMode === 'one') {
            return 0;
          }
          if (repeatMode === 'count') {
            if (currentPlayIteration < repeatTargetPlays) {
              setCurrentPlayIteration((iter) => iter + 1);
              return 0;
            } else {
              // Target play count reached! Reset counter to 1 and advance to next track
              setCurrentPlayIteration(1);
              const currentIdx = audioTracks.findIndex((t) => t.id === activeTrack.id);
              const nextIdx = (currentIdx + 1) % audioTracks.length;
              setActiveTrackId(audioTracks[nextIdx].id);
              return 0;
            }
          }
          if (repeatMode === 'all' || repeatMode === 'playlist') {
            const currentIdx = audioTracks.findIndex((t) => t.id === activeTrack.id);
            const nextIdx = isShuffle
              ? Math.floor(Math.random() * audioTracks.length)
              : (currentIdx + 1) % audioTracks.length;
            setActiveTrackId(audioTracks[nextIdx].id);
            return 0;
          }
          // Repeat Off: advance if not at end of list, else pause
          const currentIdx = audioTracks.findIndex((t) => t.id === activeTrack.id);
          if (currentIdx + 1 < audioTracks.length) {
            setActiveTrackId(audioTracks[currentIdx + 1].id);
            return 0;
          } else {
            setIsPlaying(false);
            return 0;
          }
        }
        return next;
      });
    }, tickMs);

    return () => clearInterval(timer);
  }, [
    isPlaying,
    activeTrack,
    playbackSpeed,
    repeatMode,
    repeatTargetPlays,
    currentPlayIteration,
    audioTracks,
    isShuffle,
    masterVolume,
    channelBalance,
    sleepTimerRemainingSec,
    sleepTimerFadeOutSec,
    eqBandsDb,
    bassBoostPct,
  ]);

  // Background Sleep Timer Countdown with Automatic Fade-Out & Pause
  useEffect(() => {
    if (sleepTimerRemainingSec <= 0) return;
    const timer = window.setInterval(() => {
      setSleepTimerRemainingSec((prev) => {
        if (prev <= 1) {
          setIsPlaying(false);
          if (uploadedAudioElRef.current) {
            uploadedAudioElRef.current.pause();
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [sleepTimerRemainingSec]);

  const handleSelectTrack = (track: AudioTrackItem) => {
    setActiveTrackId(track.id);
    setCurrentTimeSec(0);
    setCurrentPlayIteration(1);
    setIsPlaying(true);
    setAudioTracks((prev) =>
      prev.map((item) =>
        item.id === track.id ? { ...item, playCount: item.playCount + 1 } : item
      )
    );
  };

  const handleSkipNext = () => {
    const idx = audioTracks.findIndex((t) => t.id === activeTrack.id);
    const nextIdx = isShuffle
      ? Math.floor(Math.random() * audioTracks.length)
      : (idx + 1) % audioTracks.length;
    handleSelectTrack(audioTracks[nextIdx]);
  };

  const handleSkipPrev = () => {
    if (currentTimeSec > 3) {
      setCurrentTimeSec(0);
      return;
    }
    const idx = audioTracks.findIndex((t) => t.id === activeTrack.id);
    const prevIdx = (idx - 1 + audioTracks.length) % audioTracks.length;
    handleSelectTrack(audioTracks[prevIdx]);
  };

  const handleUploadLocalAudio = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    const newTrack: AudioTrackItem = {
      id: `local_${Date.now()}`,
      title: file.name.replace(/\..+$/, ''),
      artist: 'Local Device Artist',
      album: 'Imported Audio',
      albumArtist: 'Local Device Artist',
      genre: 'Custom',
      folder: '/storage/emulated/0/Music/Imported',
      durationSec: 30,
      year: 2025,
      trackNumber: audioTracks.length + 1,
      discNumber: 1,
      composer: 'User Imported',
      comment: 'Imported via Storage Access Framework',
      bitrateKbps: 320,
      sampleRateHz: 44100,
      format: file.name.split('.').pop()?.toUpperCase() || 'AUDIO',
      sizeMb: Number((file.size / (1024 * 1024)).toFixed(2)) || 4.2,
      isFavorite: false,
      playCount: 1,
      coverGradient: ['#06B6D4', '#3B82F6'],
      audioUrl: url,
      synthNotesHz: [261.63, 329.63, 392.0, 523.25],
      lrcLyrics: `[00:00.00]Imported Local Audio Track: ${file.name}\n[00:05.00]Playing through ALPH Media Audio Engine`,
    };
    setAudioTracks((prev) => [newTrack, ...prev]);
    setActiveTrackId(newTrack.id);
    setCurrentTimeSec(0);
    setIsPlaying(true);
  };

  // Parsed LRC Lyrics for active track
  const parsedLyrics = parseLrcLyrics(activeTrack?.lrcLyrics || '', lrcOffsetMs);
  let activeLyricIdx = -1;
  for (let i = 0; i < parsedLyrics.length; i++) {
    if (currentTimeSec >= parsedLyrics[i].timestampSec) {
      activeLyricIdx = i;
    } else {
      break;
    }
  }

  // Filtered tracks for Music Library & Global Search
  const filteredAudioTracks = audioTracks.filter((t) => {
    const q = globalSearch.trim().toLowerCase();
    const matchesSearch =
      !q ||
      t.title.toLowerCase().includes(q) ||
      t.artist.toLowerCase().includes(q) ||
      t.album.toLowerCase().includes(q) ||
      t.genre.toLowerCase().includes(q) ||
      t.folder.toLowerCase().includes(q);
    if (!matchesSearch) return false;
    if (musicCategory === 'favorites') return t.isFavorite;
    return true;
  });

  const sortedAudioTracks =
    musicCategory === 'most_played'
      ? [...filteredAudioTracks].sort((a, b) => b.playCount - a.playCount)
      : filteredAudioTracks;

  const activeVideo = videos.find((v) => v.id === activeVideoId) || videos[0];

  return (
    <div
      dir={isArabic ? 'rtl' : 'ltr'}
      className="min-h-screen flex flex-col transition-colors duration-300 pb-36"
      style={{
        backgroundColor: activeTheme.bg,
        color: activeTheme.textPrimary,
      }}
    >
      {/* =====================================================================
          TOP HEADER BAR
         ===================================================================== */}
      <header
        className="sticky top-0 z-30 border-b px-4 sm:px-8 py-3.5 transition-colors"
        style={{
          backgroundColor: `${activeTheme.surface}E6`,
          borderColor: activeTheme.border,
          backdropFilter: 'blur(16px)',
        }}
      >
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center font-black text-white shadow-lg"
              style={{
                background: `linear-gradient(135deg, ${activeTheme.primary}, ${activeTheme.secondary})`,
              }}
            >
              A
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-lg tracking-tight">ALPH Media</h1>
                <span
                  className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                  style={{
                    backgroundColor: `${activeTheme.primary}22`,
                    color: activeTheme.primary,
                  }}
                >
                  {activeTheme.nameEn}
                </span>
              </div>
              <p className="text-[11px] hidden sm:block" style={{ color: activeTheme.textSecondary }}>
                {isArabic
                  ? 'مشغل الموسيقى والفيديو ومعرض الصور واستوديو التحرير المتكامل'
                  : 'All-in-One Android Music Player, Video Player, Gallery & Media Studio'}
              </p>
            </div>
          </div>

          {/* Instant Smart Search */}
          <div
            className="flex-1 max-w-md mx-2 flex items-center gap-2 px-3.5 py-2 rounded-2xl border"
            style={{
              backgroundColor: activeTheme.elevated,
              borderColor: activeTheme.border,
            }}
          >
            <Search className="w-4 h-4 shrink-0" style={{ color: activeTheme.textSecondary }} />
            <input
              type="text"
              value={globalSearch}
              onChange={(e) => setGlobalSearch(e.target.value)}
              placeholder={
                isArabic
                  ? 'ابحث في الأغاني، الألبومات، الفيديوهات، الصور، المجلدات...'
                  : 'Search songs, albums, artists, videos, photos, folders...'
              }
              className="bg-transparent text-xs w-full focus:outline-none"
              style={{ color: activeTheme.textPrimary }}
            />
          </div>

          {/* Right Quick Actions: Sleep Timer Status, RTL/LTR Toggle, Android Source Repo */}
          <div className="flex items-center gap-2">
            {sleepTimerRemainingSec > 0 && (
              <button
                onClick={() => setSleepTimerRemainingSec(0)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border animate-pulse cursor-pointer"
                style={{
                  backgroundColor: `${activeTheme.primary}25`,
                  borderColor: activeTheme.primary,
                  color: activeTheme.primary,
                }}
                title="Click to cancel Sleep Timer"
              >
                <Moon className="w-3.5 h-3.5" />
                <span>
                  {Math.floor(sleepTimerRemainingSec / 60)}:
                  {String(sleepTimerRemainingSec % 60).padStart(2, '0')}
                </span>
              </button>
            )}

            <button
              onClick={() => setIsArabic((ar) => !ar)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer"
              style={{
                backgroundColor: activeTheme.elevated,
                borderColor: activeTheme.border,
                color: activeTheme.textPrimary,
              }}
            >
              <Globe className="w-3.5 h-3.5" style={{ color: activeTheme.primary }} />
              <span>{isArabic ? 'English (LTR)' : 'العربية (RTL)'}</span>
            </button>

            <button
              onClick={() => setIsRepoModalOpen(true)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold text-white shadow-md transition-transform hover:scale-[1.01] cursor-pointer"
              style={{ backgroundColor: activeTheme.primary }}
            >
              <FolderGit2 className="w-4 h-4" />
              <span>
                {isArabic ? 'كود مشروع أندرويد & GitHub' : 'Android Source & GitHub CI'}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* =====================================================================
          MAIN WORKSPACE CONTENT
         ===================================================================== */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-6">
        {/* -------------------------------------------------------------------
            1. HOME DASHBOARD
           ------------------------------------------------------------------- */}
        {activeTab === 'home' && (
          <div className="space-y-6">
            {/* Hero Banner */}
            <div
              className="p-6 border relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6"
              style={{
                backgroundColor: activeTheme.surface,
                borderColor: activeTheme.border,
                borderRadius: `${cornerRadius}px`,
              }}
            >
              <div className="space-y-2 max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold" style={{ backgroundColor: `${activeTheme.primary}20`, color: activeTheme.primary }}>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>
                    {isArabic
                      ? 'تطبيق أندرويد أصلي متكامل • يعمل بدون إنترنت ١٠٠٪'
                      : 'Native Offline-First Media Ecosystem • Zero Fake Controls'}
                  </span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                  {isArabic
                    ? 'مرحباً بك في ALPH Media'
                    : 'Your Complete Media Library & Creative Studio'}
                </h2>
                <p className="text-xs sm:text-sm leading-relaxed" style={{ color: activeTheme.textSecondary }}>
                  {isArabic
                    ? 'استمع إلى الموسيقى مع نظام التكرار الذكي ومعادل الصوت، شاهد الفيديوهات بإيماءات السطوع والصوت، وحرر الفيديو والصوت والصور والبيانات الوصفية الفعلية.'
                    : 'Experience precision audio with Repeat N-Times & 5-band Equalizer, gesture-driven 4K video playback, waveform ringtone creation, timed-caption video editing, and real metadata tag management.'}
                </p>
              </div>

              <div className="flex flex-wrap gap-2.5 shrink-0">
                <button
                  onClick={() => setActiveTab('music')}
                  className="px-4 py-2.5 rounded-2xl text-xs font-bold text-white flex items-center gap-2 cursor-pointer"
                  style={{ backgroundColor: activeTheme.primary }}
                >
                  <Music className="w-4 h-4" />
                  <span>{isArabic ? 'فتح مشغل الموسيقى' : 'Open Music Player'}</span>
                </button>
                <button
                  onClick={() => {
                    setStudioSubTab('video_editor');
                    setActiveTab('studio');
                  }}
                  className="px-4 py-2.5 rounded-2xl text-xs font-bold border flex items-center gap-2 cursor-pointer"
                  style={{
                    backgroundColor: activeTheme.elevated,
                    borderColor: activeTheme.border,
                  }}
                >
                  <Wand2 className="w-4 h-4" style={{ color: activeTheme.primary }} />
                  <span>{isArabic ? 'استوديو التحرير' : 'Creative Studio'}</span>
                </button>
              </div>
            </div>

            {/* Configurable Dashboard Sections */}
            {homeSections.map((sec) => {
              if (!sec.visible) return null;

              if (sec.id === 'quick_studio') {
                return (
                  <div key={sec.id} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-base">
                        {isArabic ? sec.titleAr : sec.titleEn}
                      </h3>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      {[
                        {
                          titleEn: 'Video Studio & Timed Text',
                          titleAr: 'محرر الفيديو والنصوص المؤقتة',
                          descEn: 'Trim, split, apply 13 filters & add text to exact timeline intervals',
                          descAr: 'قص، تقسيم، فلاتر وإضافة نص لفترة زمنية محددة',
                          sub: 'video_editor' as StudioSubTab,
                          icon: Film,
                        },
                        {
                          titleEn: 'Ringtone & Alarm Creator',
                          titleAr: 'صانع نغمات الرنين والمنبه',
                          descEn: 'Waveform handle trimming, fade-in/out & system tone assignment',
                          descAr: 'قص الموجة الصوتية وتعيين نغمة الرنين أو المنبه',
                          sub: 'ringtone' as StudioSubTab,
                          icon: Bell,
                        },
                        {
                          titleEn: 'Professional Photo Editor',
                          titleAr: 'محرر الصور الاحترافي',
                          descEn: 'Color grading, text layers, freehand brush & before/after compare',
                          descAr: 'تعديل الألوان، النصوص، الرسم والمقارنة قبل وبعد',
                          sub: 'photo_editor' as StudioSubTab,
                          icon: ImageIcon,
                        },
                        {
                          titleEn: 'Real Metadata & Tag Editor',
                          titleAr: 'محرر البيانات الوصفية والغلاف',
                          descEn: 'Edit ID3 tags, embedded cover art, LRC lyrics & image EXIF',
                          descAr: 'تعديل الوسوم، صورة الغلاف المدمجة وبيانات EXIF',
                          sub: 'metadata_editor' as StudioSubTab,
                          icon: Sliders,
                        },
                      ].map((card) => {
                        const Icon = card.icon;
                        return (
                          <button
                            key={card.sub}
                            onClick={() => {
                              setStudioSubTab(card.sub);
                              setActiveTab('studio');
                            }}
                            className="p-4 border text-start transition-all hover:scale-[1.01] flex flex-col justify-between gap-3 cursor-pointer"
                            style={{
                              backgroundColor: activeTheme.surface,
                              borderColor: activeTheme.border,
                              borderRadius: `${cornerRadius}px`,
                            }}
                          >
                            <div
                              className="w-10 h-10 rounded-2xl flex items-center justify-center"
                              style={{
                                backgroundColor: `${activeTheme.primary}20`,
                                color: activeTheme.primary,
                              }}
                            >
                              <Icon className="w-5 h-5" />
                            </div>
                            <div>
                              <div className="font-bold text-sm">
                                {isArabic ? card.titleAr : card.titleEn}
                              </div>
                              <p
                                className="text-xs mt-1 leading-relaxed"
                                style={{ color: activeTheme.textSecondary }}
                              >
                                {isArabic ? card.descAr : card.descEn}
                              </p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              }

              if (sec.id === 'continue_listening') {
                return (
                  <div key={sec.id} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-base">
                        {isArabic ? sec.titleAr : sec.titleEn}
                      </h3>
                      <button
                        onClick={() => setActiveTab('music')}
                        className="text-xs font-semibold cursor-pointer"
                        style={{ color: activeTheme.primary }}
                      >
                        {isArabic ? 'عرض كل المقاطع ←' : 'View All Music →'}
                      </button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                      {audioTracks.slice(0, 3).map((track) => (
                        <div
                          key={track.id}
                          onClick={() => handleSelectTrack(track)}
                          className="p-3.5 border flex items-center gap-3.5 cursor-pointer transition-all hover:opacity-95"
                          style={{
                            backgroundColor: activeTheme.surface,
                            borderColor:
                              track.id === activeTrack.id
                                ? activeTheme.primary
                                : activeTheme.border,
                            borderRadius: `${Math.max(14, cornerRadius - 4)}px`,
                          }}
                        >
                          <div
                            className="w-12 h-12 rounded-2xl shrink-0 flex items-center justify-center text-white font-bold shadow"
                            style={{
                              background: `linear-gradient(135deg, ${track.coverGradient[0]}, ${track.coverGradient[1]})`,
                            }}
                          >
                            <Music className="w-5 h-5" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="font-bold text-xs truncate">{track.title}</div>
                            <div
                              className="text-[11px] truncate"
                              style={{ color: activeTheme.textSecondary }}
                            >
                              {track.artist} • {track.format}
                            </div>
                            <div
                              className="text-[10px] mt-0.5 font-medium"
                              style={{ color: activeTheme.primary }}
                            >
                              Played {track.playCount} times
                            </div>
                          </div>
                          <Play className="w-4 h-4 shrink-0" style={{ color: activeTheme.primary }} />
                        </div>
                      ))}
                    </div>
                  </div>
                );
              }

              if (sec.id === 'continue_watching') {
                return (
                  <div key={sec.id} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-base">
                        {isArabic ? sec.titleAr : sec.titleEn}
                      </h3>
                      <button
                        onClick={() => setActiveTab('video')}
                        className="text-xs font-semibold cursor-pointer"
                        style={{ color: activeTheme.primary }}
                      >
                        {isArabic ? 'فتح مشغل الفيديو ←' : 'Open Video Player →'}
                      </button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {videos.map((vid) => (
                        <div
                          key={vid.id}
                          onClick={() => {
                            setActiveVideoId(vid.id);
                            setActiveTab('video');
                          }}
                          className="p-4 border cursor-pointer transition-all hover:opacity-95 space-y-2"
                          style={{
                            backgroundColor: activeTheme.surface,
                            borderColor: activeTheme.border,
                            borderRadius: `${cornerRadius}px`,
                          }}
                        >
                          <div
                            className="h-28 rounded-xl flex items-center justify-center text-white relative overflow-hidden"
                            style={{
                              background: `linear-gradient(135deg, #090D16, ${vid.themeColor})`,
                            }}
                          >
                            <Play className="w-8 h-8 opacity-90" />
                            <span className="absolute bottom-2 end-2 text-[10px] px-2 py-0.5 rounded bg-black/65 font-mono">
                              {vid.resolution}
                            </span>
                          </div>
                          <div className="font-bold text-xs truncate">{vid.title}</div>
                          <div className="text-[11px]" style={{ color: activeTheme.textSecondary }}>
                            Resume from {vid.lastPositionSec}s / {vid.durationSec}s • {vid.fps}fps
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              }

              if (sec.id === 'recent_edits') {
                return (
                  <div
                    key={sec.id}
                    className="p-5 border space-y-3"
                    style={{
                      backgroundColor: activeTheme.surface,
                      borderColor: activeTheme.border,
                      borderRadius: `${cornerRadius}px`,
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-sm">
                        {isArabic ? sec.titleAr : sec.titleEn}
                      </h3>
                      <span className="text-[11px]" style={{ color: activeTheme.textSecondary }}>
                        Crash-Safe Drafts &amp; Exports
                      </span>
                    </div>
                    <div className="space-y-1.5">
                      {recentlyEditedNotices.slice(0, 4).map((notice, i) => (
                        <div
                          key={i}
                          className="flex items-center gap-2 text-xs px-3 py-2 rounded-xl"
                          style={{ backgroundColor: activeTheme.elevated }}
                        >
                          <CheckCircle2
                            className="w-3.5 h-3.5 shrink-0"
                            style={{ color: activeTheme.primary }}
                          />
                          <span>{notice}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              }
              return null;
            })}

            {/* Customize Home Dashboard Sections Bar */}
            <div
              className="p-4 border flex flex-wrap items-center justify-between gap-3 text-xs"
              style={{
                backgroundColor: activeTheme.surface,
                borderColor: activeTheme.border,
                borderRadius: `${cornerRadius}px`,
              }}
            >
              <span className="font-bold">
                {isArabic
                  ? 'تخصيص وترتيب أقسام الشاشة الرئيسية:'
                  : 'Customize & Reorder Home Dashboard Sections:'}
              </span>
              <div className="flex flex-wrap gap-2">
                {homeSections.map((sec, i) => (
                  <div
                    key={sec.id}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-xl border"
                    style={{
                      backgroundColor: activeTheme.elevated,
                      borderColor: activeTheme.border,
                    }}
                  >
                    <button
                      onClick={() =>
                        setHomeSections((prev) =>
                          prev.map((s) =>
                            s.id === sec.id ? { ...s, visible: !s.visible } : s
                          )
                        )
                      }
                      className="flex items-center gap-1 cursor-pointer"
                    >
                      {sec.visible ? (
                        <Eye className="w-3.5 h-3.5" style={{ color: activeTheme.primary }} />
                      ) : (
                        <EyeOff className="w-3.5 h-3.5 opacity-50" />
                      )}
                      <span>{isArabic ? sec.titleAr : sec.titleEn}</span>
                    </button>
                    {i > 0 && (
                      <button
                        onClick={() =>
                          setHomeSections((prev) => {
                            const copy = [...prev];
                            const temp = copy[i - 1];
                            copy[i - 1] = copy[i];
                            copy[i] = temp;
                            return copy;
                          })
                        }
                        className="ms-1 cursor-pointer"
                        title="Move Up"
                      >
                        <ArrowUp className="w-3 h-3" />
                      </button>
                    )}
                    {i < homeSections.length - 1 && (
                      <button
                        onClick={() =>
                          setHomeSections((prev) => {
                            const copy = [...prev];
                            const temp = copy[i + 1];
                            copy[i + 1] = copy[i];
                            copy[i] = temp;
                            return copy;
                          })
                        }
                        className="cursor-pointer"
                        title="Move Down"
                      >
                        <ArrowDown className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* -------------------------------------------------------------------
            2. ADVANCED MUSIC PLAYER
           ------------------------------------------------------------------- */}
        {activeTab === 'music' && activeTrack && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Full-Screen Premium Music Player Deck */}
            <div
              className="lg:col-span-6 p-6 border flex flex-col justify-between space-y-5 relative overflow-hidden"
              style={{
                backgroundColor: activeTheme.surface,
                borderColor: activeTheme.border,
                borderRadius: `${cornerRadius + 4}px`,
              }}
            >
              {/* Top Row: Artwork Style Switcher & Sleep Timer */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  {(['rounded', 'vinyl', 'minimal'] as const).map((style) => (
                    <button
                      key={style}
                      onClick={() => setArtworkStyle(style)}
                      className="px-2.5 py-1 rounded-lg text-[11px] font-semibold capitalize cursor-pointer"
                      style={{
                        backgroundColor:
                          artworkStyle === style ? activeTheme.primary : activeTheme.elevated,
                        color: artworkStyle === style ? '#FFF' : activeTheme.textSecondary,
                      }}
                    >
                      {style} Art
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-1.5">
                  {[15, 30, 60].map((mins) => (
                    <button
                      key={mins}
                      onClick={() => setSleepTimerRemainingSec(mins * 60)}
                      className="px-2.5 py-1 rounded-lg text-[11px] font-medium border flex items-center gap-1 cursor-pointer"
                      style={{
                        backgroundColor: activeTheme.elevated,
                        borderColor: activeTheme.border,
                      }}
                      title={`Start ${mins}m Sleep Timer with Fade-Out`}
                    >
                      <Clock className="w-3 h-3" style={{ color: activeTheme.primary }} />
                      <span>{mins}m</span>
                    </button>
                  ))}
                  <button
                    onClick={() => setSleepTimerRemainingSec(12)}
                    className="px-2.5 py-1 rounded-lg text-[11px] font-bold border cursor-pointer"
                    style={{
                      backgroundColor: `${activeTheme.primary}20`,
                      borderColor: activeTheme.primary,
                      color: activeTheme.primary,
                    }}
                    title="Test 12-second Sleep Timer with Gradual Volume Fade-Out"
                  >
                    12s Fade Demo
                  </button>
                </div>
              </div>

              {/* Large Album Artwork */}
              <div className="flex flex-col items-center py-2">
                <div
                  className={`w-56 h-56 sm:w-64 sm:h-64 flex items-center justify-center shadow-2xl border transition-all duration-500 ${
                    artworkStyle === 'vinyl'
                      ? `rounded-full ${isPlaying ? 'animate-spin' : ''}`
                      : artworkStyle === 'minimal'
                      ? 'rounded-2xl w-full h-52'
                      : 'rounded-3xl'
                  }`}
                  style={{
                    animationDuration: '14s',
                    borderColor: activeTheme.border,
                    background: activeTrack.customCoverDataUrl
                      ? `url(${activeTrack.customCoverDataUrl}) center/cover`
                      : `linear-gradient(135deg, ${activeTrack.coverGradient[0]}, ${activeTrack.coverGradient[1]})`,
                  }}
                >
                  {!activeTrack.customCoverDataUrl && (
                    <div className="text-center text-white p-4">
                      <Music className="w-12 h-12 mx-auto mb-2 opacity-90" />
                      <span className="text-xs font-bold tracking-wider uppercase px-3 py-1 rounded-full bg-black/30">
                        {activeTrack.format} • {activeTrack.bitrateKbps} kbps
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Track Title, Artist, Favorite */}
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <h2 className="text-xl font-extrabold truncate">{activeTrack.title}</h2>
                  <p className="text-xs truncate" style={{ color: activeTheme.textSecondary }}>
                    {activeTrack.artist} • {activeTrack.album} ({activeTrack.year})
                  </p>
                </div>
                <button
                  onClick={() =>
                    setAudioTracks((prev) =>
                      prev.map((t) =>
                        t.id === activeTrack.id ? { ...t, isFavorite: !t.isFavorite } : t
                      )
                    )
                  }
                  className="p-2.5 rounded-2xl border cursor-pointer"
                  style={{
                    backgroundColor: activeTheme.elevated,
                    borderColor: activeTheme.border,
                  }}
                >
                  <Heart
                    className={`w-5 h-5 ${
                      activeTrack.isFavorite ? 'fill-rose-500 text-rose-500' : ''
                    }`}
                  />
                </button>
              </div>

              {/* Playback Timeline Scrubber */}
              <div className="space-y-1">
                <input
                  type="range"
                  min={0}
                  max={activeTrack.durationSec}
                  step={0.1}
                  value={currentTimeSec}
                  onChange={(e) => setCurrentTimeSec(parseFloat(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer"
                />
                <div
                  className="flex justify-between text-xs font-mono"
                  style={{ color: activeTheme.textSecondary }}
                >
                  <span>0:{String(Math.floor(currentTimeSec)).padStart(2, '0')}</span>
                  {repeatMode === 'count' && (
                    <span className="font-bold" style={{ color: activeTheme.primary }}>
                      Total Plays Mode: Play {currentPlayIteration} of {repeatTargetPlays} (
                      {Math.max(0, repeatTargetPlays - currentPlayIteration)} remaining)
                    </span>
                  )}
                  <span>
                    -0:
                    {String(
                      Math.max(0, Math.ceil(activeTrack.durationSec - currentTimeSec))
                    ).padStart(2, '0')}
                  </span>
                </div>
              </div>

              {/* Main Transport Controls */}
              <div className="flex items-center justify-between">
                <button
                  onClick={() => setIsShuffle(!isShuffle)}
                  className="p-2.5 rounded-xl border cursor-pointer"
                  style={{
                    backgroundColor: isShuffle ? `${activeTheme.primary}25` : activeTheme.elevated,
                    borderColor: isShuffle ? activeTheme.primary : activeTheme.border,
                    color: isShuffle ? activeTheme.primary : activeTheme.textSecondary,
                  }}
                  title="Shuffle Queue"
                >
                  <Shuffle className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-3">
                  <button
                    onClick={handleSkipPrev}
                    className="p-3 rounded-2xl border cursor-pointer"
                    style={{
                      backgroundColor: activeTheme.elevated,
                      borderColor: activeTheme.border,
                    }}
                  >
                    <SkipBack className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="w-14 h-14 rounded-3xl flex items-center justify-center text-white shadow-xl transition-transform active:scale-95 cursor-pointer"
                    style={{ backgroundColor: activeTheme.primary }}
                  >
                    {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                  </button>
                  <button
                    onClick={handleSkipNext}
                    className="p-3 rounded-2xl border cursor-pointer"
                    style={{
                      backgroundColor: activeTheme.elevated,
                      borderColor: activeTheme.border,
                    }}
                  >
                    <SkipForward className="w-5 h-5" />
                  </button>
                </div>

                <button
                  onClick={() => {
                    const order: RepeatMode[] = ['off', 'one', 'all', 'count'];
                    const next = order[(order.indexOf(repeatMode) + 1) % order.length];
                    setRepeatMode(next);
                    setCurrentPlayIteration(1);
                  }}
                  className="px-3 py-2 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer"
                  style={{
                    backgroundColor:
                      repeatMode !== 'off' ? `${activeTheme.primary}25` : activeTheme.elevated,
                    borderColor:
                      repeatMode !== 'off' ? activeTheme.primary : activeTheme.border,
                    color:
                      repeatMode !== 'off' ? activeTheme.primary : activeTheme.textSecondary,
                  }}
                >
                  <Repeat className="w-4 h-4" />
                  <span>
                    {repeatMode === 'off'
                      ? 'Off'
                      : repeatMode === 'one'
                      ? '1x ∞'
                      : repeatMode === 'all'
                      ? 'All'
                      : `${repeatTargetPlays}x Plays`}
                  </span>
                </button>
              </div>

              {/* Advanced Repeat N-Times Selector & Playback Speed Row */}
              <div
                className="p-3.5 rounded-2xl border space-y-2.5 text-xs"
                style={{ backgroundColor: activeTheme.bg, borderColor: activeTheme.border }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold">
                    {isArabic
                      ? 'تكرار المقطع لعدد محدد (إجمالي مرات التشغيل):'
                      : 'Repeat Track N Times (Total Plays Before Advancing):'}
                  </span>
                  <div className="flex items-center gap-1.5">
                    {[2, 3, 4].map((count) => (
                      <button
                        key={count}
                        onClick={() => {
                          setRepeatMode('count');
                          setRepeatTargetPlays(count);
                          setCurrentPlayIteration(1);
                        }}
                        className="px-2.5 py-1 rounded-lg font-bold cursor-pointer"
                        style={{
                          backgroundColor:
                            repeatMode === 'count' && repeatTargetPlays === count
                              ? activeTheme.primary
                              : activeTheme.elevated,
                          color:
                            repeatMode === 'count' && repeatTargetPlays === count
                              ? '#FFF'
                              : activeTheme.textPrimary,
                        }}
                      >
                        {count}x
                      </button>
                    ))}
                    <input
                      type="number"
                      min={2}
                      max={25}
                      value={repeatTargetPlays}
                      onChange={(e) => {
                        setRepeatMode('count');
                        setRepeatTargetPlays(Math.max(2, parseInt(e.target.value, 10) || 2));
                        setCurrentPlayIteration(1);
                      }}
                      className="w-14 px-2 py-1 rounded-lg border text-center font-bold"
                      style={{
                        backgroundColor: activeTheme.surface,
                        borderColor: activeTheme.border,
                        color: activeTheme.textPrimary,
                      }}
                      title="Custom Repeat Total Plays Count"
                    />
                  </div>
                </div>

                {/* Playback Speed Presets & Slider */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t" style={{ borderColor: activeTheme.border }}>
                  <span className="flex items-center gap-1 font-semibold">
                    <Gauge className="w-3.5 h-3.5" style={{ color: activeTheme.primary }} />
                    Speed: {playbackSpeed.toFixed(2)}x
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {[0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0].map((spd) => (
                      <button
                        key={spd}
                        onClick={() => setPlaybackSpeed(spd)}
                        className="px-2 py-0.5 rounded text-[11px] font-semibold cursor-pointer"
                        style={{
                          backgroundColor:
                            playbackSpeed === spd ? activeTheme.primary : activeTheme.elevated,
                          color: playbackSpeed === spd ? '#FFF' : activeTheme.textSecondary,
                        }}
                      >
                        {spd}x
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Synchronized Lyrics, 5-Band Equalizer & Library Browser */}
            <div className="lg:col-span-6 space-y-5">
              {/* Sub-Panel Switcher: Synchronized Lyrics | Equalizer & Effects | Music Library */}
              <div
                className="p-5 border space-y-4"
                style={{
                  backgroundColor: activeTheme.surface,
                  borderColor: activeTheme.border,
                  borderRadius: `${cornerRadius}px`,
                }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex gap-2">
                    {[
                      { id: 'lyrics' as const, label: 'Synchronized Lyrics (LRC)', icon: Mic2 },
                      { id: 'equalizer' as const, label: 'Equalizer & Audio FX', icon: Sliders },
                      { id: 'queue' as const, label: 'Library & Queue', icon: ListMusic },
                    ].map((p) => {
                      const Icon = p.icon;
                      const active = activeMusicPanel === p.id;
                      return (
                        <button
                          key={p.id}
                          onClick={() => setActiveMusicPanel(p.id)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer"
                          style={{
                            backgroundColor: active ? activeTheme.primary : activeTheme.elevated,
                            color: active ? '#FFF' : activeTheme.textPrimary,
                          }}
                        >
                          <Icon className="w-3.5 h-3.5" />
                          <span>{p.label}</span>
                        </button>
                      );
                    })}
                  </div>

                  <label
                    className="px-3 py-1.5 rounded-xl text-xs font-semibold border flex items-center gap-1.5 cursor-pointer"
                    style={{
                      backgroundColor: activeTheme.elevated,
                      borderColor: activeTheme.border,
                    }}
                  >
                    <Upload className="w-3.5 h-3.5" style={{ color: activeTheme.primary }} />
                    <span>Import Audio</span>
                    <input
                      type="file"
                      accept="audio/*"
                      onChange={handleUploadLocalAudio}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* PANEL A: SYNCHRONIZED LRC LYRICS */}
                {activeMusicPanel === 'lyrics' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span style={{ color: activeTheme.textSecondary }}>
                        Click any lyric line to seek • Sync Offset: {lrcOffsetMs}ms
                      </span>
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => setLrcOffsetMs((o) => o - 250)}
                          className="px-2 py-0.5 rounded border text-[11px] cursor-pointer"
                          style={{ backgroundColor: activeTheme.elevated, borderColor: activeTheme.border }}
                        >
                          -250ms
                        </button>
                        <button
                          onClick={() => setLrcOffsetMs((o) => o + 250)}
                          className="px-2 py-0.5 rounded border text-[11px] cursor-pointer"
                          style={{ backgroundColor: activeTheme.elevated, borderColor: activeTheme.border }}
                        >
                          +250ms
                        </button>
                      </div>
                    </div>

                    <div
                      className="p-4 rounded-2xl border space-y-2.5 max-h-56 overflow-y-auto"
                      style={{ backgroundColor: activeTheme.bg, borderColor: activeTheme.border }}
                    >
                      {parsedLyrics.map((line, idx) => {
                        const isCurrent = idx === activeLyricIdx;
                        return (
                          <div
                            key={idx}
                            onClick={() => setCurrentTimeSec(line.timestampSec)}
                            className="p-2 rounded-xl transition-all cursor-pointer flex items-center justify-between"
                            style={{
                              backgroundColor: isCurrent
                                ? `${activeTheme.primary}22`
                                : 'transparent',
                              color: isCurrent
                                ? activeTheme.primary
                                : activeTheme.textSecondary,
                              fontWeight: isCurrent ? 700 : 500,
                            }}
                          >
                            <span className="text-sm">{line.text}</span>
                            <span className="text-[11px] font-mono">
                              0:{String(Math.floor(line.timestampSec)).padStart(2, '0')}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* PANEL B: 5-BAND EQUALIZER & AUDIO ENHANCEMENTS */}
                {activeMusicPanel === 'equalizer' && (
                  <div className="space-y-4 text-xs">
                    <div className="flex flex-wrap gap-1.5">
                      {Object.keys(EQ_PRESETS).map((presetName) => (
                        <button
                          key={presetName}
                          onClick={() => {
                            setEqPreset(presetName);
                            setEqBandsDb([...EQ_PRESETS[presetName]]);
                          }}
                          className="px-2.5 py-1 rounded-lg text-[11px] font-semibold cursor-pointer"
                          style={{
                            backgroundColor:
                              eqPreset === presetName
                                ? activeTheme.primary
                                : activeTheme.elevated,
                            color:
                              eqPreset === presetName ? '#FFF' : activeTheme.textSecondary,
                          }}
                        >
                          {presetName}
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-5 gap-2 pt-2">
                      {EQ_FREQUENCIES.map((freq, idx) => (
                        <div
                          key={freq}
                          className="p-2.5 rounded-xl border flex flex-col items-center space-y-2"
                          style={{
                            backgroundColor: activeTheme.bg,
                            borderColor: activeTheme.border,
                          }}
                        >
                          <span className="font-mono text-[10px]" style={{ color: activeTheme.primary }}>
                            {eqBandsDb[idx] >= 0 ? `+${eqBandsDb[idx]}` : eqBandsDb[idx]} dB
                          </span>
                          <input
                            type="range"
                            min={-10}
                            max={10}
                            step={0.5}
                            value={eqBandsDb[idx]}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value);
                              setEqPreset('Custom');
                              setEqBandsDb((prev) =>
                                prev.map((b, i) => (i === idx ? val : b))
                              );
                            }}
                            className="w-full accent-indigo-500 cursor-pointer"
                          />
                          <span className="text-[10px]" style={{ color: activeTheme.textSecondary }}>
                            {freq >= 1000 ? `${freq / 1000}kHz` : `${freq}Hz`}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block mb-1">Bass Boost ({bassBoostPct}%)</label>
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={bassBoostPct}
                          onChange={(e) => setBassBoostPct(Number(e.target.value))}
                          className="w-full accent-indigo-500 cursor-pointer"
                        />
                      </div>
                      <div>
                        <label className="block mb-1">Virtualizer 3D ({virtualizerPct}%)</label>
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={virtualizerPct}
                          onChange={(e) => setVirtualizerPct(Number(e.target.value))}
                          className="w-full accent-indigo-500 cursor-pointer"
                        />
                      </div>
                      <div>
                        <label className="block mb-1">
                          L/R Balance ({channelBalance.toFixed(1)})
                        </label>
                        <input
                          type="range"
                          min={-1}
                          max={1}
                          step={0.1}
                          value={channelBalance}
                          onChange={(e) => setChannelBalance(parseFloat(e.target.value))}
                          className="w-full accent-indigo-500 cursor-pointer"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* PANEL C: MUSIC LIBRARY & QUEUE */}
                {activeMusicPanel === 'queue' && (
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-1.5">
                      {(
                        [
                          'all',
                          'albums',
                          'artists',
                          'genres',
                          'folders',
                          'favorites',
                          'most_played',
                        ] as const
                      ).map((cat) => (
                        <button
                          key={cat}
                          onClick={() => setMusicCategory(cat)}
                          className="px-2.5 py-1 rounded-lg text-[11px] font-semibold capitalize cursor-pointer"
                          style={{
                            backgroundColor:
                              musicCategory === cat
                                ? activeTheme.primary
                                : activeTheme.elevated,
                            color:
                              musicCategory === cat ? '#FFF' : activeTheme.textSecondary,
                          }}
                        >
                          {cat.replace('_', ' ')}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Track List */}
                <div className="space-y-2 max-h-72 overflow-y-auto pt-1">
                  {sortedAudioTracks.map((track) => {
                    const isCurrent = track.id === activeTrack.id;
                    return (
                      <div
                        key={track.id}
                        onClick={() => handleSelectTrack(track)}
                        className="p-3 rounded-2xl border flex items-center justify-between gap-3 cursor-pointer transition-all"
                        style={{
                          backgroundColor: isCurrent
                            ? `${activeTheme.primary}18`
                            : activeTheme.elevated,
                          borderColor: isCurrent ? activeTheme.primary : activeTheme.border,
                        }}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className="w-10 h-10 rounded-xl shrink-0 flex items-center justify-center text-white font-bold"
                            style={{
                              background: `linear-gradient(135deg, ${track.coverGradient[0]}, ${track.coverGradient[1]})`,
                            }}
                          >
                            <Music className="w-4 h-4" />
                          </div>
                          <div className="min-w-0">
                            <div className="text-xs font-bold truncate">{track.title}</div>
                            <div
                              className="text-[11px] truncate"
                              style={{ color: activeTheme.textSecondary }}
                            >
                              {track.artist} • {track.album} • {track.genre}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setStudioSubTab('ringtone');
                              setActiveTab('studio');
                            }}
                            className="px-2.5 py-1 rounded-lg text-[10px] font-semibold border cursor-pointer"
                            style={{
                              backgroundColor: activeTheme.surface,
                              borderColor: activeTheme.border,
                            }}
                            title="Make Ringtone from Track"
                          >
                            Ringtone
                          </button>
                          <span
                            className="text-xs font-mono"
                            style={{ color: activeTheme.textSecondary }}
                          >
                            0:{String(track.durationSec).padStart(2, '0')}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* -------------------------------------------------------------------
            3. ADVANCED VIDEO PLAYER
           ------------------------------------------------------------------- */}
        {activeTab === 'video' && (
          <AdvancedVideoPlayerView
            videos={videos}
            activeVideo={activeVideo}
            onSelectVideo={(vid) => setActiveVideoId(vid.id)}
            onUpdateVideo={(updated) =>
              setVideos((prev) => prev.map((v) => (v.id === updated.id ? updated : v)))
            }
            theme={activeTheme}
            isArabic={isArabic}
            cornerRadius={cornerRadius}
            enableBrightnessGesture={enableBrightnessGesture}
            enableVolumeGesture={enableVolumeGesture}
            enableHorizontalSeek={enableHorizontalSeek}
            seekIncrementSec={seekIncrementSec}
          />
        )}

        {/* -------------------------------------------------------------------
            4. ADVANCED PHOTO GALLERY
           ------------------------------------------------------------------- */}
        {activeTab === 'gallery' && (
          <PhotoGalleryView
            photos={photos}
            onUpdatePhoto={(updated) =>
              setPhotos((prev) => prev.map((p) => (p.id === updated.id ? updated : p)))
            }
            onDeletePhoto={(id) =>
              setPhotos((prev) => prev.filter((p) => p.id !== id))
            }
            onOpenInPhotoEditor={() => {
              setStudioSubTab('photo_editor');
              setActiveTab('studio');
            }}
            theme={activeTheme}
            isArabic={isArabic}
            cornerRadius={cornerRadius}
          />
        )}

        {/* -------------------------------------------------------------------
            5. CREATIVE STUDIO (VIDEO EDITOR, RINGTONE CREATOR, PHOTO & METADATA)
           ------------------------------------------------------------------- */}
        {activeTab === 'studio' && (
          <VideoStudioAndRingtoneView
            activeSubTab={studioSubTab}
            onSelectSubTab={setStudioSubTab}
            theme={activeTheme}
            isArabic={isArabic}
            cornerRadius={cornerRadius}
            audioTracks={audioTracks}
            videos={videos}
            photos={photos}
            onUpdateAudioTrack={(updated) =>
              setAudioTracks((prev) =>
                prev.map((t) => (t.id === updated.id ? updated : t))
              )
            }
            onUpdatePhotoItem={(updated) =>
              setPhotos((prev) =>
                prev.map((p) => (p.id === updated.id ? updated : p))
              )
            }
            onAddEditedMediaNotice={(msg) =>
              setRecentlyEditedNotices((prev) => [msg, ...prev])
            }
          />
        )}

        {/* -------------------------------------------------------------------
            6. BUILT-IN MEDIA FILE MANAGER
           ------------------------------------------------------------------- */}
        {activeTab === 'files' && (
          <MediaFileManagerView
            audioTracks={audioTracks}
            videos={videos}
            photos={photos}
            onBulkRenamePrefix={(prefix) =>
              setAudioTracks((prev) =>
                prev.map((t) => ({
                  ...t,
                  title: t.title.startsWith(prefix) ? t.title : `${prefix}${t.title}`,
                }))
              )
            }
            theme={activeTheme}
            isArabic={isArabic}
            cornerRadius={cornerRadius}
          />
        )}

        {/* -------------------------------------------------------------------
            7. EXTENSIVE THEMES & ADVANCED USER SETTINGS CENTER
           ------------------------------------------------------------------- */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            {/* 10 Complete Design System Themes */}
            <div
              className="p-6 border space-y-4"
              style={{
                backgroundColor: activeTheme.surface,
                borderColor: activeTheme.border,
                borderRadius: `${cornerRadius}px`,
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Palette className="w-5 h-5" style={{ color: activeTheme.primary }} />
                  <div>
                    <h3 className="font-bold text-lg">
                      {isArabic
                        ? 'محرك السمات الاحترافي (١٠ أنظمة تصميم كاملة)'
                        : 'Extensive Theme Engine (10 Complete Design Systems)'}
                    </h3>
                    <p className="text-xs" style={{ color: activeTheme.textSecondary }}>
                      Each theme customizes background layering, elevated surfaces, borders, text
                      hierarchy, and interactive states.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                {ALPH_THEMES.map((t) => {
                  const selected = t.id === themeId;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setThemeId(t.id)}
                      className="p-3.5 rounded-2xl border text-start transition-all cursor-pointer space-y-2.5"
                      style={{
                        backgroundColor: t.surface,
                        borderColor: selected ? t.primary : t.border,
                        boxShadow: selected ? `0 0 0 2px ${t.primary}` : 'none',
                        color: t.textPrimary,
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex gap-1.5">
                          <span
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: t.primary }}
                          />
                          <span
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: t.secondary }}
                          />
                          <span
                            className="w-4 h-4 rounded-full border border-white/20"
                            style={{ backgroundColor: t.bg }}
                          />
                        </div>
                        {selected && (
                          <CheckCircle2 className="w-4 h-4" style={{ color: t.primary }} />
                        )}
                      </div>
                      <div>
                        <div className="font-bold text-xs">{t.nameEn}</div>
                        <div className="text-[11px]" style={{ color: t.textSecondary }}>
                          {t.nameAr}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Custom Accent & Geometry Personalization */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-3 border-t text-xs" style={{ borderColor: activeTheme.border }}>
                <div className="p-3 rounded-xl border" style={{ backgroundColor: activeTheme.elevated, borderColor: activeTheme.border }}>
                  <label className="block mb-1 font-semibold">Custom Primary Accent</label>
                  <input
                    type="color"
                    value={customPrimary}
                    onChange={(e) => {
                      setThemeId('custom_accent');
                      setCustomPrimary(e.target.value);
                    }}
                    className="w-full h-8 rounded cursor-pointer"
                  />
                </div>
                <div className="p-3 rounded-xl border" style={{ backgroundColor: activeTheme.elevated, borderColor: activeTheme.border }}>
                  <label className="block mb-1 font-semibold">Custom Secondary Accent</label>
                  <input
                    type="color"
                    value={customSecondary}
                    onChange={(e) => {
                      setThemeId('custom_accent');
                      setCustomSecondary(e.target.value);
                    }}
                    className="w-full h-8 rounded cursor-pointer"
                  />
                </div>
                <div className="p-3 rounded-xl border" style={{ backgroundColor: activeTheme.elevated, borderColor: activeTheme.border }}>
                  <label className="block mb-1 font-semibold">
                    Corner Radius ({cornerRadius}dp)
                  </label>
                  <input
                    type="range"
                    min={12}
                    max={30}
                    value={cornerRadius}
                    onChange={(e) => setCornerRadius(Number(e.target.value))}
                    className="w-full accent-indigo-500 cursor-pointer"
                  />
                </div>
                <div className="p-3 rounded-xl border flex items-center justify-between" style={{ backgroundColor: activeTheme.elevated, borderColor: activeTheme.border }}>
                  <span className="font-semibold">Dynamic Artwork Colors</span>
                  <input
                    type="checkbox"
                    checked={dynamicArtworkColors}
                    onChange={(e) => setDynamicArtworkColors(e.target.checked)}
                    className="w-4 h-4 accent-indigo-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Playback, Gestures & Privacy Settings */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
              <div
                className="p-5 border space-y-3"
                style={{
                  backgroundColor: activeTheme.surface,
                  borderColor: activeTheme.border,
                  borderRadius: `${cornerRadius}px`,
                }}
              >
                <h4 className="font-bold text-sm">Video Gesture &amp; Playback Controls</h4>
                <label className="flex items-center justify-between py-1.5 cursor-pointer">
                  <span>Left Vertical Gesture — In-App Brightness</span>
                  <input
                    type="checkbox"
                    checked={enableBrightnessGesture}
                    onChange={(e) => setEnableBrightnessGesture(e.target.checked)}
                    className="w-4 h-4 accent-indigo-500"
                  />
                </label>
                <label className="flex items-center justify-between py-1.5 cursor-pointer">
                  <span>Right Vertical Gesture — Stream Volume</span>
                  <input
                    type="checkbox"
                    checked={enableVolumeGesture}
                    onChange={(e) => setEnableVolumeGesture(e.target.checked)}
                    className="w-4 h-4 accent-indigo-500"
                  />
                </label>
                <label className="flex items-center justify-between py-1.5 cursor-pointer">
                  <span>Horizontal Swipe — Fine Seeking</span>
                  <input
                    type="checkbox"
                    checked={enableHorizontalSeek}
                    onChange={(e) => setEnableHorizontalSeek(e.target.checked)}
                    className="w-4 h-4 accent-indigo-500"
                  />
                </label>
                <div className="flex items-center justify-between py-1.5">
                  <span>Double-Tap Seek Increment</span>
                  <select
                    value={seekIncrementSec}
                    onChange={(e) => setSeekIncrementSec(Number(e.target.value))}
                    className="px-2.5 py-1 rounded-lg border"
                    style={{ backgroundColor: activeTheme.elevated, borderColor: activeTheme.border }}
                  >
                    <option value={5}>5 seconds</option>
                    <option value={10}>10 seconds</option>
                    <option value={15}>15 seconds</option>
                  </select>
                </div>
              </div>

              <div
                className="p-5 border space-y-3"
                style={{
                  backgroundColor: activeTheme.surface,
                  borderColor: activeTheme.border,
                  borderRadius: `${cornerRadius}px`,
                }}
              >
                <h4 className="font-bold text-sm">Audio Automation, Privacy &amp; Storage</h4>
                <label className="flex items-center justify-between py-1.5 cursor-pointer">
                  <span>Auto-Pause When Headphones Disconnect</span>
                  <input
                    type="checkbox"
                    checked={pauseOnHeadphoneDisconnect}
                    onChange={(e) => setPauseOnHeadphoneDisconnect(e.target.checked)}
                    className="w-4 h-4 accent-indigo-500"
                  />
                </label>
                <div className="flex items-center justify-between py-1.5">
                  <span>Sleep Timer Fade-Out Duration</span>
                  <select
                    value={sleepTimerFadeOutSec}
                    onChange={(e) => setSleepTimerFadeOutSec(Number(e.target.value))}
                    className="px-2.5 py-1 rounded-lg border"
                    style={{ backgroundColor: activeTheme.elevated, borderColor: activeTheme.border }}
                  >
                    <option value={5}>5 seconds</option>
                    <option value={10}>10 seconds</option>
                    <option value={20}>20 seconds</option>
                  </select>
                </div>
                <div className="pt-2 flex gap-2">
                  <button
                    onClick={() =>
                      setAudioTracks((prev) => prev.map((t) => ({ ...t, playCount: 0 })))
                    }
                    className="px-3 py-2 rounded-xl border font-semibold cursor-pointer"
                    style={{ backgroundColor: activeTheme.elevated, borderColor: activeTheme.border }}
                  >
                    Reset Playback History
                  </button>
                  <button
                    onClick={() => setIsRepoModalOpen(true)}
                    className="px-3 py-2 rounded-xl font-bold text-white cursor-pointer"
                    style={{ backgroundColor: activeTheme.primary }}
                  >
                    Export Android Studio Project (.ZIP)
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* =====================================================================
          FLOATING MINI-PLAYER + MODERN ROUNDED BOTTOM NAVIGATION TASKBAR
         ===================================================================== */}
      <div className="fixed bottom-0 inset-x-0 z-40 pointer-events-none px-3 sm:px-6 pb-3">
        <div className="max-w-4xl mx-auto space-y-2 pointer-events-auto">
          {/* Floating Mini-Player */}
          {activeTrack && (
            <div
              onClick={() => setActiveTab('music')}
              className="px-4 py-2.5 border shadow-2xl flex items-center justify-between gap-3 cursor-pointer transition-all"
              style={{
                backgroundColor: `${activeTheme.elevated}F2`,
                borderColor: `${activeTheme.primary}66`,
                borderRadius: `${Math.max(16, cornerRadius)}px`,
                backdropFilter: 'blur(16px)',
              }}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="w-9 h-9 rounded-xl shrink-0 flex items-center justify-center text-white"
                  style={{
                    background: `linear-gradient(135deg, ${activeTrack.coverGradient[0]}, ${activeTrack.coverGradient[1]})`,
                  }}
                >
                  <Music className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold truncate">{activeTrack.title}</div>
                  <div className="text-[11px] truncate" style={{ color: activeTheme.textSecondary }}>
                    {activeTrack.artist}
                    {repeatMode === 'count' &&
                      ` • Play ${currentPlayIteration}/${repeatTargetPlays}`}
                  </div>
                </div>
              </div>

              <div
                className="flex items-center gap-2 shrink-0"
                onClick={(e) => e.stopPropagation()}
              >
                <Volume2 className="w-4 h-4 hidden sm:block" style={{ color: activeTheme.textSecondary }} />
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={masterVolume}
                  onChange={(e) => setMasterVolume(parseFloat(e.target.value))}
                  className="w-16 hidden sm:block accent-indigo-500 cursor-pointer"
                />
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="p-2 rounded-xl text-white cursor-pointer"
                  style={{ backgroundColor: activeTheme.primary }}
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </button>
                <button
                  onClick={handleSkipNext}
                  className="p-2 rounded-xl border cursor-pointer"
                  style={{
                    backgroundColor: activeTheme.surface,
                    borderColor: activeTheme.border,
                  }}
                >
                  <SkipForward className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Bottom Navigation Taskbar */}
          <nav
            className="px-2 py-2 border shadow-2xl flex items-center justify-around"
            style={{
              backgroundColor: `${activeTheme.surface}F5`,
              borderColor: activeTheme.border,
              borderRadius: `${cornerRadius + 4}px`,
              backdropFilter: 'blur(20px)',
            }}
          >
            {[
              { id: 'home' as MainTab, labelEn: 'Home', labelAr: 'الرئيسية', icon: Home },
              { id: 'music' as MainTab, labelEn: 'Music', labelAr: 'الموسيقى', icon: Music },
              { id: 'video' as MainTab, labelEn: 'Video', labelAr: 'الفيديو', icon: Film },
              { id: 'gallery' as MainTab, labelEn: 'Gallery', labelAr: 'المعرض', icon: ImageIcon },
              { id: 'studio' as MainTab, labelEn: 'Studio', labelAr: 'الاستوديو', icon: Wand2 },
              { id: 'files' as MainTab, labelEn: 'Files', labelAr: 'الملفات', icon: FolderOpen },
              { id: 'settings' as MainTab, labelEn: 'Settings', labelAr: 'الإعدادات', icon: Settings },
            ].map((item) => {
              const Icon = item.icon;
              const selected = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className="flex flex-col items-center gap-1 px-3 py-1.5 rounded-2xl transition-all cursor-pointer"
                  style={{
                    backgroundColor: selected ? `${activeTheme.primary}22` : 'transparent',
                    color: selected ? activeTheme.primary : activeTheme.textSecondary,
                  }}
                >
                  <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
                  <span className="text-[10px] font-bold">
                    {isArabic ? item.labelAr : item.labelEn}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Complete Native Android Source Code & GitHub CI Modal */}
      <AndroidSourceExplorerModal
        isOpen={isRepoModalOpen}
        onClose={() => setIsRepoModalOpen(false)}
        theme={activeTheme}
        isArabic={isArabic}
      />
    </div>
  );
}
export default App;
